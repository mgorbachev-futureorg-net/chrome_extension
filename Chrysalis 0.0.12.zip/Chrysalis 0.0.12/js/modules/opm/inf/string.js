/**
   This is text data module
*/

window.Module.syncRoot = function (moduleName)
{

/**
   List of modules which must be loaded before this
*/
window.Module.before[moduleName] = [] ;
window.Module.noncomplete[moduleName] = function()
 {
console.group("module <" + moduleName+ ">");

  /**
     Xpath to all using elements on pages
  */
 var Xpath =   {
                  CR: 
                     {
                       docId      : '//*[@id="lf28024"]',
                       docPriority:'//*/select[@name="risk_if_done"]',
                       docCompany : '//*[@id="lf27893"]',
                       docSummary  : '//*[@id="lf27796"]',
                       docAddInf   : '//*[@id="lf27959"]/table/tbody/tr/td',
                       docStuffOnly: '//*[@id="lf28022"]/table/tbody/tr/td',
                       docInfTable : '//*[@id="page_2"]/div/table/tbody/tr[3]/td',
                       docNewInfTable  : '//*[@id="page_2"]/div/table/tbody/tr[3]',
                       docWorkTab   : '//*[@id="tab_2_active"]/div',
                       docDetailTab   : '//*[@id="tab_0_active"]/div',
                       docDetailPage:'//*[@id="page_0"]',
                       docEditSummary:'//*[@id="e_1036"]',
                       docHistoryTab   : '//*[@id="tab_9_active"]/div',
                       docHistoryPage  : '//*[@id="page_9"]',
                       docInfHeader:'//*[@id="mainwrapper"]/tbody/tr/td/form[1]/table/tbody/tr[4]/td/div[1]/div[1]/table/tbody/tr[1]'
                     }, 
                  SR: 
                       {
                       docId       : '//*[@id="lf25489"]',
                       docVendorSRNumber:'//*[@name="vendor_sr_number"]',
                       docEditAreaAdditionalInformation:'//*[@name="additional_information"]',
                       docEditAreaStuffOnly:'//*[@name="staff_only_notes"]',
                       docPriority:'//*/select[@name="priority"]',
                       docCompany  : '//*[@id="lf25419"]',
                       docSummary  : '//*[@id="lf25337"]',
                       docAddInf   : '//*[@id="lf25350"]/table/tbody/tr/td',
                       docStuffOnly: '//*[@id="lf25352"]/table/tbody/tr/td',
                       docInfTable : '//*[@id="page_1"]/div/table/tbody/tr[1]/td',
                       docNewInfTable  : '//*[@id="page_1"]/div/table/tbody/tr[1]' ,
                       docWorkTab   : '//*[@id="tab_1_active"]/div',
                       docDetailTab   : '//*[@id="tab_0_active"]/div',
                       docDetailPage:'//*[@id="page_0"]',
                       docEditSummary:'//*[@id="e_1019"]',
                       docHistoryTab   : '//*[@id="tab_9_active"]/div',
                       docHistoryPage  : '//*[@id="page_9"]',
                       docInfHeader:'//*[@id="mainwrapper"]/tbody/tr/td/form[1]/table/tbody/tr[4]/td/div[1]/div[1]/table/tbody/tr[1]'
                     }, 
                  I: 
                      {

                        docId      : '//*[@id="lf29660"]',
                        docPriority:'//*/select[@name="priority"]',
                        docCompany : '//*[@id="lf29559"]',
                        docSummary  : '//*[@id="lf29494"]',
                        docAddInf   : '//*[@id="lf29488"]/table/tbody/tr/td',
                        docStuffOnly: '//*[@id="lf29493"]/table/tbody/tr/td',
                        docInfTable : '//*[@id="page_1"]/div/table/tbody/tr[3]/td',    
                        docNewInfTable  : '//*[@id="page_1"]/div/table/tbody/tr[3]',
                        docWorkTab   : '//*[@id="tab_1_active"]/div',
                        docDetailTab   : '//*[@id="tab_0_active"]/div',
                        docDetailPage:'//*[@id="page_0"]',
					            	docHistoryTab   : '//*[@id="tab_9_active"]/div',
						            docHistoryPage  : '//*[@id="page_9"]',
                        docEditSummary:'//*[@id="e_1022"]',
                        docInfHeader:'//*[@id="mainwrapper"]/tbody/tr/td/form[1]/table/tbody/tr[4]/td/div[1]/div[1]/table/tbody/tr[1]'
                     }
                };
//*[@id="mainwrapper"]/tbody/tr/td/form[1]/table/tbody/tr[4]/td/div[1]/div[1]/table/tbody/tr[1]
//*[@id="mainwrapper"]/tbody/tr/td/form[1]/table/tbody/tr[4]/td/div[1]/div/table/tbody/tr[1]

var CustomerGroup = {
	Alpha: [
	"ABSciex","Accusort","Alkermes","Alliance Coal","Alumco","Anchor Packaging","AngioDynamics","Aramark","Arbonne","Aspen Tech","Arctic Slope Energy Services, Inc.","Bepensa","Cape Code","Cell Signaling Technology","Cooley","Darigold","Dunkin Brands","Enanta Pharmaceuticals","EnerNoc","Ergotron","Foundation","Hollingsworth and Vose","ICU Medical","InnerWireless","iRobot","ITT","Jackson","Kadant","KBA","Kensington","Lista International","Loomis Armored US.","MasTech","MasterTag","Niagara Bottling","OneGas","Oneok","Oxfam America","PennWell","Personal","Protege","QDX (BIMBO)","RAIT","Ramsey Winch","Range Fuels","Rapid City","RDU","Sterilite","Target","Veristat","VHA","Weight Watchers","Xylem","Zoll","Open Technology Solutions"
	],
	
	Bravo:[
	"Adhesives","Aegerion Pharmaceuticals","AFL Telecommunications","Amarin Pharmaceuticals","Arriva Hospitality","Blackstone","Brightcove Inc","BrightSource","Car Toys","Curis","Danaher Motion","DTS","Dynamex","Farwest Steel","Fonda Argentina","Grupo American Industries","GGU","GI Dynamics","Greatbatch","Grupo Posadas","GSI Group Inc.","Haemonetics","Haemonetics - BMS","HAMTEK","Healthcare Uniform Company","Helix Energy","Hussmann","Infinity Pharmaceuticals","Interactive Data","King Solutions","LiDestri Foods","MathWorks","Mediacom","Mercury Computers","Ogilvy","Orleans Parish Public School Board","Perseid Software","Pitt Plastics","Scripps","Seachange","Segway","Sourcefire","Starent Networks","Sunflower Electric Power","Swett and Crawford Group","Taconic","Tejon","TOSHIBA","Travelport","Viz Media","XenoPort","Unne"
	],
	
	US:[ 	
	  "IRI","PAS Technologies","Plasan North America","State Street Corporation","Ultra Electronics"
	 ],
	 
	 Upgrade : [ "Telair"],
	 
	 FHD : [
	  "Aspen Tech",
      "Car Toys", 	  
      "DTS", 	  
      "Farwest Steel", 	  
      "Haemonetics", 	  
      "MasterTag", 	  
      "Ramsey Winch", 	  
      "Sunflower Electric Power", 	  
      "Healthcare Uniform Company", 	  
      "Starent Networks", 	  
      "Irving Oil", 	  
      "Swett and Crawford Group", 	  
      "GSI Group Inc.", 	  
      "Plasan North America",
      "Hollingsworth and Vose",
      "InnerWireless",  	  
      "Bepensa",  	  
      "Dynamex",  	  
      "Oxfam America",  	  
      "Arbonne",  	  
      "Blackstone",  	  
      "Arriva Hospitality",  	  
      "Helix Energy",  	  
      "AngioDynamics",  	  
      "Hussmann",  	  
      "Tejon",  	  
      "Rapid City",  	  
      "Aegerion Pharmaceuticals",  	  
      "LiDestri Foods" 	  
	 ],
	 
	 Covington: [
	  "Broadcast Music"
	  ,"Burlington Stores"
	  ,"Deckers Outdoor Corp"
	  ,"Dexia Credit Local"
	  ,"Konica Minolta"
	  ,"LG&E and KU Energy"
	  ,"Terracon"
	 ]
	
};


var tochilov  =[1,2,3,4,5].map(function(day){return [day, 5*60-10, 13*60-10];})
var snopok    =[1,2,3,4,5].map(function(day){return [day, 5*60-10, 13*60-10];})
var chikalenko=[1,2,3,4,5].map(function(day){return [day, 8*60-10, 16*60-10];})
var gorodetsky=[1,2,3,4,5].map(function(day){return [day, 8*60-10, 16*60-10];})
var yaschenko =[1,2,3,4,5].map(function(day){return [day, 7*60-10, 15*60-10];})

var DedicatedProjects = [
  { name: "Tochilov, Snopok 13/21", companyes: "Arriva Hospitality, Bepensa, Cooley Group, Grupo American Industries, Grupo Posadas, Interactive Data, RDU, Orleans Parish Public School Board, TOSHIBA, Travelport, XenoPort, UNNE, QDX (BIMBO), Fonda Argentina", timeIntervals: tochilov},
  
   { name: "Zavadich 13/21", companyes: "Weight Watchers", timeIntervals: tochilov},
   { name: "Chikalenko 16/00", companyes: "Aspen Tech, Blackstone", timeIntervals: chikalenko},
   { name: "Gorodetskiy 16/00", companyes: "HaNoemonetics", timeIntervals: gorodetsky},
   { name: "Yaschenko 15/23", companyes: "Sterilite", timeIntervals: yaschenko} 
];

 console.log("Loaded");
 console.groupEnd();
  /**
      Return  object which will be public interface for functions 
      in that module
  */ 	
  return {
   "Xpath"       : Xpath,
   "CustomerGroup" : CustomerGroup,
   "DedicatedProjects" :DedicatedProjects
  };

};

}("opm@inf@string");


