LoadedTextScripts.alert = function(){/*
file='{{pathToFile}}'
excepNum='{{exceptions}}'

tmpFile=tmp.TMP_FILE.txt

lastLines=10000
excep="ORA-($excepNum)"

gFuncBody='(

if [ -e $tmpFile ]; then
  goTo=$1;
  set `wc -l $tmpFile`;
  linesCount=$1;

 vi  +"$(( $linesCount<$lastLines?$goTo:$linesCount-$lastLines+$goTo ))" $tmpFile;

else
 goTo=$1;
 set `wc -l $file`;
 linesCount=$1;

 vi  +"$(( $linesCount<$lastLines?$goTo:$linesCount-$lastLines+$goTo ))" $file;
fi

)'


awkProg=$'

BEGIN {
 wasError= 0
 buffer= ""
}

END {
if (wasError ) print buffer 
}


/^(Mon|Wed|Tue|Thu|Fri|Sat|Sun) /{
if (wasError ) print buffer
buffer=""
wasError= 0
}

{ 
 buffer =buffer "\\n" $0
} 

/ORA-/ && $0 !~ /excep/ { 
wasError = 1
}

'


vFuncBody='(

awkProg=${awkProg//excep/$excep};
clear;
echo "$awkProg";

if [ -e $tmpFile ]; then
 cat $tmpFile |  awk "$awkProg"
 rm ./$tmpFile
else
 tail -$lastLines $file |  awk "$awkProg"
fi

)'

vsFuncBody='(
clear;
echo Positions in last $lastLines lines;
echo ===================================;

if [ -e $tmpFile ]; then
 cat $tmpFile | grep  -n "ORA-" | egrep -v -e "$excep"
else
 tail -$lastLines $file | grep  -n "ORA-" | egrep -v -e "$excep"
fi

echo ===================================;

echo PMON processes;
ps -ef | grep pmon;
echo ===================================;
echo Current Date;
date;
echo ===================================;
)'

viZFuncBody='(
if [ X = X$1 ]; then
 compress -cd $file > $tmpFile
else
 compress -cd `dirname $file`/$1 > $tmpFile
fi
)'

viTailFuncBody='(
if [ X = X$1 ]; then
 tail -$lastLines $file > $tmpFile
else
 tail -$lastLines `dirname $file`/$1 > $tmpFile
fi
)'

if [ X != X`echo $0|grep ksh` ];
then
  f=""
 else
  f="function"
fi

genFunc=$"
 $f g()      $gFuncBody;
 $f vs()     $vsFuncBody;
 $f v()      $vFuncBody;
 $f genZ()    $viZFuncBody;
 $f genTail() $viTailFuncBody;"

eval "$genFunc"

shell=$"
================
Current shell: $SHELL
"

usage=$'
================
Commands list:
================
h  -  this help message
c  -  clear screen
v  -  detailed view of errors from alert log
vs -  short view errors from aler log
g  -  go to line in alert log
gb -  grep backup processes
gp -  grep background processes
genTail - create tmp file as tail of file (viTail (<file in logs dir>|[$file]) )
genZ    - create tmp file as uncompressed file (viZ (<file in logs dir>|[$file]) )
viTmp  - vi of tmp file
logs   - ls of alert logs directory
'
clear="clear"
grepBack="ps -ef | egrep '(hot|cold|back|fusion|sh)'"
grepProc="ps -ef | egrep '(cjq|qmnc|mmnl|mmon|j00)'"

alias gb="$clear; echo \"$grepBack\" ; $grepBack"
alias gp="$clear; echo \"$grepProc\" ; $grepProc"
alias c="clear"
alias h="echo \"$usage\""
alias viTmp="vi $tmpFile ; rm ./$tmpFile"
alias logs="ls -l `dirname $file` | grep alert"

export PS1='$LOGNAME@$HOST:$PWD<$ORACLE_SID>';
clear;
echo "$shell" "$usage" 

*/}.toString().replace(/^function \(\){\/\*/,"").replace(/\*\/}/,"");


LoadedTextScripts.database = function(){/*


findEnvFile()
 {
  envFiles=()
  count=1
 
 for i in *.env
  do
   envFiles[$((count++))]=$i 
  done
 }

dumpEnvFile()
 {
  count=1
  for i in ${!envFiles[*]}
   do
    echo "$i: ${envFiles[$i]}"
  done
 }

chooseEnvFile()
{
 if [ -z "$1" ]; then
  
  clear
  echo "$script";
  findEnvFile
  dumpEnvFile
  echo 'Please select index of environment file from list above: go <index> '
 
 else
   
   envFile="${envFiles["$1"]}"
   
   if [ -z "$envFile" ]; then
     echo "Wrong index of file in list"
   else 
    echo "Loading $envFile"
    cat $envFile | more
     . ./$envFile
   fi

 fi
}

autoSelect()
{
tmp=tmp.file.sql;
echo  "$script"> $tmp;
clear;  sqlplus '/as sysdba' @$tmp | more ; rm $tmp;
} 

script=$'
prompt ***INSTANSE NAME***
select instance_name,status from v$instance;
prompt ***MAX SESSION COUNT***
select value from v$parameter where name =\'sessions\';
prompt ***CURRENT SESSION COUNT***
select count(*) from v$session;
prompt ***CURRENT PROCESS COUNT***
select count(*) from v$process;
prompt ***TABLESPACES***
select * from DBA_TABLESPACE_USAGE_METRICS;
exit
'

alias go=chooseEnvFile
alias ggg=autoSelect
alias gogo='sqlplus "/ as sysdba"'

*/}.toString().replace(/^function \(\){\/\*/,"").replace(/\*\/}/,"");


LoadedTextScripts.sisA = function(){/*
:8888/SiteScope/cgi/go.exe/SiteScope?writeName=monSummary&sort=_class&column=_name+300&writeType=comma&isSwingContext=true&_targetList=_master&operation=show&closeLink=true&locale=en_US&writeExport=&showParameters=on&sortorder=ascend&context=&page=monitorSummary&showLink=false&_class=ReportMonitor&showClose=true
*/}.toString().replace(/^function \(\){\/\*/,"").replace(/\*\/}/,"").trim();


LoadedTextScripts.sisB = function(){/*
var rows = [].slice.call(document.querySelectorAll('tr'));

rows = rows.filter(function(elt)
   {
    var name = elt.children[0].innerText;
    var isAlert = name.indexOf("database_alert") !== -1;
    return isAlert;
  });

var trySelectOrNull = function (obj, i)
{
  return obj && obj[i] || null;
}
  
var data = rows.map(function(elt)
  { 
    
  
  var name = elt.children[0].innerText;
  var data = elt.children[1].innerText;
  
  var path = trySelectOrNull((/^Log File Pathname:(.*)/gm).exec(data),1) ;
  var contentMatch = trySelectOrNull((/^Content Match:(.*)/gm).exec(data),1);

  return {"name":name, "path":path, "reg":contentMatch};

  });
  
  console.clear();
  JSON.stringify(data,null,1);
  
  */}.toString().replace(/^function \(\){\/\*/,"").replace(/\*\/}/,"");

  LoadedTextScripts.cmdToPutty = function(){/*


set customer=__customer__
set windowTitle=__windowTitle__
set hostname=__hostname__
set ticketNumber=__ticketNumber__
set backGroundColor=__backGroundColor__


set h_drive=h

set putty=%h_drive%:\Utils\Windows\putty

set putty_logs=%h_drive%:\PuttyLogs
mkdir "%putty_logs%"

set putty_log_folder=%putty_logs%\%customer%
mkdir "%putty_log_folder%"

set tmpTime=%TIME:~0,-3%
set tmpTime1=%TIME: =_%
set tmpTime2=%tmpTime1::=_%
set tmpDate1=%DATE: =_%
set tmpDate2=%tmpDate1:/=_%
set tmpFileName=putty_log_of_%ticketnumber%@%hostname%_at_%tmpTime2%_%tmpDate2%
set tmpSession=%putty_log_folder%\%tmpFileName%


echo SerialFlowControl\1\>> "%tmpSession%"
echo SerialParity\0\>> "%tmpSession%"
echo SerialStopHalfbits\2\>> "%tmpSession%"
echo SerialDataBits\8\>> "%tmpSession%"
echo SerialSpeed\9600\>> "%tmpSession%"
echo SerialLine\COM1\>> "%tmpSession%"
echo ShadowBoldOffset\1\>> "%tmpSession%"
echo ShadowBold\0\>> "%tmpSession%"
echo WideBoldFontHeight\1309936\>> "%tmpSession%"
echo WideBoldFontCharSet\20123880\>> "%tmpSession%"
echo WideBoldFontIsBold\20123880\>> "%tmpSession%"
echo WideBoldFont\\>> "%tmpSession%"
echo WideFontHeight\1309936\>> "%tmpSession%"
echo WideFontCharSet\20123880\>> "%tmpSession%"
echo WideFontIsBold\20123880\>> "%tmpSession%"
echo WideFont\\>> "%tmpSession%"
echo BoldFontHeight\1309936\>> "%tmpSession%"
echo BoldFontCharSet\20123880\>> "%tmpSession%"
echo BoldFontIsBold\20123880\>> "%tmpSession%"
echo BoldFont\\>> "%tmpSession%"
echo ScrollbarOnLeft\0\>> "%tmpSession%"
echo LoginShell\1\>> "%tmpSession%"
echo StampUtmp\1\>> "%tmpSession%"
echo BugRekey2\0\>> "%tmpSession%"
echo BugPKSessID2\0\>> "%tmpSession%"
echo BugRSAPad2\0\>> "%tmpSession%"
echo BugDeriveKey2\0\>> "%tmpSession%"
echo BugHMAC2\0\>> "%tmpSession%"
echo BugRSA1\0\>> "%tmpSession%"
echo BugPlainPW1\0\>> "%tmpSession%"
echo BugIgnore1\0\>> "%tmpSession%"
echo PortForwardings\\>> "%tmpSession%"
echo RemotePortAcceptAll\0\>> "%tmpSession%"
echo LocalPortAcceptAll\0\>> "%tmpSession%"
echo X11AuthType\1\>> "%tmpSession%"
echo X11Display\\>> "%tmpSession%"
echo X11Forward\0\>> "%tmpSession%"
echo BlinkText\0\>> "%tmpSession%"
echo BCE\1\>> "%tmpSession%"
echo LockSize\0\>> "%tmpSession%"
echo EraseToScrollback\1\>> "%tmpSession%"
echo ScrollOnDisp\1\>> "%tmpSession%"
echo ScrollOnKey\0\>> "%tmpSession%"
echo ScrollBarFullScreen\0\>> "%tmpSession%"
echo ScrollBar\1\>> "%tmpSession%"
echo CapsLockCyr\0\>> "%tmpSession%"
echo Printer\\>> "%tmpSession%"
echo UTF8Override\1\>> "%tmpSession%"
echo CJKAmbigWide\0\>> "%tmpSession%"
echo LineCodePage\\>> "%tmpSession%"
echo Wordness224\2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2\>> "%tmpSession%"
echo Wordness192\2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2\>> "%tmpSession%"
echo Wordness160\1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1\>> "%tmpSession%"
echo Wordness128\1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1\>> "%tmpSession%"
echo Wordness96\1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1\>> "%tmpSession%"
echo Wordness64\1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,2\>> "%tmpSession%"
echo Wordness32\0,1,2,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1\>> "%tmpSession%"
echo Wordness0\0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0\>> "%tmpSession%"
echo MouseOverride\1\>> "%tmpSession%"
echo RectSelect\0\>> "%tmpSession%"
echo MouseIsXterm\0\>> "%tmpSession%"
echo PasteRTF\0\>> "%tmpSession%"
echo RawCNP\0\>> "%tmpSession%"
echo Colour21\255,255,255\>> "%tmpSession%"
echo Colour20\187,187,187\>> "%tmpSession%"
echo Colour19\85,255,255\>> "%tmpSession%"
echo Colour18\0,187,187\>> "%tmpSession%"
echo Colour17\255,85,255\>> "%tmpSession%"
echo Colour16\187,0,187\>> "%tmpSession%"
echo Colour15\85,85,255\>> "%tmpSession%"
echo Colour14\0,0,187\>> "%tmpSession%"
echo Colour13\255,255,85\>> "%tmpSession%"
echo Colour12\187,187,0\>> "%tmpSession%"
echo Colour11\85,255,85\>> "%tmpSession%"
echo Colour10\0,187,0\>> "%tmpSession%"
echo Colour9\255,85,85\>> "%tmpSession%"
echo Colour8\187,0,0\>> "%tmpSession%"
echo Colour7\85,85,85\>> "%tmpSession%"
echo Colour6\0,0,0\>> "%tmpSession%"
echo Colour5\0,0,0\>> "%tmpSession%"
echo Colour4\0,0,0\>> "%tmpSession%"
echo Colour3\%backGroundColor%\>> "%tmpSession%"
echo Colour2\%backGroundColor%\>> "%tmpSession%"
echo Colour1\0,0,0\>> "%tmpSession%"
echo Colour0\0,0,0\>> "%tmpSession%"
echo BoldAsColour\1\>> "%tmpSession%"
echo Xterm256Colour\1\>> "%tmpSession%"
echo ANSIColour\1\>> "%tmpSession%"
echo TryPalette\0\>> "%tmpSession%"
echo UseSystemColours\0\>> "%tmpSession%"
echo FontVTMode\4\>> "%tmpSession%"
echo FontQuality\0\>> "%tmpSession%"
echo FontHeight\10\>> "%tmpSession%"
echo FontCharSet\0\>> "%tmpSession%"
echo FontIsBold\0\>> "%tmpSession%"
echo Font\Courier%20New\>> "%tmpSession%"
echo TermHeight\24\>> "%tmpSession%"
echo TermWidth\80\>> "%tmpSession%"
echo WinTitle\%windowTitle%\>> "%tmpSession%"
echo WinNameAlways\1\>> "%tmpSession%"
echo DisableBidi\0\>> "%tmpSession%"
echo DisableArabicShaping\0\>> "%tmpSession%"
echo LFImpliesCR\0\>> "%tmpSession%"
echo AutoWrapMode\1\>> "%tmpSession%"
echo DECOriginMode\0\>> "%tmpSession%"
echo ScrollbackLines\200\>> "%tmpSession%"
echo BellOverloadS\5000\>> "%tmpSession%"
echo BellOverloadT\2000\>> "%tmpSession%"
echo BellOverloadN\5\>> "%tmpSession%"
echo BellOverload\1\>> "%tmpSession%"
echo BellWaveFile\\>> "%tmpSession%"
echo BeepInd\0\>> "%tmpSession%"
echo Beep\1\>> "%tmpSession%"
echo BlinkCur\0\>> "%tmpSession%"
echo CurType\0\>> "%tmpSession%"
echo WindowBorder\1\>> "%tmpSession%"
echo SunkenEdge\0\>> "%tmpSession%"
echo HideMousePtr\0\>> "%tmpSession%"
echo FullScreenOnAltEnter\0\>> "%tmpSession%"
echo AlwaysOnTop\0\>> "%tmpSession%"
echo Answerback\PuTTY\>> "%tmpSession%"
echo LocalEdit\2\>> "%tmpSession%"
echo LocalEcho\2\>> "%tmpSession%"
echo TelnetRet\1\>> "%tmpSession%"
echo TelnetKey\0\>> "%tmpSession%"
echo CtrlAltKeys\1\>> "%tmpSession%"
echo ComposeKey\0\>> "%tmpSession%"
echo AltOnly\0\>> "%tmpSession%"
echo AltSpace\0\>> "%tmpSession%"
echo AltF4\1\>> "%tmpSession%"
echo NetHackKeypad\0\>> "%tmpSession%"
echo ApplicationKeypad\0\>> "%tmpSession%"
echo ApplicationCursorKeys\0\>> "%tmpSession%"
echo NoRemoteCharset\0\>> "%tmpSession%"
echo NoDBackspace\0\>> "%tmpSession%"
echo RemoteQTitleAction\1\>> "%tmpSession%"
echo NoRemoteWinTitle\0\>> "%tmpSession%"
echo NoAltScreen\0\>> "%tmpSession%"
echo NoRemoteResize\0\>> "%tmpSession%"
echo NoMouseReporting\0\>> "%tmpSession%"
echo NoApplicationCursors\0\>> "%tmpSession%"
echo NoApplicationKeys\0\>> "%tmpSession%"
echo LinuxFunctionKeys\0\>> "%tmpSession%"
echo RXVTHomeEnd\0\>> "%tmpSession%"
echo BackspaceIsDelete\1\>> "%tmpSession%"
echo PassiveTelnet\0\>> "%tmpSession%"
echo RFCEnviron\0\>> "%tmpSession%"
echo RemoteCommand\\>> "%tmpSession%"
echo PublicKeyFile\\>> "%tmpSession%"
echo SSH2DES\0\>> "%tmpSession%"
echo SshProt\2\>> "%tmpSession%"
echo SshNoShell\0\>> "%tmpSession%"
echo AuthKI\1\>> "%tmpSession%"
echo AuthTIS\0\>> "%tmpSession%"
echo SshNoAuth\0\>> "%tmpSession%"
echo RekeyBytes\1G\>> "%tmpSession%"
echo RekeyTime\60\>> "%tmpSession%"
echo KEX\dh-gex-sha1,dh-group14-sha1,dh-group1-sha1,WARN\>> "%tmpSession%"
echo Cipher\aes,blowfish,3des,WARN,arcfour,des\>> "%tmpSession%"
echo ChangeUsername\0\>> "%tmpSession%"
echo AgentFwd\0\>> "%tmpSession%"
echo TryAgent\1\>> "%tmpSession%"
echo Compression\0\>> "%tmpSession%"
echo NoPTY\0\>> "%tmpSession%"
echo LocalUserName\\>> "%tmpSession%"
echo UserName\\>> "%tmpSession%"
echo Environment\\>> "%tmpSession%"
echo ProxyTelnetCommand\connect%20%25host%20%25port%5Cn\>> "%tmpSession%"
echo ProxyPassword\\>> "%tmpSession%"
echo ProxyUsername\\>> "%tmpSession%"
echo ProxyPort\80\>> "%tmpSession%"
echo ProxyHost\proxy\>> "%tmpSession%"
echo ProxyMethod\0\>> "%tmpSession%"
echo ProxyLocalhost\0\>> "%tmpSession%"
echo ProxyDNS\1\>> "%tmpSession%"
echo ProxyExcludeList\\>> "%tmpSession%"
echo AddressFamily\0\>> "%tmpSession%"
echo TerminalModes\INTR=A,QUIT=A,ERASE=A,KILL=A,EOF=A,EOL=A,EOL2=A,START=A,STOP=A,SUSP=A,DSUSP=A,REPRINT=A,WERASE=A,LNEXT=A,FLUSH=A,SWTCH=A,STATUS=A,DISCARD=A,IGNPAR=A,PARMRK=A,INPCK=A,ISTRIP=A,INLCR=A,IGNCR=A,ICRNL=A,IUCLC=A,IXON=A,IXANY=A,IXOFF=A,IMAXBEL=A,ISIG=A,ICANON=A,XCASE=A,ECHO=A,ECHOE=A,ECHOK=A,ECHONL=A,NOFLSH=A,TOSTOP=A,IEXTEN=A,ECHOCTL=A,ECHOKE=A,PENDIN=A,OPOST=A,OLCUC=A,ONLCR=A,OCRNL=A,ONOCR=A,ONLRET=A,CS7=A,CS8=A,PARENB=A,PARODD=A,\>> "%tmpSession%"
echo TerminalSpeed\38400,38400\>> "%tmpSession%"
echo TerminalType\xterm\>> "%tmpSession%"
echo TCPKeepalives\0\>> "%tmpSession%"
echo TCPNoDelay\1\>> "%tmpSession%"
echo PingIntervalSecs\0\>> "%tmpSession%"
echo PingInterval\0\>> "%tmpSession%"
echo WarnOnClose\1\>> "%tmpSession%"
echo CloseOnExit\1\>> "%tmpSession%"
echo PortNumber\22\>> "%tmpSession%"
echo Protocol\ssh\>> "%tmpSession%"
echo SSHLogOmitData\0\>> "%tmpSession%"
echo SSHLogOmitPasswords\1\>> "%tmpSession%"
echo LogFlush\1\>> "%tmpSession%"
echo LogFileClash\-1\>> "%tmpSession%"
echo LogType\1\>> "%tmpSession%"
echo LogFileName\%h_drive%:%5CPuttyLogs%5C%customer%%5C%tmpFileName%.log\>> "%tmpSession%"
echo HostName\%hostname%\>> "%tmpSession%"
echo Present\1\>> "%tmpSession%"

"%h_drive%:\Utils\Windows\Dos2Unix\dos2unix" -n "%tmpSession%" "%putty%\sessions\tmpSessionFile"

set tmpNoteFile=%h_drive%:\PuttyLogs\%customer%\note_%tmpFileName%


doskey go=start "" /min "%putty%\putty.exe" -load tmpSessionFile
doskey es=start "" /min  notepad "%putty%\sessions\tmpSessionFile"
doskey en=copy "%h_drive%:\Chrysalis\Notes\templateNote.txt" "%tmpNoteFile%.txt" $T start "" /min  notepad "%tmpNoteFile%.txt"
doskey enl=copy "%h_drive%:\Notes\templateNote.txt" "%tmpNoteFile%.local.txt" $T start "" /min  notepad "%tmpNoteFile%.local.txt"
doskey np=start "" /min  notepad

doskey g=start "" /min "%putty%\putty.exe" -load tmpSessionFile $t copy "%h_drive%:\Chrysalis\Notes\templateNote.txt" "%tmpNoteFile%.txt" $T start "" /min  notepad "%tmpNoteFile%.txt" $t start "" /min  notepad

set rar="%h_drive%:\Utils\Windows\WinRAR\rar.exe"  a -ep

doskey logcrar=%rar% "%h_drive%:\TicketAttachment\%tmpFileName%.rar" "%h_drive%:\PuttyLogs\%customer%\%tmpFileName%_c.log" 
doskey logc=copy  "%h_drive%:\PuttyLogs\%customer%\%tmpFileName%_c.log"  "%h_drive%:\TicketAttachment\%tmpFileName%_c.log" 
doskey lograw=copy  "%h_drive%:\PuttyLogs\%customer%\%tmpFileName%.log"  "%h_drive%:\TicketAttachment\%tmpFileName%.log" 
doskey q=shutdown /l
doskey pscp=mkdir h:\transfer\%ticketNumber%  $T "%putty%\pscp.exe" -r  $1@$2:/tmp/$3 h:\transfer\%ticketNumber%
doskey pscpt=mkdir h:\transfer\%ticketNumber% $T "%putty%\pscp.exe" -r  $1@$2:/tmp/%ticketNumber% h:\transfer\%ticketNumber%
doskey remd=doskey /macros $B find "$1"
doskey t=date /t $T time /t

color f2

*/}.toString().replace(/^function \(\){\/\*/,"").replace(/\*\/}/,"").trim();

