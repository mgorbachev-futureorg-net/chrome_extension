var Data =[ 
{
  "name": "AEGDEV_database_alert_log_on_aegdb201",
  "path": " /aeg/dev/db/diag/rdbms/aegdev/AEGDEV/trace/alert_AEGDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AEGTST_database_alert_log_on_aegdb201",
  "path": " /aeg/tst/db/diag/rdbms/aegtst/AEGTST/trace/alert_AEGTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AEGUAT_database_alert_log_on_aegdb201",
  "path": " /aeg/uat/db/diag/rdbms/aeguat/AEGUAT/trace/alert_AEGUAT.log ",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AEGPRD_database_alert_log_on_aegdb101",
  "path": " /aeg/prd/db/diag/rdbms/aegprd/AEGPRD/trace/alert_AEGPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|1466)\\d+/"
 },
 {
  "name": "AEGOAMT_database_alert_log_on_aegdb201",
  "path": " /aeg/oamt/db/diag/rdbms/aegoamt/AEGOAMT/trace/alert_AEGOAMT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|00445)\\d+/"
 },
 {
  "name": "AEGOAMP_database_alert_log_on_aegdb101",
  "path": " /aeg/oamp/db/diag/rdbms/aegoamp/AEGOAMP/trace/alert_AEGOAMP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|00445)\\d+/"
 },
{
  "name": "DOBI_database_alert_log_on_naaobi-dev01",
  "path": " /oracle/admin/dobi/bdump/alert_dobi.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DTRC_database_alert_log_on_naaobi-dev01",
  "path": " /oracle/admin/dtrc/bdump/alert_dtrc.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PPK_database_alert_log_on_naaobi-dev01",
  "path": " /oracle/admin/ppk/bdump/alert_ppk.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "POBI_database_alert_log_on_naaobi-prd01",
  "path": " /oracle/admin/pobi/bdump/alert_pobi.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PTRC_database_alert_log_on_naaobi-prd01",
  "path": " /oracle/admin/ptrc/bdump/alert_ptrc.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "P850_database_alert_log_on_naaorap1",
  "path": " /oa_afl_prdb/oraadmin/p850/bdump/alert_p850.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLFDMD_database_alert_log_on_aflhypdb01.dibos02.di-cloud.com",
  "path": " /afl/dev/db/diag/rdbms/aflfdmd/AFLFDMD/trace/alert_AFLFDMD.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLHFMD_database_alert_log_on_aflhypdb01.dibos02.di-cloud.com",
  "path": " /afl/dev/db/diag/rdbms/aflhfmd/AFLHFMD/trace/alert_AFLHFMD.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLHYPD_database_alert_log_on_aflhypdb01.dibos02.di-cloud.com",
  "path": " /afl/dev/db/diag/rdbms/aflhypd/AFLHYPD/trace/alert_AFLHYPD.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLFDMP_database_alert_log_on_aflhypdb11.dibos02.di-cloud.com",
  "path": " /afl/prd/db/diag/rdbms/aflfdmp/AFLFDMP/trace/alert_AFLFDMP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLHFMP_database_alert_log_on_aflhypdb11.dibos02.di-cloud.com",
  "path": " /afl/prd/db/diag/rdbms/aflhfmp/AFLHFMP/trace/alert_AFLHFMP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLHYPP_database_alert_log_on_aflhypdb11.dibos02.di-cloud.com",
  "path": " /afl/prd/db/diag/rdbms/aflhypp/AFLHYPP/trace/alert_AFLHYPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLBIWD_database_alert_log_on_aflobidb01",
  "path": " /afl/dev/db/diag/rdbms/aflbiwd/AFLBIWD/trace/alert_AFLBIWD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLBIWT_database_alert_log_on_aflobidb01",
  "path": " /afl/tst/db/diag/rdbms/aflbiwt/AFLBIWT/trace/alert_AFLBIWT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLBIWP_database_alert_log_on_aflobidb11.dibos02.di-cloud.com",
  "path": " /afl/prd/db/diag/rdbms/aflbiwp/AFLBIWP/trace/alert_AFLBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|1652)\\d+/"
 },
 {
  "name": "AFLTAD_database_alert_log_on_aflhypdb01.dibos02.di-cloud.com",
  "path": " /afl/tad/db/diag/rdbms/afltad/AFLTAD/trace/alert_AFLTAD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLTAT_database_alert_log_on_aflhypdb01.dibos02.di-cloud.com",
  "path": " /afl/tat/db/diag/rdbms/afltat/AFLTAT/trace/alert_AFLTAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLTAP_database_alert_log_on_afltadb11.dibos02.di-cloud.com",
  "path": " /afl/tap/db/diag/rdbms/afltap/AFLTAP/trace/alert_AFLTAP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AFLBOX_database_alertlog_on_afldb01",
  "path": null,
  "reg": null
 },
 {
  "name": "AFLDEV_database_alertlog_on_afldb01",
  "path": null,
  "reg": null
 },
 {
  "name": "AFLSTG_database_alertlog_on_afldb02",
  "path": null,
  "reg": null
 },
 {
  "name": "AFLPRD_database_alertlog_on_afldb11",
  "path": null,
  "reg": null
 },
{
  "name": "IPRD_database_alert_log_on_ptcrebsdb0p.arlp.com",
  "path": " /iprd/orabase/diag/rdbms/iprd/iprd/trace/alert_iprd.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIEP_database_alert_log_on_ptcrbiedb1p.arlp.com",
  "path": " /biep/db/dump/01/diag/rdbms/biep/biep/trace/alert_biep.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OIDP_database_alert_log_on_ptcrebsoid0p.arlp.com",
  "path": " /oidp/oracle/diag/rdbms/oidp/oidp/trace/alert_oidp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FDDP_database_alert_log_on_ptcrfdddb1p.arlp.com",
  "path": " /fddp/oracle/diag/rdbms/fddp/fddp/trace/alert_fddp.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ODWP_database_alert_log_on_ptcrodwdb0p.arlp.com",
  "path": " /odwp/db/dump/01/diag/rdbms/odwp/odwp/trace/alert_odwp.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "QUOP_database_alert_log_on_ptcrquodb1p.arlp.com",
  "path": " /quop/db/admin/quop/bdump/alert_quop.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "RMXP_database_alert_log_on_ptcrrmxdb0p.arlp.com",
  "path": " /rmxp/oracle/diag/rdbms/rmxp/rmxp/trace/alert_rmxp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TBSP_database_alert_log_on_ptcrtbsdb1p.arlp.com",
  "path": " /tbsp/db/dump/01/diag/rdbms/tbsp/tbsp/trace/alert_tbsp.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IPRD_database_alert_log_on_ptcrebsdb1p.arlp.com",
  "path": " /iprd/orabase/diag/rdbms/iprd/iprd/trace/alert_iprd.log ",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OIDP_database_alert_log_on_ptcrebsoid1p.arlp.com",
  "path": " /oidp/oracle/admin/oidp/bdump/alert_oidp.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TBST_database_alert_log_on_ptcrtbsdb1t.arlp.com",
  "path": " /tbst/db/dump/01/diag/rdbms/tbst/tbst/trace/alert_tbst.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TEST1_database_alert_log_on_stlcorpdb2",
  "path": " /u01/oracle/test1/test1db/diag/rdbms/test1/test1/trace/alert_test1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DEV1_database_alert_log_on_stlcorpdb3",
  "path": " /u01/oracle/dev1/diag/rdbms/dev1/dev1/trace/alert_dev1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PROD1_database_alert_log_on_stlcorpdb1",
  "path": " /u01/oracle/prod1/prod1db/11.2.0.3/db/admin/prod1_stlcorpdb1/diag/rdbms/prod1/prod1/trace/alert_prod1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "ANGAGLD _database_alert_log_on_angagldb201",
  "path": " /ang/agld/db/diag/rdbms/angagld/ANGAGLD/trace/alert_ANGAGLD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGAGLQ_database_alert_log_on_angagldb201",
  "path": " /ang/aglq/db/diag/rdbms/angaglq/ANGAGLQ/trace/alert_ANGAGLQ.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGAGLP_database_alert_log_on_angagldb101",
  "path": " /ang/aglp/db/diag/rdbms/angaglp/ANGAGLP/trace/alert_ANGAGLP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGDEV_database_alert_log_on_angdb201",
  "path": " /ang/dev/db/tech_st/diag/rdbms/angdev/ANGDEV/trace/alert_ANGDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGQA_database_alert_log_on_angdb201",
  "path": " /ang/qa/db/tech_st/diag/rdbms/angqa/ANGQA/trace/alert_ANGQA.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGSBX_database_alert_log_on_angdb201",
  "path": " /ang/sbx/db/tech_st/diag/rdbms/angsbx/ANGSBX/trace/alert_ANGSBX.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGPRD_database_alert_log_on_angdb101",
  "path": " /ang/prd/db/tech_st/diag/rdbms/angprd/ANGPRD/trace/alert_ANGPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGPRD_DR_database_alert_log_on_angdb101.slc01.di-cloud.com",
  "path": " /ang/prd/db/tech_st/diag/rdbms/angstb/ANGPRD/trace/alert_ANGPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGBIWD_database_alert_log_on_angobidb201",
  "path": " /ang/biwd/db/diag/rdbms/angbiwd/ANGBIWD/trace/alert_ANGBIWD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGBIWQ_database_alert_log_on_angobidb201",
  "path": " /ang/biwq/db/diag/rdbms/angbiwq/ANGBIWQ/trace/alert_ANGBIWQ.log ",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ANGBIWP_database_alert_log_on_angobidb101",
  "path": " /ang/biwp/db/diag/rdbms/angbiwp/ANGBIWP/trace/alert_ANGBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "BERMUDA_database_alert_log_on_hqdevora12db",
  "path": " /asp/euat/db/11.2.0.4/admin/BERMUDA_hqdevora12db/diag/rdbms/bermuda/BERMUDA/trace/alert_BERMUDA.log",
  "reg": " /ORA-(?!00445|00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "EBSDEV_database_alert_log_on_hqdevora12db",
  "path": " /asp/dev/db/diag/rdbms/ebsdev/EBSDEV/trace/alert_EBSDEV.log",
  "reg": " /ORA-(?!00445|00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "EBSSUPRT_database_alert_log_on_hqdevora12db",
  "path": " /asp/suprt/db/diag/rdbms/ebssuprt/EBSSUPRT/trace/alert_EBSSUPRT.log",
  "reg": " /ORA-(?!01155|01013|00445|00210|00060|00060|28|18913|3136|03149|03137|609|48913|16037|19624|19504|27040|01157|01110|27037|1109|00333|00334|27069|00227|00202|00604|00448|06512|27052|19510|27045|19624|19504|17502|17500)\\d+/"
 },
 {
  "name": "STJOHN_database_alert_log_on_hqdevora12db",
  "path": " /asp/tst/db/11.2.0.4/admin/STJOHN_hqdevora12db/diag/rdbms/stjohn/STJOHN/trace/alert_STJOHN.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ARUBA_database_alert_log_on_hqprojora12db",
  "path": " /asp/dev/db/11.2.0.4/admin/ARUBA_hqprojora12db/diag/rdbms/aruba/ARUBA/trace/alert_ARUBA.log",
  "reg": " /ORA-(?!00445|00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BAHAMAS_database_alert_log_on_hqprojora12db",
  "path": " /asp/reg/db/diag/rdbms/bahamas/BAHAMAS/trace/alert_BAHAMAS.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "KEYWEST_database_alert_log_on_hqprojora12db",
  "path": " /asp/uat/db/11.2.0.4/admin/KEYWEST_hqprojora12db/diag/rdbms/keywest/KEYWEST/trace/alert_KEYWEST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SUPPORT2_database_alert_log_on_hqprojora12db",
  "path": " /asp/hris/bin/11.2.0.4/admin/SUPPORT2_hqprojora12db/diag/rdbms/support2/SUPPORT2/trace/alert_SUPPORT2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TURKS_database_alert_log_on_hqprojora12db",
  "path": " /asp/sit/db/11.2.0.4/admin/TURKS_hqprojora12db/diag/rdbms/turks/TURKS/trace/alert_TURKS.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CZPROD_database_alert_log_on_hqora12db",
  "path": " /asp/czp/db/diag/rdbms/czprod/CZPROD/trace/alert_CZPROD.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "EBSPROD_database_alert_log_on_hqora12db",
  "path": " /asp/prd/db/diag/rdbms/ebsprod/EBSPROD/trace/alert_EBSPROD.log",
  "reg": " /ORA-(?!12152|03113|01033|01858|01013|16058|00060|00060|28|18913|3136|03149|03137|609|48913|03135|01722|03135|604)\\d+/"
 },
 {
  "name": "INFDEV_database_alert_log_on_hqdevdwdb1.corp.aspentech.com_",
  "path": " /u01/app/oracle/diag/rdbms/infdev/INFDEV/trace/alert_INFDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "INFTST_database_alert_log_on_hqdevdwdb1.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/inftst/INFTST/trace/alert_INFTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWTST_database_alert_log_on_hqdevdwdb1.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/mwtst/MWTST/trace/alert_MWTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WHSEDEV_database_alert_log_on_hqdevdwdb1.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/whsedev/WHSEDEV/trace/alert_WHSEDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WHSETST_database_alert_log_on_hqdevdwdb1.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/whsetst/WHSETST/trace/alert_WHSETST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BODEV_database_alert_log_on_hqdevwhsedb2.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/bodev/BODEV/trace/alert_BODEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BOUAT_database_alert_log_on_hqdevwhsedb2.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/bouat/BOUAT/trace/alert_BOUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DWDEV_database_alert_log_on_hqdevwhsedb2.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/dwdev/DWDEV/trace/alert_DWDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DWUAT_database_alert_log_on_hqdevwhsedb2.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/dwuat/DWUAT/trace/alert_DWUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ODSDEV_database_alert_log_on_hqdevwhsedb2.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/odsdev/ODSDEV/trace/alert_ODSDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ODSUAT_database_alert_log_on_hqdevwhsedb2.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/odsuat/ODSUAT/trace/alert_ODSUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "INFUAT_database_alert_log_on_hquatdwdb1.corp.aspentech.com_",
  "path": " /u01/oracle/prod/proddb/9.2.0/admin/PROD_candeladb1/bdump/alert_PROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WHSEUAT_database_alert_log_on_hquatdwdb1.corp.aspentech.com",
  "path": " /u01/app/oracle/diag/rdbms/whseuat/WHSEUAT/trace/alert_WHSEUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "UPK_database_alert_log_on_\\\\mrprod1",
  "path": " D$\\oracle\\diag\\rdbms\\upk\\upk\\trace\\alert_upk.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SCHEMACQ_database_alert_log_on_hqcqscopdb",
  "path": " /u01/app/oracle/diag/rdbms/schemacq/schemacq/trace/alert_schemacq.log",
  "reg": " /ORA-(?!03135|00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TESTCQ_database_alert_log_on_hqcqscopdb",
  "path": " /u01/app/oracle/diag/rdbms/testcq/testcq/trace/alert_testcq.log",
  "reg": " /ORA-(?!27037|00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PRODCQ_standby_database_alert_log_on_hqdevcqscopdb",
  "path": " /u01/app/oracle/diag/rdbms/prodcq_standby/prodcq/trace/alert_prodcq.log",
  "reg": " /ORA-(?!12537|01034|12537|00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SCHEMACQ_standby_database_alert_log_on_hqdevcqscopdb",
  "path": " /u01/app/oracle/diag/rdbms/schemacq_standby/schemacq/trace/alert_schemacq.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TESTCQ_standby_database_alert_log_on_hqdevcqscopdb",
  "path": " /u01/app/oracle/diag/rdbms/testcq_standby/testcq/trace/alert_testcq.log",
  "reg": " /ORA-(?!12537|01034|00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SCOP5_database_alert_log_on_hqdevscopusdb",
  "path": " /tst/scopsup/db/diag/rdbms/scopsup/SCOP5/trace/alert_SCOP5.log",
  "reg": " /ORA-(?!12012|01089|06512|01089|16037|03113|03135|1652|16058|00060|000060|28|18913|3136|03149|03137|609|48913|04030|03135|3135|04022|04045|27366|27403|06512|28500|02063)\\d+/"
 },
 {
  "name": "SCOP5SB_database_alert_log_on_hqdevscopusdb",
  "path": " /tst/scop5sb/db/diag/rdbms/scop5sb/SCOP5SB/trace/alert_SCOP5SB.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SCOPDEV_database_alert_log_on_hqdevscopusdb",
  "path": " /tst/scopdev/db/diag/rdbms/scopdev/SCOPDEV/trace/alert_SCOPDEV.log",
  "reg": " /ORA-(?!12154|12012|06502|06512|000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "INFPRD_database_alert_log_on_hqdwdb1",
  "path": " /u01/app/oracle/diag/rdbms/infprd/INFPRD/trace/alert_INFPRD.log",
  "reg": " /ORA-(?!00445|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WHSEPRD_database_alert_log_on_hqdwdb1",
  "path": " /u01/app/oracle/diag/rdbms/whseprd/WHSEPRD/trace/alert_WHSEPRD.log",
  "reg": " /ORA-(?!1652|00445|01013|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SCOP5_database_alert_log_on_hqscopusdb",
  "path": " /prd/scop5/db/diag/rdbms/scop5/SCOP5/trace/alert_SCOP5.log",
  "reg": " /ORA-(?!12012|04045|27403|06512|27366|04022|04045|27403|00338|00312|00338|00312|03113|03135|1652|16058|00060|000060|28|18913|3136|03149|03137|609|48913|04030|03135|3135|04022|04045|27366|27403|06512|28500|02063|01089)\\d+/"
 },
 {
  "name": "TAXSTREA_database_alert_log_on_hqtaxstream2",
  "path": " \\\\hqtaxstream2\\D$\\app\\oracle\\diag\\rdbms\\taxstrea\\taxstrea\\trace\\alert_taxstrea.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BOPROD_database_alert_log_on_hqwhsedb2",
  "path": " /u01/app/oracle/diag/rdbms/boprod/BOPROD/trace/alert_BOPROD.log",
  "reg": " /ORA-(?!00445|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DWPRD_database_alert_log_on_hqwhsedb2",
  "path": " /u01/app/oracle/diag/rdbms/dwprd/DWPRD/trace/alert_DWPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ODSPRD_database_alert_log_on_hqwhsedb2",
  "path": " /u01/app/oracle/diag/rdbms/odsprd/ODSPRD/trace/alert_ODSPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WHSEUAT_database_alert_log_on_hquatdwdb1.corp.aspentech.com",
  "path": " /u01/oracle/prod/proddb/9.2.0/admin/PROD_candeladb1/bdump/alert_PROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 }
,
{
  "name": "ASRDEV_database_alert_log_on_acancebsdbd1",
  "path": " /asr/dev/db/11.2.0.3/admin/ASRDEV_acancebsdbd1/diag/rdbms/asrdev/ASRDEV/trace/alert_ASRDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ASRPCH_database_alert_log_on_acancebsdbd2",
  "path": " /asr/pch/db/11.2.0.3/admin/ASRPCH_acancebsdbd2/diag/rdbms/asrpch/ASRPCH/trace/alert_ASRPCH.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ASRTST_database_alert_log_on_acancebsdbd3",
  "path": " /asr/tst/db/11.2.0.3/admin/ASRTST_acancebsdbd3/diag/rdbms/asrtst/ASRTST/trace/alert_ASRTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ASRUAT_database_alert_log_on_acancebsdbs1",
  "path": " /asr/uat/db/11.2.0.3/admin/ASRUAT_acancebsdbs1/diag/rdbms/asruat/ASRUAT/trace/alert_ASRUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FINDEV03_database_alert_log_on_douglas",
  "path": " /app/oracle/admin/FINDEV03/bdump/alert_FINDEV03.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FINDEV04_database_alert_log_on_douglas",
  "path": " /app/oracle/admin/FINDEV04/bdump/alert_FINDEV04.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ASRPRD_database_alert_log_on_acancebsdbp1",
  "path": " /asr/prd/db/tech_st/diag/rdbms/asrprd/ASRPRD/trace/alert_ASRPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ASRPRD_DR_database_alert_log_on_acancebsdrdbp1.asrc.com",
  "path": " /asr/prd/db/tech_st/diag/rdbms/asrprddr/ASRPRD/trace/alert_ASRPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FINPRD01_database_alert_log_on_augustine",
  "path": " /app/oracle/product/FINPRD01/diag/rdbms/finprd01/FINPRD01/trace/alert_FINPRD01.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },

 {
  "name": "BEPDEV_database_alert_log_on_bepdb01.dibos02.di-cloud.com",
  "path": " /bep/dev/db/10.2.0/admin/BEPDEV_bepdb01/bdump/alert_BEPDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPTST_database_alert_log_on_bepdb01.dibos02.di-cloud.com",
  "path": " /bep/tst/db/10.2.0/admin/BEPTST_bepdb01/bdump/alert_BEPTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPEBSD_database_alert_log_on_bepdb201.dibos02.di-cloud.com",
  "path": " /bep/ebsd/db/12.1.0.2/admin/BEPEBSD_bepdb201/diag/rdbms/bepebsd/BEPEBSD/trace/alert_BEPEBSD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPEBST_database_alert_log_on_bepdb201.dibos02.di-cloud.com",
  "path": " /bep/ebst/db/12.1.0.2/admin/BEPEBST_bepdb201/diag/rdbms/bepebst/BEPEBST/trace/alert_BEPEBST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPEBSP_database_alert_log_on_bepdb101.dibos02.di-cloud.com",
  "path": " /bep/ebsp/db/12.1.0.1/admin/BEPEBSP_bepdb101/diag/rdbms/bepebsp/BEPEBSP/trace/alert_BEPEBSP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPPRD_database_alert_log_on_bepdb11.dibos02.di-cloud.com",
  "path": " /bep/prd/db/10.2.0/admin/BEPPRD_bepdb11/bdump/alert_BEPPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPFDMD_database_alert_log_on_bephypdb01.dibos02.di-cloud.com",
  "path": " /bep/dev/ora/db/diag/rdbms/bepfdmd/BEPFDMD/trace/alert_BEPFDMD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPREPD_database_alert_log_on_bephypdb01.dibos02.di-cloud.com",
  "path": " /bep/dev/ora/db/diag/rdbms/beprepd/BEPREPD/trace/alert_BEPREPD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPFDMT_database_alert_log_on_bephypdb02.dibos02.di-cloud.com",
  "path": " /bep/tst/ora/diag/rdbms/bepfdmt/BEPFDMT/trace/alert_BEPFDMT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPREPT_database_alert_log_on_bephypdb02.dibos02.di-cloud.com",
  "path": " /bep/tst/ora/diag/rdbms/beprept/BEPREPT/trace/alert_BEPREPT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPBIWP_database_alert_log_on_bephypdb12.dibos02.di-cloud.com",
  "path": " /bep/prd/bi/db/diag/rdbms/bepbiwp/BEPBIWP/trace/alert_BEPBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPFDMP_database_alert_log_on_bephypdb12.dibos02.di-cloud.com",
  "path": " /bep/prd/ora/db/diag/rdbms/bepfdmp/BEPFDMP/trace/alert_BEPFDMP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPREPP_database_alert_log_on_bephypdb12.dibos02.di-cloud.com",
  "path": " /bep/prd/ora/db/diag/rdbms/beprepp/BEPREPP/trace/alert_BEPREPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPSOAT_database_alert_log_on_bepfmwdb01.dibos02.di-cloud.com",
  "path": " /bep/soat/db/oracle/product/diag/bdump/alert_BEPSOAT.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPSOAP_database_alert_log_on_bepfmwdb11.dibos02.di-cloud.com",
  "path": " /bep/soap/db/oracle/product/diag/bdump/alert_BEPSOAP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BEPTST_database_alert_log_on_bepdb01.dibos02.di-cloud.com",
  "path": " /bep/tst/db/10.2.0/admin/BEPTST_bepdb01/bdump/alert_BEPTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },

 {
  "name": "BEPTST_database_alert_log_on_bepdb01.dibos02.di-cloud.com",
  "path": " /bep/tst/db/10.2.0/admin/BEPTST_bepdb01/bdump/alert_BEPTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 }
,
{
  "name": "TBGDEV_database_alert_log_on_tbgdb01",
  "path": " /tbg/dev/db/diag/rdbms/tbgdev/TBGDEV/trace/alert_TBGDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TBGPCH_database_alert_log_on_tbgdb01",
  "path": " /tbg/pch/db/11.2.0.3/admin/TBGPCH_tbgdb01/diag/rdbms/tbgpch/TBGPCH/trace/alert_TBGPCH.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TBGUAT_database_alert_log_on_tbgdb02",
  "path": " /tbg/uat/db/diag/rdbms/tbguat/TBGUAT/trace/alert_TBGUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TBGYES_database_alert_log_on_tbgdb02",
  "path": " /tbg/yes/db/diag/rdbms/tbgprd/TBGPRD/trace/alert_TBGPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|10917)\\d+/"
 },
 {
  "name": "TBGPRD_database_alert_log_on_ tbgdb11.dibos02.di-cloud.com",
  "path": " /tbg/prd/db/diag/rdbms/tbgprd/TBGPRD/trace/alert_TBGPRD.log",
  "reg": " /ORA-(?!1277|01277|01013|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TBGGRCH_database_alert_log_on_tbgdb01",
  "path": " /tbg/grch/db/diag/rdbms/tbggrch/TBGGRCH/trace/alert_TBGGRCH.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TBGGRCP_database_alert_log_on_tbgdb11.dibos02.di-cloud.com",
  "path": " /tbg/grcp/db/diag/rdbms/tbggrcp/TBGGRCP/trace/alert_TBGGRCP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TBGGRCPDR_database_alert_log_on_tbgdb11r.slc01.di-cloud.com",
  "path": " /tbg/grcp/db/diag/rdbms/tbggrcpdr/TBGGRCP/trace/alert_TBGGRCP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|48180)\\d+/"
 },
 {
  "name": "TBGPRDDR_database_alert_log_on_tbgdb11r.slc01.di-cloud.com",
  "path": " /tbg/prd/db/diag/rdbms/tbgprddr/TBGPRD/trace/alert_TBGPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRIDEV_database_alert_log_on_bridb01",
  "path": " /bri/dev/db/tech_st/11.2.0/admin/BRIDEV_bridb01/diag/rdbms/bridev/BRIDEV/trace/alert_BRIDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/ "
 },
 {
  "name": "BRITST_database_alert_log_on_bridb01",
  "path": " /bri/tst/db/tech_st/11.2.0/admin/BRITST_bridb01/diag/rdbms/britst/BRITST/trace/alert_BRITST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRIPRD_database_alert_log_on_bridb11",
  "path": " /bri/prd/db/tech_st/11.2.0/admin/BRIPRD_bridb11/diag/rdbms/briprd/BRIPRD/trace/alert_BRIPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRIHYPD_database_alert_log_on_brihypdb01",
  "path": " /bri/dev/db/diag/rdbms/brihypd/BRIHYPD/trace/alert_BRIHYPD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRIHYPT_database_alert_log_on_brihypdb02",
  "path": " /bri/tst/db/diag/rdbms/brihypt/BRIHYPT/trace/alert_BRIHYPT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRIHYPP_database_alert_log_on_brihypdb11",
  "path": " /bri/prd/db/diag/rdbms/brihypp/BRIHYPP/trace/alert_BRIHYPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "BSEDEV_database_alert_log_on_bsedb01.dibos02.di-cloud.com",
  "path": " /bse/dev/db/11.2.0.3/admin/BSEDEV_bsedb01/diag/rdbms/bsedev/BSEDEV/trace/alert_BSEDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|1652)\\d+/"
 },
 {
  "name": "BSESTG_database_alert_log_on_bsedb01.dibos02.di-cloud.com",
  "path": " /bse/stg/db/11.2.0.3/admin/BSESTG_bsedb01/diag/rdbms/bsestg/BSESTG/trace/alert_BSESTG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|1652)\\d+/"
 },
 {
  "name": "BSETST_database_alert_log_on_bsedb01.dibos02.di-cloud.com",
  "path": " /bse/tst/db/11.2.0.3/admin/BSETST_bsedb01/diag/rdbms/bsetst/BSETST/trace/alert_BSETST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|1652)\\d+/"
 },
 {
  "name": "BSEPRD_database_alert_log_on_bsedb11.dibos02.di-cloud.com",
  "path": " /bse/prd/db/admin/BSEPRD_bsedb11/diag/rdbms/bseprd/BSEPRD/trace/alert_BSEPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "CSTANL_database_alert_log_on_cstdb01.dibos02.di-cloud.com",
  "path": " /cst/anl/db/11.2.0/admin/CSTANL_cstdb01/diag/rdbms/cstanl/CSTANL/trace/alert_CSTANL.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTUAT_database_alert_log_on_cstdb01.dibos02.di-cloud.com",
  "path": " /cst/uat/db/11.2.0/admin/CSTUAT_cstdb01/diag/rdbms/cstuat/CSTUAT/trace/alert_CSTUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTDEV_database_alert_log_on_cstdb02.dibos02.di-cloud.com",
  "path": " /cst/dev/db/11.2.0/admin/CSTDEV_cstdb02/diag/rdbms/cstdev/CSTDEV/trace/alert_CSTDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|04031|01403)\\d+/"
 },
 {
  "name": "CSTTST_database_alert_log_on_cstdb02.dibos02.di-cloud.com",
  "path": " /cst/tst/db/11.2.0/admin/CSTTST_cstdb02/diag/rdbms/csttst/CSTTST/trace/alert_CSTTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTEUD_database_alert_log_on_cstdb03.dibos02.di-cloud.com",
  "path": " /cst/eud/db/11.2.0/admin/CSTEUD_cstdb03/diag/rdbms/csteud/CSTEUD/trace/alert_CSTEUD.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTEUT_database_alert_log_on_cstdb03.dibos02.di-cloud.com",
  "path": " /cst/eut/db/11.2.0/admin/CSTEUT_cstdb03/diag/rdbms/csteut/CSTEUT/trace/alert_CSTEUT.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTPRD_database_alert_log_on_cstdb11.dibos02.di-cloud.com",
  "path": " /cst/prd/db/11.2.0/admin/CSTPRD_cstdb11/diag/rdbms/cstprd/CSTPRD/trace/alert_CSTPRD.log",
  "reg": " /ORA-(?!02050|03135|02063|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTPRDDR_database_alert_log_on_cstdb11.slc01.di-cloud.com",
  "path": " /cst/prd/db/11.2.0/admin/CSTPRD_cstdb11/diag/rdbms/cstprddr/CSTPRD/trace/alert_CSTPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTATGS_database_alert_log_on_cstatgdb01",
  "path": " /cst/atgs/db/diag/rdbms/cstatgs/CSTATGS/trace/alert_CSTATGS.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTSOAT_database_alert_log_on_cstdb01.dibos02.di-cloud.com",
  "path": " /cst/soat/db/diag/rdbms/cstsoat/CSTSOAT/trace/alert_CSTSOAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIERDWD_database_alert_log_on_cstdb108.dibos02.di-cloud.com",
  "path": " /cst/cryd/db/diag/rdbms/bierdwd/BIERDWD/trace/alert_BIERDWD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTBAMD_database_alert_log_on_cstocsdb201.dibos02.di-cloud.com",
  "path": " /cst/bamd/db/diag/rdbms/cstbamd/CSTBAMD/trace/alert_CSTBAMD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTOCSD_database_alert_log_on_cstocsdb201.dibos02.di-cloud.com",
  "path": " /cst/ocsd/db/diag/rdbms/cstocsd/CSTOCSD/trace/alert_CSTOCSD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTOCSU_database_alert_log_on_cstocsdb201.dibos02.di-cloud.com",
  "path": " /cst/ocsu/db/diag/rdbms/cstocsu/CSTOCSU/trace/alert_CSTOCSU.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PDP2_database_alert_log_on_minchir.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/pdp2/pdp2/trace/alert_pdp2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|06512|00001|12012|20004|06512|12541)\\d+/"
 },
 {
  "name": "PDP3_database_alert_log_on_minchir.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/pdp3/pdp3/trace/alert_pdp3.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|00900|12012|20004|06512|12541)\\d+/"
 },
 {
  "name": "PDPD_database_alert_log_on_minchir.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/pdpd/pdpd/trace/alert_pdpd.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|06512|00001|12012|20004|06512|12541)\\d+/"
 },
 {
  "name": "PDPT_database_alert_log_on_minchir.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/pdpt/pdpt/trace/alert_pdpt.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|06512|00001|12012|20004|06512|12541)\\d+/"
 },
 {
  "name": "BIERDWT_database_alert_log_on_orinoco.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/bierdwt/bierdwt/trace/alert_bierdwt.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MSDBD_database_alert_log_on_pleione.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/msdbd/MSDBD/trace/alert_MSDBD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MSDBT_database_alert_log_on_pleione.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/msdbt/MSDBT/trace/alert_MSDBT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WERCS_database_alert_log_on_procyon.cellsignal.com",
  "path": " /u01/app/oracle/product/10.2.0/db_1/admin/wercs/bdump/alert_wercs.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PPAND_database_alert_log_on_rana.cellsignal.com",
  "path": " /u01/app/oracle/product/10.2.0/db_1/admin/PPAND/bdump/alert_ppand.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PDPC_database_alert_log_on_rubicon.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/pdpc/PDPC/trace/alert_PDPC.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PPANP_database_alert_log_on_acherner.cellsignal.com",
  "path": " /u01/app/oracle/admin/PPANP/bdump/alert_PPANP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PPANSP_database_alert_log_on_acherner.cellsignal.com",
  "path": " /u01/app/oracle/admin/PPANSP/bdump/alert_PPANSP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTATGP_database_alert_log_on_cstatgdb11",
  "path": " /cst/atgp/db/diag/rdbms/cstatgp/CSTATGP/trace/alert_CSTATGP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIERDWP_database_alert_log_on_cstdb107.dibos02.di-cloud.com",
  "path": " /cst/cryp/db/diag/rdbms/bierdwp/BIERDWP/trace/alert_BIERDWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTSOAP_database_alert_log_on_cstdb11",
  "path": " /cst/soap/db/diag/rdbms/cstsoap/CSTSOAP/trace/alert_CSTSOAP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CSTOCSP_database_alert_log_on_cstocsdb101.dibos02.di-cloud.com",
  "path": " /cst/ocsp/db/diag/rdbms/cstocsp/CSTOCSP/trace/alert_CSTOCSP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PDPP_database_alert_log_on_murphid.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/pdpp/pdpp/trace/alert_pdpp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|06512|00001|12012)\\d+/"
 },
 {
  "name": "HCSSP_database_alert_log_on_naos.cellsignal.com",
  "path": " /u01/app/oracle/admin/HCSSP/bdump/alert_HCSSP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DBPWHSE_database_alert_log_on_procyon.cellsignal.com",
  "path": " /u01/app/oracle/product/10.2.0/db_1/admin/dbpwhse/bdump/alert_dbpwhse.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ERSRP_database_alert_log_on_procyon.cellsignal.com",
  "path": " /u01/app/oracle/admin/ERSRP/bdump/alert_ERSRP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "JIRADBP_database_alert_log_on_procyon.cellsignal.com",
  "path": " /u01/app/oracle/admin/JIRADBP/bdump/alert_JIRADBP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MSDBP_database_alert_log_on_sham.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/msdbp/MSDBP/trace/alert_MSDBP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIERDWP_database_alert_log_on_turais.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/bierdwp/bierdwp/trace/alert_bierdwp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|00600)\\d+/"
 },
 {
  "name": "BIREPOSP_database_alert_log_on_turais.cellsignal.com",
  "path": " /u01/app/oracle/diag/rdbms/bireposp/bireposp/trace/alert_bireposp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 }
,
 {
  "name": "CRP_database_alert_log_on_acdcrp",
  "path": " /d02/oracrp/crpdb/admin/diag/rdbms/crp/CRP/trace/alert_CRP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DEV_database_alert_log_on_acddev",
  "path": " /d02/oradev/devdb/admin/diag/rdbms/dev/DEV/trace/alert_DEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "INTG1_database_alert_log_on_rcdintg1",
  "path": " /d02/oraint1/intg1db/admin/diag/rdbms/intg1/INTG1/trace/alert_INTG1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "INTG2_database_alert_log_on_rcdintg2",
  "path": " /d02/oraint2/intg2db/admin/diag/rdbms/intg2/INTG2/trace/alert_INTG2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PPDHR_database_alert_log_on_acdpprdhr",
  "path": " /d22/orappdhr/ppdhrdb/admin/diag/rdbms/ppdhr/PPDHR/trace/alert_PPDHR.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PREPROD_database_alert_log_on_acdpreprod",
  "path": " /d02/oratst/preproddb/admin/diag/rdbms/preprod/PREPROD/trace/alert_PREPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PTCH_database_alert_log_on_rcdpatch",
  "path": " /d02/oraptch/ptchdb/admin/diag/rdbms/ptch/PTCH/trace/alert_PTCH.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "UAT_database_alert_log_on_rcduat",
  "path": " /d02/orauat/uatdb/admin/diag/rdbms/uat/UAT/trace/alert_UAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CFGPROD_database_alert_log_on_rcdcfgprod",
  "path": " /d12/oracfgprod/cfgproddb/admin/diag/rdbms/cfgprod/CFGPROD/trace/alert_CFGPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DHROWB_database_alert_log_on_rcddhrowb",
  "path": " /d32/product/diag/rdbms/dhrowb/DHROWB/trace/alert_DHROWB.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PRDHR_database_alert_log_on_rcdprdhr",
  "path": " /d22/oraprdhr/prdhrdb/admin/diag/rdbms/prdhr/PRDHR/trace/alert_PRDHR.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PROD_database_alert_log_on_rcdprod",
  "path": " /d02/oracle/proddb/admin/diag/rdbms/prod/PROD/trace/alert_PROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "DATDEV_database_alert_log_on_datdb01.dataintensity.com",
  "path": " /dat/dev/db/diag/rdbms/datdev/DATDEV/trace/alert_DATDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DATTST_database_alert_log_on_datdb01.dataintensity.com",
  "path": " /dat/tst/db/diag/rdbms/dattst/DATTST/trace/alert_DATTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DATPRD_database_alert_log_on_datdb11.dataintensity.com",
  "path": " sdfsdf",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OAMPRD_database_alert_log_on_dbusoamdb01.dunkinbrands.corp",
  "path": " /oamprd/product/database/diag/rdbms/oamprd/oamprd/trace/alert_oamprd.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PTLPRD_database_alert_log_on_dbusoamdb01.dunkinbrands.corp",
  "path": " /oamprd/product/database/diag/rdbms/ptlprd/ptlprd/trace/alert_ptlprd.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CHEKOV_database_alert_log_on_gaea",
  "path": " /chekov/ckvdb/ckvora/11.2.0.3/admin/CHEKOV_gaea/diag/rdbms/chekov/CHEKOV/trace/alert_CHEKOV.log",
  "reg": " /ORA-(?!16957|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CRP3_database_alert_log_on_gaea",
  "path": " /crp3/ora/cp3or2/11.2.0.3/admin/CRP3_gaea/diag/rdbms/crp3/CRP3/trace/alert_CRP3.log",
  "reg": " /ORA-(?!16957|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "KIRK_database_alert_log_on_gaea",
  "path": " /kirk/krkdb/krkora/11.2.0.3/admin/KIRK_gaea/diag/rdbms/kirk/KIRK/trace/alert_KIRK.log",
  "reg": " /ORA-(?!12012|12008|01017|02063|06512|16957|00060|000060|28|18913|3136|03149|03137|609|48913|12012|04052|00604|01034|02063|06512)\\d+/"
 },
 {
  "name": "R12A_database_alert_log_on_gaea",
  "path": " /r12a/ora/r12aor2/11.2.0.3/admin/R12A_gaea/diag/rdbms/r12a/R12A/trace/alert_R12A.log",
  "reg": " /ORA-(?!16957|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SCOTTY_database_alert_log_on_gaea",
  "path": " /scotty/sctapp/db/11.2.0.4/admin/SCOTTY_gaea/diag/rdbms/scotty/SCOTTY/trace/alert_SCOTTY.log",
  "reg": " /ORA-(?!16957|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SPOCK_database_alert_log_on_gaea",
  "path": " /spock/spcapp/spcora/11.2.0.4/admin/SPOCK_gaea/diag/rdbms/spock/SPOCK/trace/alert_SPOCK.log",
  "reg": " /ORA-(?!16957|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SULU_database_alert_log_on_gaea",
  "path": " /sulu/ora/sulora/11.2.0.3/admin/SULU_gaea/diag/rdbms/sulu/SULU/trace/alert_SULU.log",
  "reg": " /ORA-(?!16957|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PRDFIN_database_alert_log_on_dbusebsdb01",
  "path": " /prdfin/prdapp/db/11.2.0.3/admin/PRDFIN_dbusebsdb01/diag/rdbms/prdfin/PRDFIN/trace/alert_PRDFIN.log",
  "reg": " /ORA-(?!16957||00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OAMTST_database_alert_log_on_dbusoamtstdb01.dunkinbrands.corp",
  "path": " /oamtst/product/database/diag/rdbms/oamtst/oamtst/trace/alert_oamtst.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PTLTST_database_alert_log_on_dbusoamtstdb01.dunkinbrands.corp",
  "path": " /oamtst/product/database/diag/rdbms/ptltst/ptltst/trace/alert_ptltst.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OAMPRD_DR_database_alert_log_on_dbusdrdb2.dunkinbrands.corp",
  "path": " /oamprd/product/database/diag/rdbms/oamprds/oamprd/trace/alert_oamprd.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OAMTST_DR_database_alert_log_on_dbusdrdb2.dunkinbrands.corp",
  "path": " /oamprd/product/database/diag/rdbms/oamtsts/oamtst/trace/alert_oamtst.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PTLPRD_DR_database_alert_log_on_dbusdrdb2.dunkinbrands.corp",
  "path": " /oamprd/product/database/diag/rdbms/ptlprds/ptlprd/trace/alert_ptlprd.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PTLTST_DR_database_alert_log_on_dbusdrdb2.dunkinbrands.corp",
  "path": " /oamprd/product/database/diag/rdbms/ptltsts/ptltst/trace/alert_ptltst.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OIMPRDDB_database_alert_log_on_dbuslnxoimprddb01",
  "path": " /u01/app/oradb/diag/rdbms/oimprddb/OIMPRDDB/trace/alert_OIMPRDDB.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OAMPRD_database_alert_log_on_dbusoamdb01",
  "path": " /oamprd/product/database/diag/rdbms/oamprd/oamprd/trace/alert_oamprd.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PTLPRD_database_alert_log_on_dbusoamdb01",
  "path": " /oamprd/product/database/diag/rdbms/ptlprd/ptlprd/trace/alert_ptlprd.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "FIND_database_alert_log_on_dmxdb02",
  "path": " /dmx/dev/db/diag/diag/rdbms/find/FIND/trace/alert_FIND.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FINT_database_alert_log_on_dmxdb02",
  "path": " /dmx/tst/db/diag/rdbms/fint/FINT/trace/alert_FINT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/ "
 },
 {
  "name": "FINP_database_alert_log_on_dmxdb12",
  "path": " /dmx/prd/db/diag/rdbms/finp/FINP/trace/alert_FINP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "VCPD5_database_alert_log_on_vm5vcpdb",
  "path": " /u01/vcpd5/db/tech_st/12.1.0.2/admin/VCPD5_vm5vcpdb/diag/rdbms/vcpd5/VCPD5/trace/alert_VCPD5.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PROD_database_alert_log_on_db1.ebs.ergotron.com",
  "path": " /u02/oracle/proddb/diag/rdbms/prod/PROD/trace/alert_PROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "VCPP_database_alert_log_on_vcpdb1",
  "path": " /sdb2/vcpdb/db/tech_st/12.1.0.2/admin/VCPP_vcpdb1/diag/rdbms/vcpp/VCPP/trace/alert_VCPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 }
,
{
  "name": "FWSDEV_database_alert_log_on_fwsdb01",
  "path": " /fws/dev/db/11.2.0/admin/FWSDEV_fwsdb01/diag/rdbms/fwsdev/FWSDEV/trace/alert_FWSDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FWSTST_database_alert_log_on_fwsdb01",
  "path": " /fws/tst/db/11.2.0/admin/FWSTST_fwsdb01/diag/rdbms/fwstst/FWSTST/trace/alert_FWSTST.log",
  "reg": " /ORA-(?!07445|48913|12012|12048|04061|04065|06512|01555|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FWSPRD_database_alert_log_on_fwsdb11",
  "path": " /fws/prd/db/diag/rdbms/fwsprdorig/FWSPRD/trace/alert_FWSPRD.log",
  "reg": " /ORA-(?!12012|12048|04061|04065|06512|00060|000060|28|18913|3136|03149|03137|609|48913|07445)\\d+/"
 },
 {
  "name": "FWSPRDDR_database_alert_log_on_fwsdb11r",
  "path": " /fws/prd/db/10.2.0/admin/FWSPRD_fwsdb11r/bdump/alert_FWSPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "FARPRD_database_alert_log_on_fardb11.dibos02.di-cloud.com",
  "path": " /far/prd/db/diag/rdbms/farprd/FARPRD/trace/alert_FARPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FARUPKP_database_alert_log_on_fardb11.dibos02.di-cloud.com",
  "path": " /far/prd/upk/db/diag/rdbms/farupkp/FARUPKP/trace/alert_FARUPKP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GAIDEV_database_alert_log_on_gaibd01",
  "path": " /gai/dev/db/10.2.0/admin/GAIDEV_gaidb01/bdump/alert_GAIDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GAITST_database_alert_log_on_gaibd01",
  "path": " /gai/tst/db/10.2.0/admin/GAITST_gaidb01/bdump/alert_GAITST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TGAII_database_alert_log_on_aiigqaapps1.aiig.com",
  "path": " /u01/install/TGAII/11.2.0/admin/TGAII_aiigqaapps1/diag/rdbms/tgaii/TGAII/trace/alert_TGAII.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DGAII_database_alert_log_on_ebs-dev.aiig.com",
  "path": " /u01/install/DGAII/11.2.0/admin/DGAII_ebs-dev/diag/rdbms/dgaii/DGAII/trace/alert_DGAII.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PGAII2_database_alert_log_on_aiiodaoracle2.aiig.com",
  "path": " /u01/app/oracle/product/11.2.0.4/dbhome_1/admin/PGAII_aiiodaoracle1/diag/diag/rdbms/pgaii/PGAII2/trace/alert_PGAII2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PGAII1_database_alert_log_on_aiiodaoracle1.aiig.com",
  "path": " /u01/app/oracle/product/11.2.0.4/dbhome_1/admin/PGAII_aiiodaoracle1/diag/diag/rdbms/pgaii/PGAII1/trace/alert_PGAII1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GIDDEV_database_alert_log_on_giddb01",
  "path": " /gid/dev/db/tech_st/diag/rdbms/giddev/GIDDEV/trace/alert_GIDDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GIDTST_database_alert_log_on_giddb01",
  "path": " /gid/tst/db/tech_st/11.2.0.3/admin/GIDTST_giddb01/diag/rdbms/gidtst/GIDTST/trace/alert_GIDTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GIDPRD_database_alert_log_on_giddb11",
  "path": " /gid/prd/db/tech_st/diag/rdbms/gidprd/GIDPRD/trace/alert_GIDPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "GBAGRCD_database_alert_log_on_gbagrcdb01.dibos02.di-cloud.com",
  "path": " /gba/grcd/db/diag/rdbms/gbagrcd/GBAGRCD/trace/alert_GBAGRCD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GBAGRCP_database_alert_log_on_gbagrcdb11.dibos02.di-cloud.com",
  "path": " /gba/grcp/db/diag/rdbms/gbagrcp/GBAGRCP/trace/alert_GBAGRCP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GBAAPEXD_database_alert_log_on_gbadb08",
  "path": " /gba/apexd/db/diag/rdbms/gbaapexd/GBAAPEXD/trace/alert_GBAAPEXD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GBAAPEXP_database_alert_log_on_gbadb11",
  "path": " /gba/apexp/db/diag/rdbms/gbaapexp/GBAAPEXP/trace/alert_GBAAPEXP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GBAAPSU2_database_alert_log_on_gbadb04",
  "path": " /gba/apsu2/db/11.2.0.3/admin/GBAAPSU2_gbadb04/diag/rdbms/gbaapsu2/GBAAPSU2/trace/alert_GBAAPSU2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GBAAPSP_database_alert_log_on_gbadb13",
  "path": " /gba/apsp/db/diag/rdbms/gbaapsp/GBAAPSP/trace/alert_GBAAPSP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "GBAERPQ1_database_alert_log_on_gbadb08.dibos02.di-cloud.com",
  "path": " /gba/erpq1/db/11.2.0.3/admin/GBAERPQ1_gbadb08/diag/rdbms/gbaerpq1/GBAERPQ1/trace/alert_GBAERPQ1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "GBAERPQ2_database_alert_log_on_gbadb08.dibos02.di-cloud.com",
  "path": " /gba/erpq2/db/diag/rdbms/gbaerpq2/GBAERPQ2/trace/alert_GBAERPQ2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "GBAERPU5_database_alert_log_on_gbadb08.dibos02.di-cloud.com",
  "path": " /gba/erpu5/db/11.2.0.3/admin/GBAERPU5_gbadb08/diag/rdbms/gbaerpu5/GBAERPU5/trace/alert_GBAERPU5.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "GBAERPU1_database_alert_log_on_gbadb09",
  "path": " /gba/erpu1/db/11.2.0.3/admin/GBAERPU1_gbadb09/diag/rdbms/gbaerpu1/GBAERPU1/trace/alert_GBAERPU1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "GBAERPU3_database_alert_log_on_gbadb09",
  "path": " /gba/erpu3/db/11.2.0.3/admin/GBAERPU3_gbadb09/diag/rdbms/gbaerpu3/GBAERPU3/trace/alert_GBAERPU3.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "GBAERPU4_database_alert_log_on_gbadb09",
  "path": " /gba/erpu4/db/11.2.0.3/admin/GBAERPU4_gbadb09/diag/rdbms/gbaerpu4/GBAERPU4/trace/alert_GBAERPU4.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "GBAERPU7_database_alert_log_on_gbadb09",
  "path": " /gba/erpu7/db/11.2.0.3/admin/GBAERPU7_gbadb09/diag/rdbms/gbaerpu7/GBAERPU7/trace/alert_GBAERPU7.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GBAERPPDR_database_alert_log_on_gbadb11.slc01.di-cloud.com",
  "path": " /gba/erpp/db/diag/rdbms/gbaerppdr/GBAERPP/trace/alert_GBAERPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "GBAAPEXP_database_alert_log_on_gbadb11",
  "path": " /gba/apexp/db/diag/rdbms/gbaapexp/GBAAPEXP/trace/alert_GBAAPEXP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GBAERPP_database_alert_log_on_gbadb11",
  "path": " /gba/erpp/db/diag/rdbms/gbaerpp/GBAERPP/trace/alert_GBAERPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555|48913)\\d+/"
 },
 {
  "name": "GBAAPSPDR_database_alert_log_on_gbadb13.slc01.di-cloud.com",
  "path": " /gba/apsp/db/diag/rdbms/gbaapspdr/GBAAPSP/trace/alert_GBAAPSP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "GRPDEV_database_alert_log_on_grpdb01.dibos02.di-cloud.com",
  "path": " /grp/dev/db/10.2.0/admin/GRPDEV_grpdb01/bdump/alert_GRPDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GRPEBSD_database_alert_log_on_grpdb01.dibos02.di-cloud.com",
  "path": " /grp/dev/db/10.2.0/admin/GRPDEV_grpdb01/bdump/alert_GRPDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GRPR12T_database_alert_log_on_grpdb01.dibos02.di-cloud.com",
  "path": " /grp/dev/db/10.2.0/admin/GRPDEV_grpdb01/bdump/alert_GRPDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GRPTST_database_alert_log_on_grpdb01.dibos02.di-cloud.com",
  "path": " /grp/tst/db/10.2.0/admin/GRPTST_grpdb01/bdump/alert_GRPTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GRPEBSP_database_alert_log_on_grpdb11.dibos02.di-cloud.com",
  "path": " /grp/ebsp/db/11.2.0.4/admin/GRPEBSP_grpdb11/diag/rdbms/grpebsp/GRPEBSP/trace/alert_GRPEBSP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GRPPRD_database_alert_log_on_grpdb11.dibos02.di-cloud.com",
  "path": " /grp/prd/db/10.2.0/admin/GRPPRD_grpdb11/bdump/alert_GRPPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIPCH_database_alert_log_on_gsidb01",
  "path": " /gsi/pch/db/diag/rdbms/gsipch/GSIPCH/trace/alert_GSIPCH.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSITST_database_alert_log_on_gsidb01",
  "path": " /gsi/tst/db/diag/rdbms/gsitst/GSITST/trace/alert_GSITST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIDEV_database_alert_log_on_gsidb02",
  "path": " /gsi/dev/db/diag/rdbms/gsidev/GSIDEV/trace/alert_GSIDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIPJT_database_alert_log_on_gsidb02",
  "path": " /gsi/pjt/db/diag/rdbms/gsipjt/GSIPJT/trace/alert_GSIPJT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIPRD_database_alert_log_on_gsidb11",
  "path": " /gsi/prd/db/diag/rdbms/gsiprd/GSIPRD/trace/alert_GSIPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIJKLP_database_alert_log_on_gsidb13",
  "path": " /gsi/jklp/db/diag/rdbms/gsijklp/GSIJKLP/trace/alert_GSIJKLP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIFDMD_database_alert_log_on_gsihypdb01",
  "path": " /gsi/dev/ora/diag/rdbms/gsifdmd/GSIFDMD/trace/alert_GSIFDMD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIREPD_database_alert_log_on_gsihypdb01",
  "path": " /gsi/dev/ora/diag/rdbms/gsirepd/GSIREPD/trace/alert_GSIREPD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIFDMT_database_alert_log_on_gsihypdb02",
  "path": " /gsi/tst/ora/db/diag/rdbms/gsifdmt/GSIFDMT/trace/alert_GSIFDMT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIREPT_database_alert_log_on_gsihypdb02",
  "path": " /gsi/tst/ora/db/diag/rdbms/gsirept/GSIREPT/trace/alert_GSIREPT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIFDMP_database_alert_log_on_gsihypdb11",
  "path": " /gsi/prd/ora/db/diag/rdbms/gsifdmp/GSIFDMP/trace/alert_GSIFDMP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSIREPP_database_alert_log_on_gsihypdb11",
  "path": " /gsi/prd/ora/db/diag/rdbms/gsirepp/GSIREPP/trace/alert_GSIREPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "KRONOS_database_alert_log_on_wg-kdb-01.global.hovo.com",
  "path": " /u01/app/oracle/admin/kronos/bdump/alert_kronos.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HVTST_database_alert_log_on_wg-oa-04",
  "path": " /hv/tst/db/diag/rdbms/hvtst/HVTST/trace/alert_HVTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "KRONOS_database_alert_log_on_ew-kdb-01.global.hovo.com",
  "path": " /u01/app/oracle/admin/kronos/bdump/alert_kronos.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HVPRD_database_alert_log_on_ew-oa-04",
  "path": " /hv/prd/db/diag/rdbms/hvprd/HVPRD/trace/alert_HVPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HVPRD_database_alert_log_on_wg-oa-06",
  "path": " /hv/prd/db/diag/rdbms/hvprd_sb/HVPRD/trace/alert_HVPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TIPSPROD_database_alert_log_on_ew-tips-01.global.hovo.com",
  "path": " /hv/tipsprod/db/diag/rdbms/tipsprod/TIPSPROD/trace/alert_TIPSPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TIPSPROD_database_alert_log_on_wg-tips-01",
  "path": " /hv/tipsprod/db/diag/rdbms/tipsprod/TIPSPROD/trace/alert_TIPSPROD.log",
  "reg": " /ORA-0*(01244|01110)[^0-9]/"
 },
 {
  "name": "BMSBIWD_database_alert_log_on_haeobidb01",
  "path": " /hae/bms11d/ora/db/diag/rdbms/bmsbiwd/BMSBIWD/trace/alert_BMSBIWD.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BMSBIWT_database_alert_log_on_haeobidb02",
  "path": " /hae/bms11t/ora/diag/rdbms/bmsbiwt/BMSBIWT/trace/alert_BMSBIWT.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEBIWP_database_alert_log_on_haeobidb101.dibos02.di-cloud.com",
  "path": " /hae/biwp/db/product/11.2.0.3/diag/rdbms/haebiwp/HAEBIWP/trace/alert_HAEBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BMSBIWP_database_alert_log_on_haeobidb11",
  "path": " /hae/bms11p/ora/product/11.2.0/diag/rdbms/bmsbiwp/BMSBIWP/trace/alert_BMSBIWP.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEIOIMD_database_alert_log_on_haeoimdb02",
  "path": " /hae/oimd/db/diag/rdbms/haeioimd/HAEIOIMD/trace/alert_HAEIOIMD.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEIOIMT_database_alert_log_on_haeoimdb03",
  "path": " /hae/oimt/db/diag/rdbms/haeioimt/HAEIOIMT/trace/alert_HAEIOIMT.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BMSBIWI_database_alert_log_on_haeoimdb12",
  "path": " /hae/oimp/db/diag/rdbms/bmsbiwi/BMSBIWI/trace/alert_BMSBIWI.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "BIAAGLP_database_alert_log_on_haeobidb19",
  "path": " /hae/prd/ora/db/diag/rdbms/biaaglp/BIAAGLP/trace/alert_BIAAGLP.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIAAGLU_database_alert_log_on_haeobidb43",
  "path": " /hae/uat/ora/db/diag/rdbms/biaaglu/BIAAGLU/trace/alert_BIAAGLU.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIABAWD_database_alert_log_on_haeobidb41",
  "path": " /hae/ora/biad/db/diag/rdbms/biabawd/BIABAWD/trace/alert_BIABAWD.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIABAWP_database_alert_log_on_haeobidb19",
  "path": " /hae/prd/ora/db/diag/rdbms/biabawp/BIABAWP/trace/alert_BIABAWP.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIABAWT_database_alert_log_on_haeobidb42",
  "path": " /hae/tst/ora/db/diag/rdbms/biabawt/BIABAWT/trace/alert_BIABAWT.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIABAWU_database_alert_log_on_haeobidb43",
  "path": " /hae/uat/ora/db/diag/rdbms/biabawu/BIABAWU/trace/alert_BIABAWU.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIAREPU_database_alert_log_on_haeobidb41",
  "path": " /hae/ora/biad/db/diag/rdbms/biarepu/BIAREPU/trace/alert_BIAREPU.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEAGLV_database_alert_log_on_haeagldb201",
  "path": " /hae/aglv/db/diag/rdbms/haeaglv/HAEAGLV/trace/alert_HAEAGLV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEAGLD_database_alert_log_on_haeagldb301",
  "path": " /hae/agld/db/diag/rdbms/haeagld/HAEAGLD/trace/alert_HAEAGLD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEAGLT_database_alert_log_on_haeagldb301",
  "path": " /hae/aglt/db/diag/rdbms/haeaglt/HAEAGLT/trace/alert_HAEAGLT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEAGLP_database_alert_log_on_haeagldb101",
  "path": " /hae/aglp/db/diag/rdbms/haeaglp/HAEAGLP/trace/alert_HAEAGLP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEAPSD_database_alert_log_on_haedb53",
  "path": " /hae/apsd/db/12c_base/diag/diag/rdbms/haeapsd/HAEAPSD/trace/alert_HAEAPSD.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913|00700)\\d+/"
 },
 {
  "name": "HAEAPSP_database_alert_log_on_haedb73",
  "path": " /hae/apsp/db/base/admin/HAEAPSP_haedb73/diag/rdbms/haeapsp/HAEAPSP/trace/alert_HAEAPSP.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEXQY_database_alert_log_on_haedb61",
  "path": " /hae/xqy/db/diag/rdbms/haexqy/HAEXQY/trace/alert_HAEXQY.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAETST_database_alert_log_on_haedb64",
  "path": " /hae/tst/db/11.2.0.3/admin/HAETST_haedb64/diag/rdbms/haetst/HAETST/trace/alert_HAETST.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEUAT_database_alert_log_on_haedb64",
  "path": " /hae/uat/db/11.2.0.3/admin/HAEUAT_haedb64/diag/rdbms/haeuat/HAEUAT/trace/alert_HAEUAT.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEDEV_database_alert_log_on_haedb65",
  "path": " /hae/dev/db/diag/rdbms/haedev/HAEDEV/trace/alert_HAEDEV.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEHRU_database_alert_log_on_haedb65",
  "path": " /hae/hru/db/diag/rdbms/haehru/HAEHRU/trace/alert_HAEHRU.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAECNV_database_alert_log_on_haedb66.dibos02.di-cloud.com",
  "path": " /hae/cnv/db/diag/rdbms/haecnv/HAECNV/trace/alert_HAECNV.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEWKLY_database_alert_log_on_haedb66.dibos02.di-cloud.com",
  "path": " /hae/wkly/db/diag/rdbms/haewkly/HAEWKLY/trace/alert_HAEWKLY.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEZRC_database_alert_log_on_haedb66.dibos02.di-cloud.com",
  "path": " /hae/zrc/db/diag/rdbms/haezrc/HAEZRC/trace/alert_HAEZRC.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEVAL1_database_alert_log_on_haedb61",
  "path": " /hae/val/db/diag/rdbms/haeval/HAEVAL1/trace/alert_HAEVAL1.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEVAL2_database_alert_log_on_haedb62",
  "path": " /hae/val/db/diag/rdbms/haeval/HAEVAL2/trace/alert_HAEVAL2.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEAPSV_database_alert_log_on_haedb63",
  "path": " /hae/apsv/db/12c_base/diag/diag/rdbms/haeapsv/HAEAPSV/trace/alert_HAEAPSV.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEPRD_C_database_alert_log_on_haedb63",
  "path": " /hae/prd/db/diag/rdbms/haeprd_c/HAEPRD_C/trace/alert_HAEPRD_C.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913|16037)\\d+/"
 },
 {
  "name": "HAEPRD2_database_alert_log_on_haedb72",
  "path": " /hae/prd/db/base/diag/rdbms/haeprd/HAEPRD2/trace/alert_HAEPRD2.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEPRD1_database_alert_log_on_haedb71",
  "path": " /hae/prd/db/base/diag/rdbms/haeprd/HAEPRD1/trace/alert_HAEPRD1.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEFDMD_database_alert_log_on_haehypdb02.dibos02.di-cloud.com",
  "path": " /hae/dev/ora/db/diag/rdbms/haefdmd/HAEFDMD/trace/alert_HAEFDMD.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEREPD_database_alert_log_on_haehypdb02.dibos02.di-cloud.com",
  "path": " /hae/dev/ora/db/diag/rdbms/haerepd/HAEREPD/trace/alert_HAEREPD.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEFDMP_database_alert_log_on_haehypdb22",
  "path": " /hae/prd/db/diag/rdbms/haefdmp/HAEFDMP/trace/alert_HAEFDMP.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEREPP_database_alert_log_on_haehypdb22",
  "path": " /hae/prd/db/diag/rdbms/haerepp/HAEREPP/trace/alert_HAEREPP.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEIDMT_database_alert_log_on_haeidmdb01",
  "path": " /hae/idmt/db/diag/rdbms/haeidmt/HAEIDMT/trace/alert_HAEIDMT.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEIDMV_database_alert_log_on_haeidmdb01",
  "path": " /hae/idmv/db/diag/rdbms/haeidmv/HAEIDMV/trace/alert_HAEIDMV.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEIDMP_database_alert_log_on_haeidmdb11",
  "path": " /hae/idmp/db/diag/rdbms/haeidmp/HAEIDMP/trace/alert_HAEIDMP.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEAGLPR_database_alert_log_on_haeagldb101.slc01.di-cloud.com",
  "path": " /hae/aglp/db/diag/rdbms/haeaglpr/HAEAGLP/trace/alert_HAEAGLP.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HAEPRDR_database_alert_log_on_haedb71r",
  "path": " /hae/prd/db/11.2.0.3/log/diag/rdbms/haeprdr/HAEPRDR/trace/alert_HAEPRDR.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSUAT_database_alert_log_on_husdb201",
  "path": " /hus/uat/db/base/diag/rdbms/husuat/HUSUAT/trace/alert_HUSUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSDEV_database_alert_log_on_husdb301",
  "path": " /hus/dev/db/base/diag/rdbms/husdev/HUSDEV/trace/alert_HUSDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSTST_database_alert_log_on_husdb301",
  "path": " /hus/tst/db/base/diag/rdbms/hustst/HUSTST/trace/alert_HUSTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSVCPD_database_alert_log_on_husdb302",
  "path": " /hus/vcpd/db/tech_st/diag/rdbms/husvcpd/HUSVCPD/trace/alert_HUSVCPD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSVCPT_database_alert_log_on_husdb302",
  "path": " /hus/vcpt/db/tech_st/diag/rdbms/husvcpt/HUSVCPT/trace/alert_HUSVCPT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSPRDDR_database_alert_log_on_husdb101.slc01.di-cloud.com",
  "path": " /hus/prd/db/diag/diag/rdbms/husprddr/HUSPRD/trace/alert_HUSPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSPRD_database_alert_log_on_husdb101",
  "path": " /hus/prd/db/base/diag/rdbms/husprd/HUSPRD/trace/alert_HUSPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSREPP_database_alert_log_on_husdb102",
  "path": " /hus/repp/db/base/diag/rdbms/husrepp/HUSREPP/trace/alert_HUSREPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSVCPP_database_alert_log_on_husdb102",
  "path": " /hus/vcpp/db/tech_st/diag/rdbms/husvcpp/HUSVCPP/trace/alert_HUSVCPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSEMP_database_alert_log_on_husoemdb101",
  "path": " /hus/oem/db/diag/diag/rdbms/husemp/HUSEMP/trace/alert_HUSEMP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HUSSTP_database_alert_log_on_husstatdb101",
  "path": " /hus/stp/db/base/diag/rdbms/husstp/husstp/trace/alert_husstp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "ICUAPSD_database_alert_log_on_icuapsdb01d",
  "path": " /icu/dev/db/tech_st/diag/rdbms/icuapsd/ICUAPSD/trace/alert_ICUAPSD.log",
  "reg": " /ORA-(?!1652|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ICUAPST_database_alert_log_on_icuapsdb01d",
  "path": " /icu/tst/db/tech_st/diag/rdbms/icuapst/ICUAPST/trace/alert_ICUAPST.log",
  "reg": " /ORA-(?!1652|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ICUDEV1_database_alert_log_on_icudb01d",
  "path": " /icu/ora/dev1/db/11.2.0.3/admin/ICUDEV1_icudb01d/diag/rdbms/icudev1/ICUDEV1/trace/alert_ICUDEV1.log",
  "reg": " /ORA-(?!1652|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ICUTST1_database_alert_log_on_icudb01d",
  "path": " /icu/ora/tst1/db/diag/rdbms/icutst1/ICUTST1/trace/alert_ICUTST1.log",
  "reg": " /ORA-(?!1652|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ICUBIWD_database_alert_log_on_icubidb01d",
  "path": " /",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "QDEV_database_alert_log_on_\\\\icu-q-ora01t",
  "path": " \\\\icu-q-ora01t\\d$\\oracle\\diag\\rdbms\\qdev\\qdev\\trace\\alert_qdev.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ICUAPSP_database_alert_log_on_icuapsdb11p",
  "path": " /icu/prd/db/tech_st/diag/rdbms/icuapsp/ICUAPSP/trace/alert_ICUAPSP.log",
  "reg": " /ORA-(?!16957|07445|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ICUPRD_database_alert_log_on_icudb11p",
  "path": " /icu/ora/prd/db/diag/rdbms/icuprd/ICUPRD/trace/alert_ICUPRD.log",
  "reg": " /ORA-(?!00235|00060|000060|28|18913|3136|03149|03137|609|48913|00338|00312|12012|06502|06512)\\d+/"
 },
 {
  "name": "WEBSKPRD_database_alert_log_on_sk-webkey01p",
  "path": " /icu/apps/prd/db/diag/rdbms/webskprd/WEBSKPRD/trace/alert_WEBSKPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ICUBIWP_database_alert_log_on_icubidb11p",
  "path": " /icu/prd/db/diag/rdbms/icubiwp/ICUBIWP/trace/alert_ICUBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|00600)\\d+/"
 },
 {
  "name": "ICUBIWP_database_alert_log_on_icubidb12p",
  "path": " /",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "QPRD_database_alert_log_on_\\\\icu-q-ora12p",
  "path": " \\\\ICU-Q-ORA12P\\D$\\oracle\\diag\\rdbms\\qprd\\qprd\\trace\\alert_qprd.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ICUOAP_database_alert_log_on_icuoadb11p",
  "path": " /icu/oa/prd/db/diag/rdbms/icuoap/ICUOAP/trace/alert_ICUOAP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },

{
  "name": "PDB00_database_alert_log_on_dev-db02",
  "path": " /app/oracle/diag/rdbms/pdb00/pdb00/trace/alert_pdb00.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PDB00_database_alert_log_on_ipidb02",
  "path": " /u01/app/oracle/diag/rdbms/pdb00/PDB00/trace/alert_PDB00.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "BBNDEV_database_alert_log_on_bbndb01.dibos02.di-cloud.com",
  "path": " /bbn/dev/db/11.2.0.3/admin/BBNDEV_bbndb01/diag/rdbms/bbndev/BBNDEV/trace/alert_BBNDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BBNTST_database_alert_log_on_bbndb01.dibos02.di-cloud.com",
  "path": " /bbn/tst/db/diag/rdbms/bbntst/BBNTST/trace/alert_BBNTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BBNPRD_database_alert_log_on_bbndb11.dibos02.di-cloud.com",
  "path": " /bbn/prd/db/diag/rdbms/bbnprd/BBNPRD/trace/alert_BBNPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "IDCQAT_database_alert_log_on_idcdb01",
  "path": " /idc/qat/db/diag/rdbms/idcqat/IDCQAT/trace/alert_IDCQAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IDCSUP_database_alert_log_on_idcdb01",
  "path": " /idc/sup/db/11.2.0/admin/IDCSUP_idcdb01/diag/rdbms/idcsup/IDCSUP/trace/alert_IDCSUP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|06512)\\d+/"
 },
 {
  "name": "IDCUAT_database_alert_log_on_idcdb01",
  "path": " /idc/uat/db/diag/rdbms/idcuat/IDCUAT/trace/alert_IDCUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IDCDV2_database_alert_log_on_idcdb04",
  "path": " /idc/dv2/db/diag/rdbms/idcdv2/IDCDV2/trace/alert_IDCDV2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IDCDV3_database_alert_log_on_idcdb04",
  "path": " /idc/dv3/db/diag/rdbms/idcdv3/IDCDV3/trace/alert_IDCDV3.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IDCPRD_database_alert_log_on_idcdb-vip",
  "path": " /idc/prd/db/diag/rdbms/idcprdorig/IDCPRD/trace/alert_IDCPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|00600|00601|00604|07445|00020|01578)\\d+/"
 },
 {
  "name": "IDCPRD_database_alert_log_for_P1_on_idcdb-vip",
  "path": " /idc/prd/db/diag/rdbms/idcprdorig/IDCPRD/trace/alert_IDCPRD.log",
  "reg": " /ORA-(00600|00601|00604|07445|00020|01578)/"
 },
 {
  "name": "FOGLIGHT_database_alert_log_on_idcfog11",
  "path": " /idc/foglight/db/diag/rdbms/idcfog/IDCFOG/trace/alert_IDCFOG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IDCSTAT_database_alert_log_on_idcstat11",
  "path": " /idc/stat/appl/diag/rdbms/idcstat/IDCSTAT/trace/alert_IDCSTAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IDCBID_database_alert_log_on_idcobidb01",
  "path": " /idc/dev/db/diag/rdbms/idcbid/IDCBID/trace/alert_IDCBID.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|10173)\\d+/ "
 },
 {
  "name": "IDCBIWD_database_alert_log_on_idcobidb01",
  "path": " /idc/dev/db/diag/rdbms/idcbiwd/IDCBIWD/trace/alert_IDCBIWD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|10173)\\d+/"
 },
 {
  "name": "IDCBIT_database_alert_log_on_idcobidb02",
  "path": " /idc/tst/db/diag/rdbms/idcbit/IDCBIT/trace/alert_IDCBIT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|10173|12012|00911|06512)\\d+/"
 },
 {
  "name": "IDCBIWT_database_alert_log_on_idcobidb02",
  "path": " /idc/tst/db/diag/rdbms/idcbiwt/IDCBIWT/trace/alert_IDCBIWT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|10173)\\d+/"
 },
 {
  "name": "IDCBIP_database_alert_log_on_idcobidb11",
  "path": " /idc/prd/db/diag/rdbms/idcbip/IDCBIP/trace/alert_IDCBIP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|10173|00308|27037|38500|27037|03135|19624|19504|27041|16037|03113|00445|279|308)\\d+/"
 },
 {
  "name": "IDCBIWP_database_alert_log_on_idcobidb11",
  "path": " /idc/prd/db/diag/rdbms/idcbiwp/IDCBIWP/trace/alert_IDCBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|10173)\\d+/"
 },
 {
  "name": "IDCPRD_DR_database_alert_log_on_idcdb11r",
  "path": " /idc/prd/db/diag/rdbms/idcprddr/IDCPRD/trace/alert_IDCPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IDCBIP_DR_database_alert_log_on_idcobidb11r",
  "path": " /idc/prd/db/diag/rdbms/idcbip/IDCBIP/trace/alert_IDCBIP.log",
  "reg": " /ORA-(?!03135|00060|000060|28|18913|3136|03149|03137|609|48913|00308|27037|38500|27037|03135|19624|19504|27041|16037|16038|03113|00445|279|308|00312|16014)\\d+/"
 },
 {
  "name": "IDCBIWP_DR_database_alert_log_on_idcobidb11r",
  "path": " /idc/prd/db/diag/rdbms/idcbiwp/IDCBIWP/trace/alert_IDCBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|00308|27037|38500|27037|03135|19624|19504|27041|16037|03113|00445|279|308)\\d+/"
 },
 {
  "name": "IDCDEV_database_alert_log_on_idcdb03",
  "path": null,
  "reg": null
 },
 {
  "name": "IDCPCH_database_alert_log_on_idcdb03",
  "path": null,
  "reg": null
 }
,
{
  "name": "HYPDEV_database_alert_log_on_hypt-oradb-01",
  "path": " /irb/hyporatstdb/db/diag/rdbms/hypdev/HYPDEV/trace/alert_HYPDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HYPPRD_database_alert_log_on_hyporaprddb",
  "path": " /irb/hyporaprddb/db/diag/rdbms/hypprd/HYPPRD/trace/alert_HYPPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DISCOPRD_database_alert_log_on_hq-discoprd-01.wardrobe.irobot.com",
  "path": " /u01/app/oracle/diag/rdbms/xe/XE/trace/alert_XE.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IRBQTZ_database_alert_log_on_irbqtzdb",
  "path": " /irb/qtz/db/diag/rdbms/irbqtz/IRBQTZ/trace/alert_IRBQTZ.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IRBRBY_database_alert_log_on_irbrbydb",
  "path": " /irb/rby/db/diag/rdbms/irbrby/IRBRBY/trace/alert_IRBRBY.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IRBZIR_database_alert_log_on_irbzirdb",
  "path": " /irb/zir/db/diag/rdbms/irbzir/IRBZIR/trace/alert_IRBZIR.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "IRBONX_database_alert_log_on_irbonxdb",
  "path": " /irb/onx/db/diag/rdbms/irbonx/IRBONX/trace/alert_IRBONX.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "HYPPRD_database_alert_log_on_hyporaprddb_new.wardrobe.irobot.com",
  "path": " /irb/hyporaprddb/db/diag/rdbms/hypprd/HYPPRD/trace/alert_HYPPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ODWDEV_database_alert_log_on_odwdevdb",
  "path": " /irb/odwdev/db/diag/rdbms/odwdev/ODWDEV/trace/alert_ODWDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ODWTST_database_alert_log_on_odwtstdb",
  "path": " /irb/odwtst/db/diag/rdbms/odwtst/ODWTST/trace/alert_ODWTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ORACLEDI_database_alert_log_on_odiprd.wardrobe.irobot.com",
  "path": " /irb/odiprd/db/diag/rdbms/oracledi/ORACLEDI/trace/alert_ORACLEDI.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ODWPRD_database_alert_log_on_odwprddb",
  "path": " /irb/odwprd/db/diag/rdbms/odwprd/ODWPRD/trace/alert_ODWPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WIND9_database_alert_log_on_wcprddb",
  "path": " /irb/wcprd/db/oracle/app/oracle/diag/rdbms/wind9/wind9/trace/alert_wind9.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "ITTDEV_database_alert_log_on_sfoapdb1t.global.ittcorp.net",
  "path": " /itt/ora/dev/db/diag/rdbms/ittdev/ITTDEV/trace/alert_ITTDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ITTEVAL_database_alert_log_on_sfoapdb1t.global.ittcorp.net",
  "path": " /itt/ora/eval/db/diag/rdbms/itteval/ITTEVAL/trace/alert_ITTEVAL.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ASCPDEV_database_alert_log_on_sfoapgrc1t.global.ittcorp.net",
  "path": " /itt/ora/ascpdev/db/diag/rdbms/ascpdev/ASCPDEV/trace/alert_ASCPDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GRCDEV_database_alert_log_on_sfoapgrc1t.global.ittcorp.net",
  "path": " /itt/ora/db/diag/rdbms/grcdev/GRCDEV/trace/alert_GRCDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ITTPROD_database_alert_log_on_sfoapdb1",
  "path": " /itt/ora/db/diag/rdbms/ittprod/ITTPROD/trace/alert_ITTPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ASCPPROD_database_alert_log_on_sfoapgrc1.global.ittcorp.net",
  "path": " /itt/ora/ascpprod/db/diag/rdbms/ascpprod/ASCPPROD/trace/alert_ASCPPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GRCPROD_database_alert_log_on_sfoapgrc1.global.ittcorp.net",
  "path": " /itt/ora/db/diag/rdbms/grcprod/GRCPROD/trace/alert_GRCPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "KADPRD_database_alert_log_on_kaddb01",
  "path": " /u01/ora/prd/db/10.2.0/admin/KADPRD_kaddb01/bdump/alert_KADPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "LFICONV2_database_alert_log_on_lfidb01",
  "path": " /lfi/conv2/db/diag/rdbms/lficonv2/LFICONV2/trace/alert_LFICONV2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFIDEV_database_alert_log_on_lfidb01",
  "path": " /lfi/dev/db/diag/rdbms/lfidev/LFIDEV/trace/alert_LFIDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|28500|02063|28511|12154)\\d+/"
 },
 {
  "name": "LFISUP_database_alert_log_on_lfidb01",
  "path": " /lfi/sup/db/diag/rdbms/lfisup/LFISUP/trace/alert_LFISUP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFIUAT_database_alert_log_on_lfidb02",
  "path": " /lfi/uat/db/diag/rdbms/lfiuat/LFIUAT/trace/alert_LFIUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|28500|02063)\\d+/"
 },
 {
  "name": "LFIAPSD_database_alert_log_on_lfidb05",
  "path": " /lfi/apsd/db/dbbase/diag/rdbms/lfiapsd/LFIAPSD/trace/alert_LFIAPSD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFIAPST_database_alert_log_on_lfidb05",
  "path": " /lfi/apst/db/dbbase/diag/rdbms/lfiapst/LFIAPST/trace/alert_LFIAPST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFIPRD_database_alert_log_on_lfidb11",
  "path": " /lfi/prd/db/diag/rdbms/lfiprd/LFIPRD/trace/alert_LFIPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|28500|02063)\\d+/"
 },
 {
  "name": "LFIAPSP_database_alert_log_on_lfidb15",
  "path": " /lfi/apsp/db/dbbase/diag/rdbms/lfiapsp/LFIAPSP/trace/alert_LFIAPSP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFIHYPD_database_alert_log_on_lfihypdb01",
  "path": " /lfi/dev/hyp/ora/db/diag/rdbms/lfihypd/LFIHYPD/trace/alert_LFIHYPD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFIHYPP_database_alert_log_on_lfihypdb11.dibos02.di-cloud.com",
  "path": " /lfi/prd/ora/db/diag/rdbms/lfihypp/LFIHYPP/trace/alert_LFIHYPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFIBIDW1_database_alert_log_on_lfiobidb01",
  "path": " /lfi/dev/ora/dw1/db/diag/rdbms/lfibidw1/LFIBIDW1/trace/alert_LFIBIDW1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFIBIWP_database_alert_log_on_lfiobidb11",
  "path": " /lfi/prd/ora/db/dw/diag/rdbms/lfibiwp/LFIBIWP/trace/alert_LFIBIWP.log",
  "reg": " /ORA-(?!2000|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFISOAT_database_alert_log_on_lfidb03",
  "path": " /lfi/soat/db/diag/rdbms/lfisoat/lfisoat/trace/alert_lfisoat.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LFISOAP_database_alert_log_on_lfidb13.dibos02.di-cloud.com",
  "path": " /lfi/soap/db/diag/rdbms/lfisoap/LFISOAP/trace/alert_LFISOAP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "DLSTAI_database_alert_log_on_li-tstdev",
  "path": " /dlstai/oracle/dlstaidb/10.2.0/admin/DLSTAI_li-tstdev/bdump/alert_DLSTAI.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TLSTAI_database_alert_log_on_li-tstdev",
  "path": " /tlstai/oracle/tlstaidb/9.2.0/admin/TLSTAI_li-tstdev/bdump/alert_TLSTAI.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CLSTAI_database_alert_log_on_li-pdb",
  "path": " /clstai/oracle/clstaidb/9.2.0/admin/CLSTAI_li-pdb/bdump/alert_CLSTAI.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PLSTAI_database_alert_log_on_li-pdb",
  "path": " /plstai/oracle/plstaidb/9.2.0/admin/PLSTAI_li-pdb/bdump/alert_PLSTAI.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LAPRD_database_alert_log_on_h2-oeldb01.us.loomis.com",
  "path": " /la/prd/db/admin/LAPRD/diag/rdbms/laprd/LAPRD/trace/alert_LAPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LAPRD_database_alert_log_on_h2-oeldb02.us.loomis.com",
  "path": " /la/prd/db/admin/LAPRD/diag/rdbms/laprd/LAPRD/trace/alert_LAPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DEV_database_alert_log_on_dylan",
  "path": " /mtg/dev/db/10.2.0/admin/DEV_dylan/bdump/alert_DEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TST_database_alert_log_on_dylan",
  "path": " /mtg/tst/db/10.2.0/admin/TST_dylan/bdump/alert_TST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AADPROD_database_alert_log_on_dionysus",
  "path": " /mtg/aadprod/db/diag/rdbms/aadprod/AADPROD/trace/alert_AADPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|20000)\\d+/"
 },
 {
  "name": "ADVPROD_database_alert_log_on_dionysus",
  "path": " /mtg/advprod/db/diag/rdbms/advprod/ADVPROD/trace/alert_ADVPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PROD_database_alert_log_on_dionysus",
  "path": " /mtg/prd/db/10.2.0/admin/PROD_dionysus/bdump/alert_PROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|07445)\\d+/"
 },
 {
  "name": "PRODBI_database_alert_log_on_dionysus",
  "path": " /mtg/prodbi/db/diag/rdbms/prodbi/PRODBI/trace/alert_PRODBI.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|07445)\\d+/"
 },
 {
  "name": "ORCL9DAM_database_alert_log_on_\\\\hades",
  "path": " \\\\hades\\d$\\oracle\\admin\\orcl9dam\\bdump\\alert_orcl9dam.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|07445)\\d+/"
 },
 {
  "name": "AADDEV_database_alert_log_on_dylan",
  "path": " /mtg/aaddev/db/diag/rdbms/aaddev/AADDEV/trace/alert_AADDEV.log",
  "reg": " /ORA-(?!00060|000060|1089|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ADVDEV_database_alert_log_on_dylan",
  "path": " /mtg/advdev/db/diag/rdbms/advdev/ADVDEV/trace/alert_ADVDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|1089)\\d+/"
 },
{
  "name": "TMIPRF_database_alert_log_on_tmidb01.dibos02.di-cloud.com",
  "path": " /tmi/prf/db/tech_st/diag/rdbms/tmiprf/TMIPRF/trace/alert_TMIPRF.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TMISTG_database_alert_log_on_tmidb01.dibos02.di-cloud.com",
  "path": " /tmi/stg/db/tech_st/diag/rdbms/tmistg/TMISTG/trace/alert_TMISTG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TMIDEV_database_alert_log_on_tmidb02.dibos02.di-cloud.com",
  "path": " /tmi/dev/db/tech_st/diag/rdbms/tmidev/TMIDEV/trace/alert_TMIDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TMITST_database_alert_log_on_tmidb02.dibos02.di-cloud.com",
  "path": " /tmi/tst/db/tech_st/diag/rdbms/tmitst/TMITST/trace/alert_TMITST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TMIPRD_database_alert_log_on_tmidb11.dibos02.di-cloud.com",
  "path": " /tmi/prd/db/tech_st/diag/rdbms/tmiprd/TMIPRD/trace/alert_TMIPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBDEV1_database_alert_log_on_mwsbapp-d00ah.mathworks.com",
  "path": " /local_db/oracle/diag/rdbms/mwsbdev1/MWSBDEV1/trace/alert_MWSBDEV1.log",
  "reg": " /ORA-(?!00060|00445|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBDEV2_database_alert_log_on_mwsbapp-d00ah.mathworks.com",
  "path": " /local_db/oracle/diag/rdbms/mwsbdev2/MWSBDEV2/trace/alert_MWSBDEV2.log",
  "reg": " /ORA-(?!00060|000060|00445|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBDEV3_database_alert_log_on_mwsbapp-d00ah.mathworks.com",
  "path": " /local_db/oracle/diag/rdbms/mwsbdev3/MWSBDEV3/trace/alert_MWSBDEV3.log",
  "reg": " /ORA-(?!00060|000060|00445|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBTST1_database_alert_log_on_mwsbapp-t00ah.mathworks.com",
  "path": " /local_db/oracle/diag/rdbms/mwsbtst1/MWSBTST1/trace/alert_MWSBTST1.log",
  "reg": " /ORA-(?!00060|000060|00445|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBTST2_database_alert_log_on_mwsbapp-t00ah.mathworks.com",
  "path": " /local_db/oracle/diag/rdbms/mwsbtst2/MWSBTST2/trace/alert_MWSBTST2.log",
  "reg": " /ORA-(?!00060|000060|00445|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBTST3_database_alert_log_on_mwsbapp-t00ah.mathworks.com",
  "path": " /local_db/oracle/diag/rdbms/mwsbtst3/MWSBTST3/trace/alert_MWSBTST3.log",
  "reg": " /ORA-(?!00060|000060|00445|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBDEV1_database_alert_log_on_mwsbintegdb-00-ah",
  "path": " /local_db/oracle/diag/rdbms/mwsbdev1/MWSBDEV1/trace/alert_MWSBDEV1.log",
  "reg": " /ORA-(?!00060|000060|00445|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBDEV2_database_alert_log_on_mwsbintegdb-00-ah",
  "path": " /local_db/oracle/diag/rdbms/mwsbdev2/MWSBDEV2/trace/alert_MWSBDEV2.log",
  "reg": " /ORA-(?!00060|000060|00445|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBDEV3_database_alert_log_on_mwsbintegdb-00-ah",
  "path": " /local_db/oracle/diag/rdbms/mwsbdev3/MWSBDEV3/trace/alert_MWSBDEV3.log",
  "reg": " /ORA-(?!00060|000060|00445|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBPERFDB_database_alert_log_on_mwsbperfdb-00-ah",
  "path": " /local/oracle_11g/product/11.2.0/asm_1/log/mwsbperfdb-00-ah/alertmwsbperfdb-00-ah.log ",
  "reg": " /ORA-(?!00060|000060|00445|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBSTG2_database_alert_log_on_mwsbsdb-01-ah",
  "path": " /grid11g/log/mwsbsdb-01-ah/alertmwsbsdb-01-ah.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBSTG1_database_alert_log_on_mwsbsdb-00-ah",
  "path": " /grid11g/log/mwsbsdb-00-ah/alertmwsbsdb-00-ah.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DEV_database_alert_log_on_\\\\twedapp-00-ah",
  "path": " C\\app\\brianb\\diag\\rdbms\\orcl\\orcl\\trace\\alert_orcl.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "STAGE_database_alert_log_on_\\\\twesapp-00-ah",
  "path": " \\\\twesapp-00-ah\\c$\\app\\brianb\\diag\\rdbms\\orcl\\orcl\\trace\\alert_orcl.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TEST_database_alert_log_on_\\\\twetdb-00-ah",
  "path": " \\\\twetdb-00-ah\\c$\\app\\brianb\\diag\\rdbms\\orcl\\orcl\\trace\\alert_orcl.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBPROD1_database_alert_log_on_mwsbpdb-01-ah",
  "path": " /local/oracle_11g/diag/rdbms/mwsbprod/MWSBPROD1/trace/alert_MWSBPROD1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MWSBPROD2_database_alert_log_on_mwsbpdb-01-ah",
  "path": " /local/oracle_11g/diag/rdbms/mwsbprod/MWSBPROD2/trace/alert_MWSBPROD2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PROD_database_alert_log_on_\\\\twepdb-00-ah",
  "path": " \\\\twepdb-00-ah\\c$\\app\\brianb\\diag\\rdbms\\orcl\\orcl\\trace\\alert_orcl.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MCCDEV_database_alert_log_on_mccdb01",
  "path": " /mcc/dev/db/diag/rdbms/mccdev/MCCDEV/trace/alert_MCCDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MCCSTG_database_alert_log_on_mccdb01",
  "path": " /mcc/stg/db/diag/rdbms/mccstg/MCCSTG/trace/alert_MCCSTG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MCCTST_database_alert_log_on_mccdb01",
  "path": " /mcc/tst/db/diag/rdbms/mcctst/MCCTST/trace/alert_MCCTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MCCPRD_database_alert_log_on_mccdb11",
  "path": " /mcc/prd/db/tech_st/diag/rdbms/mccprd/MCCPRD/trace/alert_MCCPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SABPRD_database_alert_log_on_mccsabmt11",
  "path": " /mcc/sab/db/diag/rdbms/sabprd/SABPRD/trace/alert_SABPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MCCDMTST_database_alert_log_on_mccdmdb01.dibos02.di-cloud.com",
  "path": " /mcc/dmtst/db/diag/rdbms/mccdmtst/MCCDMTST/trace/alert_MCCDMTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MCCDMPRD_database_alert_log_on_mccdmdb11",
  "path": " /mcc/dmprd/db/diag/rdbms/mccdmprd/MCCDMPRD/trace/alert_MCCDMPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "MRCAGLD_database_alert_log_on_mrcagldb01",
  "path": " /mrc/agld/db/diag/rdbms/mrcagld/MRCAGLD/trace/alert_MRCAGLD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCAGLQ_database_alert_log_on_mrcagldb01",
  "path": " /mrc/aglt/db/db_mrcaglq/diag/rdbms/mrcaglq/MRCAGLQ/trace/alert_MRCAGLQ.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCAGLT_database_alert_log_on_mrcagldb01",
  "path": " /mrc/aglt/db/diag/rdbms/mrcaglt/MRCAGLT/trace/alert_MRCAGLT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCAGLP_database_alert_log_on_mrcagldb101",
  "path": " /mrc/aglp/db/diag/rdbms/mrcaglp/MRCAGLP/trace/alert_MRCAGLP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCIPMD_database_alert_log_on_mrcdeldb01.dibos02.di-cloud.com",
  "path": " /mrc/ipmd/db/diag/rdbms/mrcipmd/MRCIPMD/trace/alert_MRCIPMD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCSFTD_database_alert_log_on_mrcdeldb01.dibos02.di-cloud.com",
  "path": " /mrc/sftd/db/diag/rdbms/mrcsftd/MRCSFTD/trace/alert_MRCSFTD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCIPMT_database_alert_log_on_mrcdeldb02.dibos02.di-cloud.com",
  "path": " /mrc/ipmt/db/diag/rdbms/mrcipmt/MRCIPMT/trace/alert_MRCIPMT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCSFTT_database_alert_log_on_mrcdeldb02.dibos02.di-cloud.com",
  "path": " /mrc/sftt/db/diag/rdbms/mrcsftt/MRCSFTT/trace/alert_MRCSFTT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCIPMP_database_alert_log_on_mrcdeldb11.dibos02.di-cloud.com",
  "path": " /mrc/ipmp/db/diag/rdbms/mrcipmp/MRCIPMP/trace/alert_MRCIPMP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCSFTP_database_alert_log_on_mrcdeldb11.dibos02.di-cloud.com",
  "path": " /mrc/sftp/db/diag/rdbms/mrcsftp/MRCSFTP/trace/alert_MRCSFTP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCDEV_database_alert_log_on_mrcdb01",
  "path": " /mrc/dev/db/11.2.0/admin/MRCDEV_mrcdb01/diag/rdbms/mrcdev/MRCDEV/trace/alert_MRCDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCPJT_database_alert_log_on_mrcdb01",
  "path": " /mrc/pjt/db/11.2.0/admin/MRCPJT_mrcdb01/diag/rdbms/mrcpjt/MRCPJT/trace/alert_MRCPJT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCSUP_database_alert_log_on_mrcdb01",
  "path": " /mrc/sup/db/11.2.0/admin/MRCSUP_mrcdb01/diag/rdbms/mrcsup/MRCSUP/trace/alert_MRCSUP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCTST_database_alert_log_on_mrcdb01",
  "path": " /mrc/tst/db/11.2.0/admin/MRCTST_mrcdb01/diag/rdbms/mrctst/MRCTST/trace/alert_MRCTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCPRD_database_alert_log_on_mrcdb11",
  "path": " /mrc/prd/db/diag/rdbms/mrcprd/MRCPRD/trace/alert_MRCPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCBIWD_database_alert_log_on_mrcobdb01",
  "path": " /mrc/dev/ora/db/diag/rdbms/mrcbiwd/MRCBIWD/trace/alert_MRCBIWD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCBIWT_database_alert_log_on_mrcobdb01",
  "path": " /mrc/tst/ora/db/diag/rdbms/mrcbiwt/MRCBIWT/trace/alert_MRCBIWT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCBIWP_database_alert_log_on_mrcobdb11",
  "path": " /mrc/prd/ora/db/diag/rdbms/mrcbiwp/MRCBIWP/trace/alert_MRCBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCSOLD_database_alert_log_on_mrcsoldb01.dibos02.di-cloud.com",
  "path": " /mrc/sold/db/admin/MRCSOLD/diag/rdbms/mrcsold/MRCSOLD/trace/alert_MRCSOLD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCSOLT_database_alert_log_on_mrcsoldb02.dibos02.di-cloud.com",
  "path": " /mrc/solt/db/admin/MRCSOLT/diag/rdbms/mrcsolt/MRCSOLT/trace/alert_MRCSOLT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MRCSOLP_database_alert_log_on_mrcsoldb11.dibos02.di-cloud.com",
  "path": " /mrc/solp/db/admin/MRCSOLP/diag/rdbms/mrcsolp/MRCSOLP/trace/alert_MRCSOLP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "DEV_database_alert_log_on_ebsd1pd1",
  "path": " /u01/DEV/db/diag/rdbms/dev/DEV/trace/alert_DEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "UAT_database_alert_log_on_ebst1pd1",
  "path": " /u01/UAT/db/diag/rdbms/uat/UAT/trace/alert_UAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PROD_database_alert_log_on_ebsp1pd1",
  "path": " /u01/PROD/db/diag/rdbms/prod/PROD/trace/alert_PROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MANHDB_database_alert_log_on_manh-db",
  "path": " /",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OTMPROD_database_alert_log_on_otmp1pd1",
  "path": " /u01/OTMPROD/oracle/diag/rdbms/otmprod/OTMPROD/trace/alert_OTMPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BIPROD_database_alert_log_on_prod-bi-db",
  "path": " /u01/oracle/BIPROD/diag/rdbms/biprod/BIPROD/trace/alert_BIPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SBIDB_database_alert_log_on_sbidb.niagarawater.com",
  "path": " /u01/oracle/SBIDB/diag/rdbms/sbidb/SBIDB/trace/alert_SBIDB.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SOAPROD_database_alert_log_on_soap1pd1",
  "path": " /u10/oracle/SOAPROD/diag/rdbms/soaprod/SOAPROD/trace/alert_SOAPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SBIDB_database_alert_log_on_sbidb",
  "path": " /",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OPRBIDEV_database_alert_log_on_oprmacdb01",
  "path": " /opr/bidev/diag/rdbms/oprbidev/OPRBIDEV/trace/alert_OPRBIDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OPRDEV_database_alert_log_on_oprmacdb01",
  "path": " /opr/dev/diag/rdbms/oprdev/OPRDEV/trace/alert_OPRDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OPRPRD_database_alert_log_on_oprdb11.slc01.di-cloud.com",
  "path": " /opr/prd/diag/rdbms/oprprddr/OPRPRD/trace/alert_OPRPRD.log",
  "reg": " /ORA-(?!00060)\\d+/"
 },
 {
  "name": "OPRBIPRD_database_alert_log_on_oprdb11",
  "path": " /opr/biprd/diag/rdbms/oprbiprd/OPRBIPRD/trace/alert_OPRBIPRD.log",
  "reg": " /ORA-(?!10173)\\d+/"
 },
 {
  "name": "OPRPRD_database_alert_log_on_oprdb11",
  "path": " /opr/prd/diag/rdbms/oprprd/OPRPRD/trace/alert_OPRPRD.log",
  "reg": " /ORA-(?!00060)\\d+/"
 },
{
  "name": "BAPRODTX_database_alert_log_on_axprod5",
  "path": " /u01/app/oracle/admin/diag/rdbms/baprodtx/BAPRODTX/trace/alert_BAPRODTX.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BAPRODKS_database_alert_log_on_axprod6",
  "path": " /u01/app/oracle/admin/diag/rdbms/baprodks/BAPRODKS/trace/alert_BAPRODKS.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BAPRODOK_database_alert_log_on_axprod9",
  "path": " /u01/app/oracle/admin/diag/rdbms/baprodok/BAPRODOK/trace/alert_BAPRODOK.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OGSOAP_database_alert_log_on_axprod1",
  "path": " /u01/app/oracle/db/tech_st/11.2.0.3/admin/OGSOAP_axprod1/diag/rdbms/ogsoap/OGSOAP/trace/alert_OGSOAP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "CALLPROD_database_alert_log_on_axprod10",
  "path": " /u01/app/oracle/admin/CALLPROD/bdump/alert_CALLPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CASHPROD_database_alert_log_on_axprod10",
  "path": " /u01/app/oracle/admin/CASHPROD/bdump/alert_CASHPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FLOGG_database_alert_log_on_axprod10",
  "path": " /u01/app/oracle/admin/FLOGG/bdump/alert_FLOGG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FLOKG_database_alert_log_on_axprod10",
  "path": " /u01/app/oracle/admin/FLOKG/bdump/alert_FLOKG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FLOTG_database_alert_log_on_axprod10",
  "path": " /u01/app/oracle/admin/FLOTG/bdump/alert_FLOTG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MAAPROD_database_alert_log_on_axprod10",
  "path": " /u01/app/oracle/admin/MAAPROD/bdump/alert_MAAPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MCHKPROD_database_alert_log_on_axprod10",
  "path": " /u01/app/oracle/admin/MCHKPROD/bdump/alert_MCHKPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AIPMG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/aipmg/AIPMG/trace/alert_AIPMG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "APWXPROD_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/apwxprod/APWXPROD/trace/alert_APWXPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "CRDSG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/crdsg/CRDSG/trace/alert_CRDSG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "FNETG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/fnetg/FNETG/trace/alert_FNETG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "HARVSTG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/harvstg/HARVSTG/trace/alert_HARVSTG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "IPSPROD_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/ipsprod/IPSPROD/trace/alert_IPSPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "JPGDMG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/jpgdmg/JPGDMG/trace/alert_JPGDMG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "JPGTMG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/jpgtmg/JPGTMG/trace/alert_JPGTMG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "LANDG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/landg/LANDG/trace/alert_LANDG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "PICNG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/picng/PICNG/trace/alert_PICNG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "PWPG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/pwpg/PWPG/trace/alert_PWPG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "RAIPMG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/raipmg/RAIPMG/trace/alert_RAIPMG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "TIBADMG_database_alert_log_on_axprod12",
  "path": " /u01/app/oracle/diag/rdbms/tibadmg/TIBADMG/trace/alert_TIBADMG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "PCADPROD_database_alert_log_on_axprod13",
  "path": " /u01/app/oracle/diag/rdbms/pcadprod/PCADPROD/trace/alert_PCADPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BWKSPROD_database_alert_log_on_axprod14",
  "path": " /u01/app/oracle/admin/diag/rdbms/bwksprod/BWKSPROD/trace/alert_BWKSPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FEBPROD_database_alert_log_on_axprod14",
  "path": " /u01/app/oracle/admin/diag/rdbms/febprod/FEBPROD/trace/alert_FEBPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MAXPROD_database_alert_log_on_axprod15",
  "path": " /u01/app/oracle/admin/MAXPROD/bdump/alert_MAXPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "ADMNG_database_alert_log_on_axprod16",
  "path": " /u01/app/oracle/admin/ADMNG/bdump/alert_ADMNG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "CMMG_database_alert_log_on_axprod16",
  "path": " /u01/app/oracle/admin/CMMG/bdump/alert_CMMG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "GSPAG_database_alert_log_on_axprod16",
  "path": " /u01/app/oracle/admin/GSPAG/bdump/alert_GSPAG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "KGSDG_database_alert_log_on_axprod16",
  "path": " /u01/app/oracle/admin/KGSDG/bdump/alert_KGSDG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "KSLDG_database_alert_log_on_axprod16",
  "path": " /u01/app/oracle/admin/KSLDG/bdump/alert_KSLDG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OKLDG_database_alert_log_on_axprod16",
  "path": " /u01/app/oracle/admin/OKLDG/bdump/alert_OKLDG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ONGDG_database_alert_log_on_axprod16",
  "path": " /u01/app/oracle/admin/ONGDG/bdump/alert_ONGDG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|1652)\\d+/"
 },
 {
  "name": "RISKG_database_alert_log_on_axprod17",
  "path": " /u01/app/oracle/diag/rdbms/riskg/RISKG/trace/alert_RISKG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PQDISTRG_database_alert_log_on_axprod24",
  "path": " /u01/app/oracle/diag/rdbms/pqdistrg/PQDISTRG/trace/alert_PQDISTRG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "MAXSPROD_database_alert_log_on_axprod25",
  "path": " /u01/app/oracle/admin/diag/rdbms/maxsprod/MAXSPROD/trace/alert_MAXSPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
 {
  "name": "TPSKPROD_database_alert_log_on_axprod25",
  "path": " /u01/app/oracle/admin/diag/rdbms/tpskprod/TPSKPROD/trace/alert_TPSKPROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|29904)\\d+/"
 },
{
  "name": "OAPRD1_database_alert_log_on_rsprod1",
  "path": " /u01/app/oracle/db/tech_st/11.2.0.3/admin/OAPRD1_rsprod1/diag/rdbms/oaprd1/OAPRD1/trace/alert_OAPRD1.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913|00443|00450)\\d+/"
 },
 {
  "name": "PGPL_database_alert_log_on_rsprod14",
  "path": " /u01/app/oracle/admin/PGPL/bdump/alert_PGPL.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913|00443|00450)\\d+/"
 },
 {
  "name": "PMGT_database_alert_log_on_rsprod14",
  "path": " /u01/app/oracle/admin/PMGT/bdump/alert_PMGT.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913|00443|00450)\\d+/"
 },
 {
  "name": "POKT_database_alert_log_on_rsprod14",
  "path": " /u01/app/oracle/admin/POKT/bdump/alert_POKT.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913|00443|00450)\\d+/"
 },
 {
  "name": "PVGT_database_alert_log_on_rsprod14",
  "path": " /u01/app/oracle/admin/PVGT/bdump/alert_PVGT.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913|00443|00450)\\d+/"
 },

 {
  "name": "OXFBIWT_database_alert_log_on_oxfdb201.dibos02.di-cloud.com",
  "path": " /oxf/biwt/db/diag/rdbms/oxfbiwt/OXFBIWT/trace/alert_OXFBIWT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OXFDEV_database_alert_log_on_oxfdb201.dibos02.di-cloud.com",
  "path": " /oxf/dev/db/diag/rdbms/oxfdev/OXFDEV/trace/alert_OXFDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012|06502|06512)\\d+/"
 },
 {
  "name": "OXFTST_database_alert_log_on_oxfdb201.dibos02.di-cloud.com",
  "path": " /oxf/tst/db/diag/rdbms/oxftst/OXFTST/trace/alert_OXFTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012|06502|06512)\\d+/"
 },
 {
  "name": "OXFPRD_database_alert_log_on_oxfdb101.dibos02.di-cloud.com",
  "path": " /oxf/prd/db/diag/rdbms/oxfprd/OXFPRD/trace/alert_OXFPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012|06502|06512)\\d+/"
 },
 {
  "name": "OXFBIWD_database_alert_log_on_oxfdb201.dibos02.di-cloud.com",
  "path": " /oxf/biwd/db/diag/rdbms/oxfbiwd/OXFBIWD/trace/alert_OXFBIWD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OXFBIWT_database_alert_log_on_oxfdb201.dibos02.di-cloud.com",
  "path": " /oxf/biwt/db/diag/rdbms/oxfbiwt/OXFBIWT/trace/alert_OXFBIWT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OXFBIWP_database_alert_log_on_oxfdb101.dibos02.di-cloud.com",
  "path": " /oxf/biwp/db/diag/rdbms/oxfbiwp/OXFBIWP/trace/alert_OXFBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 }
,
{
  "name": "PERPOC_database_alert_log_on_perdb111.dibos02.di-cloud.com",
  "path": " /per/poc/db/diag/rdbms/perpoc/PERPOC/trace/alert_PERPOC.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "QDXTST2_database_alert_log_on_qdxdb202.dibos02.di-cloud.com",
  "path": " /qdx/tst/db/diag/rdbms/qdxtst/QDXTST2/trace/alert_QDXTST2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "QDXTST1_database_alert_log_on_qdxdb201.dibos02.di-cloud.com",
  "path": " /qdx/tst/db/diag/rdbms/qdxtst/QDXTST1/trace/alert_QDXTST1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "QDXPRD2_database_alert_log_on_qdxdb102.dibos02.di-cloud.com",
  "path": " /qdx/prd/db/diag/rdbms/qdxprd/QDXPRD2/trace/alert_QDXPRD2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "QDXPRD1_database_alert_log_on_qdxdb101.dibos02.di-cloud.com",
  "path": " /qdx/prd/db/diag/rdbms/qdxprd/QDXPRD1/trace/alert_QDXPRD1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "DEV_database_alert_log_on_ramseydev",
  "path": " /d01/oracle/devdb/10.2.0/admin/DEV_ramseydev/bdump/alert_DEV.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PROD_database_alert_log_on_ramseyprd",
  "path": " /p01/oracle/proddb/10.2.0/admin/PROD_ramseyprd/bdump/alert_PROD.log",
  "reg": " /ORA-(?!00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "LIVE1_database_alert_log_on_\\\\profitkey.eskridge1.com",
  "path": " \\\\192.168.1.9\\d$\\oracle\\diag\\rdbms\\pk1\\live1\\trace\\alert_live1.log",
  "reg": " /ORA-(?!07445|00060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "RDUDEV_database_alert_log_on_rduora-dev",
  "path": " /oracle/RDUDEV/devdb/diag/rdbms/rdudev/RDUDEV/trace/alert_RDUDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "RDUTST_database_alert_log_on_rduora-tst",
  "path": " /oracle/RDUTST/tstdb/diag/rdbms/rdutst/RDUTST/trace/alert_RDUTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PROD_database_alert_log_on_rduoraprod",
  "path": " /oracle/PROD/proddb/diag/rdbms/prod/PROD/trace/alert_PROD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "SFIDEV_database_alert_log_on_sfidb01",
  "path": " /sfi/dev/db/diag/rdbms/sfidev/SFIDEV/trace/alert_SFIDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/ "
 },
 {
  "name": "SFISUP_database_alert_log_on_sfidb01",
  "path": " /sfi/sup/db/diag/rdbms/sfisup/SFISUP/trace/alert_SFISUP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/ "
 },
 {
  "name": "SFITST_database_alert_log_on_sfidb01",
  "path": " /sfi/tst/db/diag/rdbms/sfitst/SFITST/trace/alert_SFITST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/ "
 },
 {
  "name": "SFIPRD_database_alert_log_on_sfidb11",
  "path": " /sfi/prd/db/diag/rdbms/sfiprd/SFIPRD/trace/alert_SFIPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "DEVL1_database_alert_log_on_shotestucs01",
  "path": " /a03/app/oracle/diag/rdbms/devl/DEVL1/trace/alert_DEVL1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012|00001|01403|01422|08103|06512|02050|03135|02063)\\d+/ "
 },
 {
  "name": "DEVL2_database_alert_log_on_shotestucs02",
  "path": " /a03/app/oracle/diag/rdbms/devl/DEVL2/trace/alert_DEVL2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012|00001|01403|01422|08103|06512|02050|03135|02063)\\d+/ "
 },
 {
  "name": "PTCH2_database_alert_log_on_shotestucs02",
  "path": " /a01/app/oracle/diag/rdbms/ptch/PTCH2/trace/alert_PTCH2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012|00001|01403|01422|08103|06512|02050|03135|02063)\\d+/ "
 },
 {
  "name": "PTCH1_database_alert_log_on_shotestucs01",
  "path": " /a01/app/oracle/diag/rdbms/ptch/PTCH1/trace/alert_PTCH1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012|00001|01403|01422|08103|06512|02050|03135|02063)\\d+/ "
 },
 {
  "name": "TEST1_database_alert_log_on_shotestucs01",
  "path": " /a04/app/oracle/diag/rdbms/test/TEST1/trace/alert_TEST1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012|00001|01403|01422|08103|06512|02050|03135|02063)\\d+/ "
 },
 {
  "name": "TEST2_database_alert_log_on_shotestucs02",
  "path": " /a04/app/oracle/diag/rdbms/test/TEST2/trace/alert_TEST2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012|00001|01403|01422|08103|06512|02050|03135|02063)\\d+/ "
 },
 {
  "name": "PROD1_database_alert_log_on_shoprod01.sterilite.com",
  "path": " /a01/app/oracle/diag/rdbms/prod/PROD1/trace/alert_PROD1.log",
  "reg": " /(ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|15310|01555|03135|600|00600.*ksfdchkfob1|07445.*kgiPinObject|07445.*kkqfppUNPVTPushPredOK)\\d+)/"
 },
 {
  "name": "PROD2_database_alert_log_on_shoprod02.sterilite.com",
  "path": " /a01/app/oracle/diag/rdbms/prod/PROD2/trace/alert_PROD2.log",
  "reg": " /(ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|15310|01555|03135|600|00600.*ksfdchkfob1|07445.*kgiPinObject|07445.*kkqfppUNPVTPushPredOK)\\d+)/"
 },
 {
  "name": "PRODDR_database_alert_log_on_twnprod01.sterilite.com",
  "path": " /a01/app/oracle/product/11.2.0/admin/PRODDR1_twnprod01/diag/rdbms/proddr/PRODDR1/trace/alert_PRODDR1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|15310|01555|03135|600|00600.*ksfdchkfob1|07445.*kgiPinObject)\\d+/"
 }
,
{
  "name": "SEPDEV_database_alert_log_on_sepdb01",
  "path": " /sep/dev/ora/db/tech_st/11.2.0/admin/SEPDEV_sepdb01/diag/rdbms/sepdev/SEPDEV/trace/alert_SEPDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|02019|12154)\\d+/"
 },
 {
  "name": "SEPTST_database_alert_log_on_sepdb01",
  "path": " /sep/tst/ora/db/tech_st/11.2.0/admin/SEPTST_sepdb01/diag/rdbms/septst/SEPTST/trace/alert_SEPTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|02019|12154)\\d+/"
 },
 {
  "name": "SEPIDM_database_alert_log_on_sepdb02",
  "path": " /sep/idm/ora/db/tech_st/11.2.0/admin/SEPIDM_sepdb02/diag/rdbms/sepidm/SEPIDM/trace/alert_SEPIDM.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|28500|02063)\\d+/"
 },
 {
  "name": "SEPPRD_database_alert_log_on_sepdb11",
  "path": " /sep/prd/ora/db/tech_st/diag/rdbms/sepprd/SEPPRD/trace/alert_SEPPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|604|48913|28500|02063|00700)\\d+/"
 },
 {
  "name": "SEPHYPD_database_alert_log_on_sephypdb201",
  "path": " /sep/hypd/db/diag/rdbms/sephypd/SEPHYPD/trace/alert_SEPHYPD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SEPHYPP_database_alert_log_on_sephypdb101",
  "path": " /sep/hypp/db/diag/rdbms/sephypp/SEPHYPP/trace/alert_SEPHYPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SEPIDMT_database_alert_log_on_sepidmdb01.dibos02.di-cloud.com",
  "path": " /sep/idmt/db/diag/rdbms/sepidmt/SEPIDMT/trace/alert_SEPIDMT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|24761)\\d+/"
 },
 {
  "name": "SEPIDMP_database_alert_log_on_sepidmdb11",
  "path": " /sep/idmp/db/diag/rdbms/sepidmp/SEPIDMP/trace/alert_SEPIDMP.log",
  "reg": " /ORA-(?!00060|24761|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SEPBIWD_database_alert_log_on_sepobidb02",
  "path": " /sep/biwd/db/diag/rdbms/sepbiwd/SEPBIWD/trace/alert_SEPBIWD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SEPBIWP_database_alert_log_on_sepobidb12",
  "path": " /sep/biwp/db/diag/rdbms/sepbiwp/SEPBIWP/trace/alert_SEPBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SEPBIWP_DR_database_alert_log_on_sepobidb12.slc01.di-cloud.com",
  "path": " /sep/biwp/db/diag/rdbms/sepbiwp/SEPBIWP/trace/alert_SEPBIWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "TACSTG_database_alert_log_on_tacdb02",
  "path": " /tac/stg/db/tech_st/diag/rdbms/tacstg/TACSTG/trace/alert_TACSTG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|14403)\\d+/"
 },
 {
  "name": "TACTST_database_alert_log_on_tacdb03",
  "path": " /tac/tst/db/tech_st/diag/rdbms/tactst/TACTST/trace/alert_TACTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|14403)\\d+/"
 },
 {
  "name": "TACDEV_database_alert_log_on_tacdb04",
  "path": " /tac/dev/db/tech_st/diag/rdbms/tacdev/TACDEV/trace/alert_TACDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|14403)\\d+/"
 },
 {
  "name": "TACPRD_database_alert_log_on_tacdb11",
  "path": " /tac/prd/db/tech_st/diag/rdbms/tacprd/TACPRD/trace/alert_TACPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|14403)\\d+/"
 },
 {
  "name": "TACFMWT_database_alert_log_on_tacfmwdb01.dibos02.di-cloud.com",
  "path": " /tac/tst/db/diag/rdbms/tacfmwt/TACFMWT/trace/alert_TACFMWT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TACFMWP_database_alert_log_on_tacfmwdb11.dibos02.di-cloud.com",
  "path": " /tac/prd/db/diag/rdbms/tacfmwp/TACFMWP/trace/alert_TACFMWP.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "TRCUPG1_database_alert_log_on_trcdb02",
  "path": " /trc/tst/db/diag/rdbms/trcupg1/TRCUPG1/trace/alert_TRCUPG1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRCUPG2_database_alert_log_on_trcdb02",
  "path": " /trc/dev/db/11.2.0.4/admin/TRCUPG2_trcdb02/diag/rdbms/trcupg2/TRCUPG2/trace/alert_TRCUPG2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRCPRD_database_alert_log_on_trcdb12",
  "path": " /trc/prd/db/diag/rdbms/trcprd/TRCPRD/trace/alert_TRCPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ORCL_database_alert_log_on_trcrsdb01",
  "path": " /oracle/db/app/oracle/diag/rdbms/orcl/orcl/trace/alert_orcl.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ORCL_database_alert_log_on_trcrsdb11",
  "path": " /oracle/db/app/oracle/diag/rdbms/orcl/orcl/trace/alert_orcl.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "TRVCHSIP_database_alert_log_on_trvochdb11",
  "path": " /trv/prd/sie/db/diag/rdbms/trvchsip/TRVCHSIP/trace/alert_TRVCHSIP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRMDEV01_database_alert_log_on_trvbrmdb01",
  "path": " /trv/brm/dev/diag/rdbms/brmdev01/BRMDEV01/trace/alert_BRMDEV01.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRMDEV02_database_alert_log_on_trvbrmdb02",
  "path": " /trv/brm/dev/diag/rdbms/brmdev02/brmdev02/trace/alert_brmdev02.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRMDEV03_database_alert_log_on_trvbrmdb03",
  "path": " /trv/brm/diag/rdbms/brmdev03/brmdev03/trace/alert_brmdev03.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRMDEV04_database_alert_log_on_trvbrmdb04",
  "path": " /trv/brm/diag/rdbms/brmdev04/brmdev04/trace/alert_brmdev04.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRMDEV05_database_alert_log_on_trvbrmdb05",
  "path": " /trv/brm/trn/diag/rdbms/brmdev05/brmdev05/trace/alert_brmdev05.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRMUAT06_database_alert_log_on_trvbrmdb06",
  "path": " /trv/brm/uat/db/diag/rdbms/brmuat06/brmuat06/trace/alert_brmuat06.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRMPRD_database_alert_log_on_trvbrmprd-vip",
  "path": " /trv/brm/prd/db/diag/rdbms/brmprd/BRMPRD/trace/alert_BRMPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BRMPRD_database_alert_log_on_trvbrmdb11.slc01.di-cloud.com",
  "path": " /trv/brm/prd/db/diag/rdbms/brmprdsb/BRMPRD/trace/alert_BRMPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVUAT_database_alert_log_on_trvdb01",
  "path": " /trv/uat/db/11.2.0/admin/TRVUAT_trvdb01/diag/rdbms/trvuat/TRVUAT/trace/alert_TRVUAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVDEV_database_alert_log_on_trvdb03",
  "path": " /trv/dev/db/11.2.0/admin/TRVDEV_trvdb03/diag/rdbms/trvdev/TRVDEV/trace/alert_TRVDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVPCH_database_alert_log_on_trvdb03",
  "path": " /trv/pch/db/11.2.0/admin/TRVPCH_trvdb03/diag/rdbms/trvpch/TRVPCH/trace/alert_TRVPCH.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVTST_database_alert_log_on_trvdb03",
  "path": " /trv/tst/db/11.2.0/admin/TRVTST_trvdb03/diag/rdbms/trvtst/TRVTST/trace/alert_TRVTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVHRD_database_alert_log_on_trvdb04",
  "path": " /trv/hrd/db/11.2.0/admin/TRVHRD_trvdb04/diag/rdbms/trvhrd/TRVHRD/trace/alert_TRVHRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVSTG_database_alert_log_on_trvdb04",
  "path": " /trv/stg/db/11.2.0/admin/TRVSTG_trvdb04/diag/rdbms/trvstg/TRVSTG/trace/alert_TRVSTG.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVTRN_database_alert_log_on_trvdb04",
  "path": " /trv/trn/db/10.2.0/admin/TRVTRN_trvdb04/bdump/alert_TRVTRN.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVPRD_database_alert_log_on_trvdb-vip",
  "path": " /trv/prd/db/diag/rdbms/trvprd/TRVPRD/trace/alert_TRVPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVHYDRMD_database_alert_log_on_trvochdb01",
  "path": " /trv/tst/drmd/db/diag/rdbms/trvhydrmd/TRVHYDRMD/trace/alert_TRVHYDRMD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVHYDRMQ_database_alert_log_on_trvochdb02",
  "path": " /trv/drmq/db/diag/rdbms/trvhydrmq/TRVHYDRMQ/trace/alert_TRVHYDRMQ.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVHYDRMU_database_alert_log_on_trvochdb03.dibos02.di-cloud.com",
  "path": " /trv/drmu/db/diag/rdbms/trvhydrmu/TRVHYDRMU/trace/alert_TRVHYDRMU.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVIND_database_alert_log_on_trvindb01",
  "path": " /trv/dev/in/db/diag/rdbms/trvind/TRVIND/trace/alert_TRVIND.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVINP_database_alert_log_on_trvindb11",
  "path": " /trv/prd/in/db/diag/rdbms/trvinp/TRVINP/trace/alert_TRVINP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVHYDRMP_database_alert_log_on_trvochdb11.dibos02.di-cloud.com",
  "path": " /trv/drmp/db/diag/rdbms/trvhydrmp/TRVHYDRMP/trace/alert_TRVHYDRMP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVOPD_database_alert_log_on_trvopdb01",
  "path": " /trv/dev/op/db/admin/TRVOPD/bdump/alert_TRVOPD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVOPP_database_alert_log_on_trvopdb11",
  "path": " /trv/prd/op/db/admin/TRVOPP/bdump/alert_TRVOPP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVCHBIT_database_alert_log_on_trvochdb01",
  "path": " /trv/tst/bi/db/diag/rdbms/trvchbit/TRVCHBIT/trace/alert_TRVCHBIT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVCHDRT_database_alert_log_on_trvochdb01",
  "path": " /trv/tst/drm/db/diag/rdbms/trvchdrt/TRVCHDRT/trace/alert_TRVCHDRT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVCHSIT_database_alert_log_on_trvochdb01",
  "path": " /trv/tst/sie/db/diag/rdbms/trvchsit/TRVCHSIT/trace/alert_TRVCHSIT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVCHSIQ_database_alert_log_on_trvochdb02",
  "path": " /trv/qa/db/diag/rdbms/trvchsiq/TRVCHSIQ/trace/alert_TRVCHSIQ.log",
  "reg": " /ORA-(?!000060|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVCHSIU_database_alert_log_on_trvochdb03.dibos02.di-cloud.com",
  "path": " /trv/uat/ora/db/diag/rdbms/trvchsiu/TRVCHSIU/trace/alert_TRVCHSIU.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "TRVCHSIP_database_alert_log_on_trvochdb11",
  "path": " /trv/prd/sie/db/diag/rdbms/trvchsip/TRVCHSIP/trace/alert_TRVCHSIP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "STATDEV_database_alert_log_on_trvstat11",
  "path": " /trv/stat/appl/diag/rdbms/statdev/STATDEV/trace/alert_STATDEV.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "STAT_database_alert_log_on_trvstat11",
  "path": " /trv/stat/appl/diag/rdbms/stat/STAT/trace/alert_STAT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "INFORM46_database_alert_log_on_\\\\orasrv04.veristat.local",
  "path": " \\\\orasrv04.veristat.local\\D$\\oracle\\Admin\\inform46\\bdump\\alert_inform46.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "C47PRD1_database_alert_log_on_\\\\orasrv05.veristat.local",
  "path": " \\\\orasrv05.veristat.local\\D$\\oracle\\Admin\\c47prd1\\bdump\\alert_c47prd1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|07445\\: exception encountered\\: core dump \\[ACCESS_VIOLATION\\])\\d+/"
 },
 {
  "name": "CATDB2_database_alert_log_on_\\\\orasrv05.veristat.local",
  "path": " \\\\orasrv05.veristat.local\\D$\\oracle\\Admin\\catdb2\\bdump\\alert_catdb2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "EXARCH01_database_alert_log_on_\\\\orasrv05.veristat.local",
  "path": " \\\\orasrv05.veristat.local\\D$\\oracle\\Admin\\exarch01\\bdump\\alert_exarch01.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "VTMS_database_alert_log_on_\\\\orasrv05.veristat.local",
  "path": " \\\\orasrv05.veristat.local\\D$\\oracle\\Admin\\vtms\\bdump\\alert_vtms.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "NSP1_database_alert_log_on_s608923dl2sl11",
  "path": " /vha/prd/ora/db/nsp/diag/rdbms/nsp/NSP1/trace/alert_NSP1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297|08103)\\d+/"
 },
 {
  "name": "NSP2_database_alert_log_on_s608923dl2sl12",
  "path": " /vha/prd/ora/db/nsp/diag/rdbms/nsp/NSP2/trace/alert_NSP2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297|08103)\\d+/"
 },
 {
  "name": "APTSIT_database_alert_log_on_s608923dl2sl73.usdlls2.savvis.net",
  "path": " /apt/sit/ora/db/apt/diag/rdbms/aptsit/APTSIT/trace/alert_APTSIT.log",
  "reg": " /ORA-(?!20|00020|00060|000060|28|18913|3136|03149|03137|609|48913|04031|3297)\\d+/"
 },
 {
  "name": "HYBDEV_database_alert_log_on_s608923dl2sl73.usdlls2.savvis.net",
  "path": " /apt/sit/ora/db/hyb/diag/rdbms/hybdev/HYBDEV/trace/alert_HYBDEV.log",
  "reg": " /ORA-(?!20|00020|00060|000060|28|18913|3136|03149|03137|609|48913|04031|3297)\\d+/"
 },
 {
  "name": "MKTDEV_database_alert_log_on_s608923dl2sl73.usdlls2.savvis.net",
  "path": " /apt/sit/ora/db/mkt/diag/rdbms/mktdev/MKTDEV/trace/alert_MKTDEV.log",
  "reg": " /ORA-(?!20|00020|00060|000060|28|18913|3136|03149|03137|609|48913|04031|3297)\\d+/"
 },
 {
  "name": "NED_database_alert_log_on_s608923dl2sl73.usdlls2.savvis.net",
  "path": " /apt/sit/ora/db/ned/diag/rdbms/ned/NED/trace/alert_NED.log",
  "reg": " /ORA-(?!20|00020|00060|000060|28|18913|3136|03149|03137|609|48913|04031|3297)\\d+/"
 },
 {
  "name": "NPD_database_alert_log_on_s608923dl2sl73.usdlls2.savvis.net",
  "path": " /apt/sit/ora/db/npd/diag/rdbms/npd/NPD/trace/alert_NPD.log",
  "reg": " /ORA-(?!20|00020|00060|000060|28|18913|3136|03149|03137|609|48913|04031|3297)\\d+/"
 },
 {
  "name": "APTUAT2_database_alert_log_on_s608923dl2sl14.usdlls2.savvis.net",
  "path": " /vha/uat/ora/db/int/diag/rdbms/aptuat/APTUAT2/trace/alert_APTUAT2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "APTUAT1_database_alert_log_on_s608923dl2sl13.usdlls2.savvis.net",
  "path": " /vha/uat/ora/db/int/diag/rdbms/aptuat/APTUAT1/trace/alert_APTUAT1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "HYBUAT2_database_alert_log_on_s608923dl2sl14",
  "path": " /vha/uat/ora/db/hyb/diag/rdbms/hybuat/HYBUAT2/trace/alert_HYBUAT2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "HYBUAT1_database_alert_log_on_s608923dl2sl13",
  "path": " /vha/uat/ora/db/hyb/diag/rdbms/hybuat/HYBUAT1/trace/alert_HYBUAT1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "MKTUAT1_database_alert_log_on_s608923dl2sl13",
  "path": " /vha/uat/ora/db/mkt/diag/rdbms/mktuat/MKTUAT1/trace/alert_MKTUAT1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "MKTUAT2_database_alert_log_on_s608923dl2sl14",
  "path": " /vha/uat/ora/db/mkt/diag/rdbms/mktuat/MKTUAT2/trace/alert_MKTUAT2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "NEQ1_database_alert_log_on_s608923dl2sl13",
  "path": " /vha/uat/ora/db/neq/diag/rdbms/neq/NEQ1/trace/alert_NEQ1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "NEQ2_database_alert_log_on_s608923dl2sl14",
  "path": " /vha/uat/ora/db/neq/diag/rdbms/neq/NEQ2/trace/alert_NEQ2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "NPQ2_database_alert_log_on_s608923dl2sl14",
  "path": " /vha/uat/ora/db/npq/diag/rdbms/npq/NPQ2/trace/alert_NPQ2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "NPQ1_database_alert_log_on_s608923dl2sl13",
  "path": " /vha/uat/ora/db/npq/diag/rdbms/npq/NPQ1/trace/alert_NPQ1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "VHAINTU2_database_alert_log_on_s608923dl2sl14",
  "path": " /vha/uat/ora/db/int/diag/rdbms/vhaintu/VHAINTU2/trace/alert_VHAINTU2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "VHAINTU1_database_alert_log_on_s608923dl2sl13",
  "path": " /vha/uat/ora/db/int/diag/rdbms/vhaintu/VHAINTU1/trace/alert_VHAINTU1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "HYBSIT_database_alert_log_on_dvhals31",
  "path": " /vha/sit/ora/db/hyb/diag/rdbms/hybsit/HYBSIT/trace/alert_HYBSIT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "MKTSIT_database_alert_log_on_dvhals31",
  "path": " /vha/sit/ora/db/mkt/diag/rdbms/mktsit/MKTSIT/trace/alert_MKTSIT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "VHAINT_database_alert_log_on_dvhals31",
  "path": " /vha/sit/ora/db/int/diag/diag/rdbms/vhaint/VHAINT/trace/alert_VHAINT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "VHAINTD_database_alert_log_on_dvhals31",
  "path": " /vha/sit/ora/db/int/diag/rdbms/vhaintd/VHAINTD/trace/alert_VHAINTD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "APTPRD2_database_alert_log_on_s608923dl2sl12.usdlls2.savvis.net",
  "path": " /vha/prd/ora/db/prd/diag/rdbms/aptprd/APTPRD2/trace/alert_APTPRD2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "APTPRD1_database_alert_log_on_s608923dl2sl11.usdlls2.savvis.net",
  "path": " /vha/prd/ora/db/prd/diag/rdbms/aptprd/APTPRD1/trace/alert_APTPRD1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "HYBPRD1_database_alert_log_on_s608923dl2sl11",
  "path": " /vha/prd/ora/db/hyb/diag/rdbms/hybprd/HYBPRD1/trace/alert_HYBPRD1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "HYBPRD2_database_alert_log_on_s608923dl2sl12",
  "path": " /vha/prd/ora/db/hyb/diag/rdbms/hybprd/HYBPRD2/trace/alert_HYBPRD2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "MKTPRD2_database_alert_log_on_s608923dl2sl12",
  "path": " /vha/prd/ora/db/mkt/diag/rdbms/mktprd/MKTPRD2/trace/alert_MKTPRD2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "MKTPRD1_database_alert_log_on_s608923dl2sl11",
  "path": " /vha/prd/ora/db/mkt/diag/rdbms/mktprd/MKTPRD1/trace/alert_MKTPRD1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "NEP1_database_alert_log_on_s608923dl2sl11",
  "path": " /vha/prd/ora/db/nep/diag/rdbms/nep/NEP1/trace/alert_NEP1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297|08103)\\d+/"
 },
 {
  "name": "NEP2_database_alert_log_on_s608923dl2sl12",
  "path": " /vha/prd/ora/db/nep/diag/rdbms/nep/NEP2/trace/alert_NEP2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297|08103)\\d+/"
 },
 {
  "name": "NPP2_database_alert_log_on_s608923dl2sl12",
  "path": " /vha/prd/ora/db/npp/diag/rdbms/npp/NPP2/trace/alert_NPP2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "NPP1_database_alert_log_on_s608923dl2sl11",
  "path": " /vha/prd/ora/db/npp/diag/rdbms/npp/NPP1/trace/alert_NPP1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "NSP2_database_alert_log_on_s608923dl2sl12",
  "path": " /vha/prd/ora/db/nsp/diag/rdbms/nsp/NSP2/trace/alert_NSP2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297|08103)\\d+/"
 },
 {
  "name": "NSP1_database_alert_log_on_s608923dl2sl11",
  "path": " /vha/prd/ora/db/nsp/diag/rdbms/nsp/NSP1/trace/alert_NSP1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297|08103)\\d+/"
 },
 {
  "name": "VHAINTP1_database_alert_log_on_s608923dl2sl11",
  "path": " /vha/prd/ora/db/int/diag/rdbms/vhaintp/VHAINTP1/trace/alert_VHAINTP1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "VHAINTP2_database_alert_log_on_s608923dl2sl12",
  "path": " /vha/prd/ora/db/int/diag/rdbms/vhaintp/VHAINTP2/trace/alert_VHAINTP2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|3297)\\d+/"
 },
 {
  "name": "D1ERP_database_alert_log_on_nyaderpdb05.na.weightwatchers.net",
  "path": " /u01/app/oracle/admin/D1ERP/bdump/alert_D1ERP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "D2ERP_database_alert_log_on_nyaderpdb05.na.weightwatchers.net",
  "path": " /u01/app/oracle/diag/rdbms/d2erp/D2ERP/trace/alert_D2ERP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "PSERP_database_alert_log_on_nyaderpdb05.na.weightwatchers.net",
  "path": " /u01/app/oracle/admin/PSERP/bdump/alert_PSERP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "Q1ERP_database_alert_log_on_nyaderpdb05.na.weightwatchers.net",
  "path": " /u01/app/oracle/diag/rdbms/q1erp/Q1ERP/trace/alert_Q1ERP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "S1ERP_database_alert_log_on_nyaderpdb05.na.weightwatchers.net",
  "path": " /u01/app/oracle/admin/S1ERP/bdump/alert_S1ERP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "S2ERP_database_alert_log_on_nyaderpdb05.na.weightwatchers.net",
  "path": " /u01/app/oracle/admin/S2ERP/bdump/alert_S2ERP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WWIPRD_database_alert_log_on_nyaperpdb01p.na.weightwatchers.net",
  "path": " /u01/app/oracle/admin/WWIPRD/bdump/alert_WWIPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WWIPRDSB_database_alert_log_on_nyaperpdb01p.na.weightwatchers.net",
  "path": " /u01/app/oracle/diag/rdbms/wwiprd_nyaperpdb01p/WWIPRD/trace/alert_WWIPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "Q1FDM_database_alert_log_on_nyaqfindb01.na.weightwatchers.net",
  "path": " /u01/app/oracle/diag/rdbms/q1fdm/Q1FDM/trace/alert_Q1FDM.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "Q1HFM_database_alert_log_on_nyaqfindb01.na.weightwatchers.net",
  "path": " /u01/app/oracle/diag/rdbms/q1hfm/Q1HFM/trace/alert_Q1HFM.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WWPFDM_database_alert_log_on_nyapfindb02s.na.weightwatchers.net",
  "path": " /u01/app/oracle/diag/rdbms/wwpfdm_nyapfindb02s/WWPFDM/trace/alert_WWPFDM.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "WWPHFM_database_alert_log_on_nyapfindb02s.na.weightwatchers.net",
  "path": " /u01/app/oracle/diag/rdbms/wwpfdm_nyapfindb02p/WWPFDM/trace/alert_WWPFDM.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XENQA_database_alert_log_on_xendb201",
  "path": " /xen/qa/db/11.2.0/admin/XENQA_xendb201/diag/rdbms/xenqa/XENQA/trace/alert_XENQA.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XENTST_database_alert_log_on_xendb201",
  "path": " /xen/tst/db/11.2.0/admin/XENTST_xendb201/diag/rdbms/xentst/XENTST/trace/alert_XENTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XENPRD_database_alert_log_on_xendb101",
  "path": " /xen/prd/db/11.2.0/admin/XENPRD_xendb101/diag/rdbms/xenprd/XENPRD/trace/alert_XENPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "XYLDEV1_database_alert_log_on_xyldb01.dibos02.di-cloud.com",
  "path": " /xyl/dev/db/tech_st/diag/rdbms/xyldev/XYLDEV1/trace/alert_XYLDEV1.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLTST1_database_alert_log_on_xyldb01.dibos02.di-cloud.com",
  "path": " /xyl/tst/db/tech_st/diag/rdbms/xyltst/XYLTST1/trace/alert_XYLTST1.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLDEV2_database_alert_log_on_xyldb02.dibos02.di-cloud.com",
  "path": " /xyl/dev/db/tech_st/diag/rdbms/xyldev/XYLDEV2/trace/alert_XYLDEV2.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLTST2_database_alert_log_on_xyldb02.dibos02.di-cloud.com",
  "path": " /xyl/tst/db/tech_st/diag/rdbms/xyltst/XYLTST2/trace/alert_XYLTST2.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLSIT_database_alert_log_on_xyldb03.dibos02.di-cloud.com",
  "path": " /xyl/sit/db/tech_st/diag/rdbms/xylsit/XYLSIT/trace/alert_XYLSIT.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLPRD1_database_alert_log_on_xyldb11.dibos02.di-cloud.com",
  "path": " /xyl/prd/db/tech_st/diag/rdbms/xylprd/XYLPRD1/trace/alert_XYLPRD1.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLPRD2_database_alert_log_on_xyldb12.dibos02.di-cloud.com",
  "path": " /xyl/prd/db/tech_st/diag/rdbms/xylprd/XYLPRD2/trace/alert_XYLPRD2.log",
  "reg": " /ORA-(?!00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLFMWD_database_alert_log_on_xylfmwdb11.dibos02.di-cloud.com",
  "path": " /xyl/dev/db/diag/rdbms/xylfmwd/XYLFMWD/trace/alert_XYLFMWD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLFMWP_database_alert_log_on_xylfmwdb11.dibos02.di-cloud.com",
  "path": " /xyl/prd/db/diag/rdbms/xylfmwp/XYLFMWP/trace/alert_XYLFMWP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLGRCD_database_alert_log_on_xylgrcdb01.dibos02.di-cloud.com",
  "path": " /xyl/grcd/db/diag/rdbms/xylgrcd/XYLGRCD/trace/alert_XYLGRCD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLGRCT_database_alert_log_on_xylgrcdb02.dibos02.di-cloud.com",
  "path": " /xyl/grct/db/diag/rdbms/xylgrct/XYLGRCT/trace/alert_XYLGRCT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLGRCP_database_alert_log_on_xylgrcdb11.dibos02.di-cloud.com",
  "path": " /xyl/grcp/db/diag/rdbms/xylgrcp/XYLGRCP/trace/alert_XYLGRCP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLBIWD_database_alert_log_on_xylobidb01.dibos02.di-cloud.com",
  "path": " /xyl/dev/db/diag/rdbms/xylbiwd/XYLBIWD/trace/alert_XYLBIWD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLBIWT_database_alert_log_on_xylobidb02.dibos02.di-cloud.com",
  "path": " /xyl/tst/db/diag/rdbms/xylbiwt/XYLBIWT/trace/alert_XYLBIWT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLBIWP_database_alert_log_on_xylobidb11.dibos02.di-cloud.com",
  "path": " /xyl/prd/db/diag/rdbms/xylbiwp/XYLBIWP/trace/alert_XYLBIWP.log",
  "reg": " /ORA-(?!20000|00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLOIMD_database_alert_log_on_xyldb01.dibos02.di-cloud.com",
  "path": " /xyl/oimd/db/diag/rdbms/xyloimd/XYLOIMD1/trace/alert_XYLOIMD1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLOIMP_database_alert_log_on_xyldb11.dibos02.di-cloud.com",
  "path": " /xyl/oimp/db/diag/rdbms/xyloimp/XYLOIMP1/trace/alert_XYLOIMP1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLVTXD_database_alert_log_on_xylvtxdb01.dibos02.di-cloud.com",
  "path": " /xyl/vtxd/db/diag/rdbms/xylvtxd/XYLVTXD/trace/alert_XYLVTXD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLVTXS_database_alert_log_on_xylvtxdb01.dibos02.di-cloud.com",
  "path": " /xyl/vtxs/db/diag/rdbms/xylvtxs/XYLVTXS/trace/alert_XYLVTXS.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "XYLVTXP_database_alert_log_on_xylvtxdb11.dibos02.di-cloud.com",
  "path": " /xyl/vtxp/db/diag/rdbms/xylvtxp/XYLVTXP/trace/alert_XYLVTXP.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "TEST_database_alert_log_on_odax2vs4.zollmed.com",
  "path": " /u01/app/oracle/diag/rdbms/test/TEST/trace/alert_TEST.log",
  "reg": " /ORA-(?!00060|01555|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "UPG2_database_alert_log_on_odax2vs4.zollmed.com",
  "path": " /cloudfs/oradiag/diag/rdbms/upg2/UPG2/trace/alert_UPG2.log",
  "reg": " /ORA-(?!00060|01555|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AZM1_database_alert_log_on_odax1vs2",
  "path": " /u01/app/oracle/diag/rdbms/azm1/AZM1/trace/alert_AZM1.log",
  "reg": " /ORA-(?!00060|01555|000060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "ZOLL_database_alert_log_on_odax2vs3.zollmed.com",
  "path": " /u01/app/oracle/diag/rdbms/zoll/ZOLL/trace/alert_ZOLL.log",
  "reg": " /ORA-(?!00060|01555|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "ZOLL_database_alert_log_on_orarx66",
  "path": " /oracle/orazoll/product/11gR1/admin/diag/rdbms/zoll/ZOLL/trace/alert_ZOLL.log",
  "reg": " /ORA-(?!00060|01555|00060|28|18913|3136|03149|03137|609|48913|01555)\\d+/"
 },
 {
  "name": "HPMDB1_database_alert_log_on_odax1vs1.zollmed.com",
  "path": " /u01/app/oracle/diag/rdbms/hpmdb1/HPMDB1/trace/alert_HPMDB1.log",
  "reg": " /ORA-(?!00060|01555|000060|28|18913|3136|03149|03137|609|48913|12012|12008|01555|02063|06512)\\d+/"
 },
 {
  "name": "SALESDB1_database_alert_log_on_odax1vs1.zollmed.com",
  "path": " /u01/app/oracle/diag/rdbms/salesdb1/SALESDB1/trace/alert_SALESDB1.log",
  "reg": " /ORA-(?!00060|01555|000060|28|18913|3136|03149|03137|609|48913|12012|12008|01555|02063|06512)\\d+/"
 },
 {
  "name": "ZDWDB1_database_alert_log_on_odax1vs2.zollmed.com",
  "path": " /u01/app/oracle/diag/rdbms/zdwdb1/ZDWDB1/trace/alert_ZDWDB1.log",
  "reg": " /ORA-(?!00060|01555|000060|28|18913|3136|03149|03137|609|48913|12012|12008|01555|02063|06512)\\d+/"
 },
 {
  "name": "FMDEV102_database_alert_log_on_devdb03",
  "path": " /u01/oracle/diag/rdbms/fmdev102/FMDEV102/trace/alert_FMDEV102.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FMPRD102_database_alert_log_on_db03",
  "path": " /u01/oracle/diag/rdbms/fmprd102/FMPRD102/trace/alert_FMPRD102.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FMPRD1022_database_alert_log_on_rac02",
  "path": " /u01/app/oracle/diag/rdbms/fmprd102/FMPRD1022/trace/alert_FMPRD1022.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "FMPRD1021_database_alert_log_on_rac01",
  "path": " /u01/app/oracle/diag/rdbms/fmprd102/FMPRD1021/trace/alert_FMPRD1021.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
{
  "name": "DTSSBX_database_alert_log_on_dtsdb01",
  "path": " /dts/sbx/db/11.2.0/admin/DTSSBX_dtsdb01/diag/rdbms/dtssbx/DTSSBX/trace/alert_DTSSBX.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DTSTST_database_alert_log_on_dtsdb01",
  "path": " /dts/tst/db/11.2.0.2/admin/DTSTST_dtsdb01/diag/rdbms/dtstst/DTSTST/trace/alert_DTSTST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "DTSPRD_database_alert_log_on_dtsdb11",
  "path": " /dts/prd/db/diag/rdbms/dtsprd/DTSPRD/trace/alert_DTSPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|00445)\\d+/"
 }
,
 {
  "name": "IVCZKH_database_alert_log_on_main",
  "path": " /u/app/diag/rdbms/ivczkh/ivczkh/trace/alert_ivczkh.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|03135)\\d+/"
 },
 {
  "name": "CITY190_database_alert_log_on_standby",
  "path": " /u/app/oracle/city/product/diag/rdbms/city190/CITY190/trace/alert_CITY190.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|03135)\\d+/"
 },
 {
  "name": "ORA1C_database_alert_log_on_standby",
  "path": " /u/app/diag/rdbms/ora1c/ora1c/trace/alert_ora1c.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|03135)\\d+/"
 },
 
 
 
 
  {
  "name": "O10CLICT_database_alert_log_on_\\\\hq-cv-dbt-01",
  "path": " \\\\10.142.210.9\\c$\\oracle\\admin\\o10clict\\bdump\\alert_O10CLICT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10CORA_database_alert_log_on_\\\\hq-cv-dbt-01",
  "path": " \\\\10.142.210.9\\c$\\oracle\\admin\\o10cora\\bdump\\alert_O10CORA.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10CORT_database_alert_log_on_\\\\hq-cv-dbt-01",
  "path": " \\\\10.142.210.9\\c$\\oracle\\admin\\o10cort\\bdump\\alert_O10CORT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10DIAST_database_alert_log_on_\\\\hq-cv-dbt-01",
  "path": " \\\\10.142.210.9\\c$\\oracle\\admin\\o10diast\\bdump\\alert_O10DIAST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10HFLT_database_alert_log_on_\\\\hq-cv-dbt-01",
  "path": " \\\\10.142.210.9\\c$\\oracle\\admin\\o10hflt\\bdump\\alert_O10HFLT.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10OTHET_database_alert_log_on_\\\\hq-cv-dbt-01",
  "path": " \\\\10.142.210.9\\c$\\oracle\\admin\\o10othet\\bdump\\alert_O10OTHET.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10POST_database_alert_log_on_\\\\hq-cv-dbt-01",
  "path": " \\\\10.142.210.9\\c$\\oracle\\admin\\o10post\\bdump\\alert_O10POST.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10CLICP_database_alert_log_on_\\\\df-cv-dbp-01",
  "path": " \\\\10.142.230.12\\c$\\oracle\\admin\\O10CLICP\\bdump\\alert_o10clicp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10CORP_database_alert_log_on_\\\\df-cv-dbp-01",
  "path": " \\\\10.142.230.12\\c$\\oracle\\admin\\O10CORP\\bdump\\alert_o10corp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10DIASP_database_alert_log_on_\\\\df-cv-dbp-01",
  "path": " \\\\10.142.230.12\\c$\\oracle\\admin\\O10DIASP\\bdump\\alert_o10diasp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10HFLP_database_alert_log_on_\\\\df-cv-dbp-01",
  "path": " \\\\10.142.230.12\\c$\\oracle\\admin\\O10HFLP\\bdump\\alert_o10hflp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10OTHER_database_alert_log_on_\\\\df-cv-dbp-01",
  "path": " \\\\10.142.230.12\\c$\\oracle\\admin\\O10OTHER\\bdump\\alert_o10other.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "O10POSP_database_alert_log_on_\\\\df-cv-dbp-01",
  "path": " \\\\10.142.230.12\\c$\\oracle\\admin\\O10POSP\\bdump\\alert_o10posp.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 
  {
  "name": "AXTEST_database_alert_log_(SYS* job)_on_sarov",
  "path": "/opt/oracle/diag/rdbms/axtest/AXTEST/trace/alert_AXTEST.log",
  "reg":  "/ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012)\d+/"
 },
 
 
  {
  "name": "AXWORK11_database_alert_log_on_tango",
  "path": "/opt/app/oracle/diag/rdbms/axwork11/AXWORK11/trace/alert_AXWORK11.log",
  "reg": "/ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012)\d+/"
 },
 
 
  {
  "name": "AXWORK11S_database_alert_log_on_cash",
  "path": "/opt/app/oracle/diag/rdbms/axwork11s/AXWORK11S/trace/alert_AXWORK11S.log",
  "reg": "/ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012)\d+/"
 },
 
 
 
  {
  "name": "TOCIS11_database_alert_log_on_cash",
  "path": "/opt/app/oracle/diag/rdbms/tocis11/TOCIS11/trace/alert_TOCIS11.log",
  "reg": "/ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012)\d+/"
 },
 
 
 
  {
  "name": "TOCIS11S_database_alert_log_on_tango",
  "path": "/opt/app/oracle/diag/rdbms/tocis11s/TOCIS11S/trace/alert_TOCIS11S.log",
  "reg": "/ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012)\d+/"
 },
 
 
 
  {
  "name": "TOCIS11TEST_database_alert_log_on_sarov2",
  "path": "/u01/app/oracle/diag/rdbms/tocis11/TOCIS11/trace/alert_TOCIS11.log",
  "reg": "/ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012)\d+/"
 },
 
 
 
  {
  "name": "VOLGA_database_alert_log_on_anzer",
  "path": "/opt/oracle/diag/rdbms/volga/VOLGA/trace/alert_VOLGA.log",
  "reg": "/ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|12012)\d+/"
 },




{
  "name": "INSIS2_database_alert_log_on_s-msk00-idb02",
  "path": " /opt/oracle/base/diag/rdbms/insis/insis2/trace/alert_insis2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "INSIS1_database_alert_log_on_s-msk00-idb01",
  "path": " /opt/oracle/base/diag/rdbms/insis/insis1/trace/alert_insis1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "AIS_database_alert_log_on_msk01-aisdb01",
  "path": " /oracle/diag/rdbms/ais/ais/trace/alert_ais.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "RSA_database_alert_log_on_rsadb01",
  "path": " /opt/oracle/diag/rdbms/rsa/RSA/trace/alert_RSA.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913|00942|06550|00364|12012|00600:.*\\[26599[^\\]]*\\])\\d+/"
 },
 {
  "name": "INSIS_database_alert_log_on_s-msk00-irp01",
  "path": " /opt/oracle/base/diag/rdbms/insis_stb/insis_stb/trace/alert_insis_stb.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "OFIS_database_alert_log_on_vs-msk00-podb",
  "path": " /opt/oracle/diag/rdbms/ofis/ofis/trace/alert_ofis.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 }
,
{
  "name": "AGIL_database_alert_log_on_\\\\stnaglmt11",
  "path": " \\\\stnaglmt11\\D$\\oracle\\product\\10.2.0\\admin\\agil\\bdump\\alert_agil.log",
  "reg": " /ORA-(?!02097|00439|00060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "STNPRD_database_alert_log_on_stndb11",
  "path": " /stn/prd/db/diag/rdbms/stnprd/STNPRD/trace/alert_STNPRD.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 }
,
{
  "name": "PROD_database_alert_log_on_ots-db-blprod",
  "path": " /u01/app/oracle/admin/prod/bdump/alert_prod.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "RPT1_database_alert_log_on_ots-db-blrpt1",
  "path": " /u01/app/oracle/admin/prod/bdump/alert_prod.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "RPT2_database_alert_log_on_ots-db-blrpt2",
  "path": " /u01/app/oracle/admin/rpt2/bdump/alert_rpt2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BLWHS1_database_alert_log_on_ots-db-blwhs1",
  "path": " /u01/app/oracle/admin/blwhs1/bdump/alert_blwhs1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BPPROD1_database_alert_log_on_ots-db-bpprod",
  "path": " /u01/app/oracle/admin/bpprod1/bdump/alert_bpprod1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BPRPT1_database_alert_log_on_ots-db-bprpt1",
  "path": " /u01/app/oracle/admin/bprpt1/bdump/alert_bprpt1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BPRPT2_database_alert_log_on_ots-db-bprpt2",
  "path": " /u01/app/oracle/admin/bprpt2/bdump/alert_bprpt2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "BPWHS1_database_alert_log_on_ots-db-bpwhs1",
  "path": " /u01/app/oracle/admin/bpwhs1/bdump/alert_bpwhs1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SEPROD1_database_alert_log_on_ots-db-seprod1",
  "path": " /u01/app/oracle/admin/seprod1/bdump/alert_seprod1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SERPT1_database_alert_log_on_ots-db-serpt1",
  "path": " /u01/app/oracle/admin/serpt1/bdump/alert_serpt1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SERPT2_database_alert_log_on_ots-db-serpt2",
  "path": " /u01/app/oracle/admin/serpt2/bdump/alert_serpt2.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 },
 {
  "name": "SEWHS1_database_alert_log_on_ots-db-sewhs1",
  "path": " /u01/app/oracle/admin/sewhs1/bdump/alert_sewhs1.log",
  "reg": " /ORA-(?!00060|000060|28|18913|3136|03149|03137|609|48913)\\d+/"
 }
,
{name:"" ,path:"", reg:""} ] 
