/**
    This is a scheleton of module which compatible  with 
    module system 
*/

window.Module.syncRoot = function (moduleName)
{
/**
   List of modules which must be loaded before this
*/
window.Module.before[moduleName] = [
                                    "base@util",
                                    "opm@inf@string"
                                    ] ;
window.Module.noncomplete[moduleName] = function()
 {
 console.group("module <" + moduleName+ ">");

  var mUtil   = Module.get("util");
  var mClFunc = Module.get("string");
 

 /**
    Tags for differenciate pages
 */
 var tags = mUtil.arrayToObj
                        ([
                            "massEdit",
                            "viewRecord",
                            "viewI",
                            "viewCR",
                            "viewSR",
                            "editI",
                            "editSR",
                            "editCR",
                            "newI",
                            "newSR",
                            "newCR",
                            "viewRecord",
                            "lookUpUser",
							              "lookUpItem",
                            "homePage",
							"unknownPage"
                           ]);
  
  /**
     Select Xpath pointed to valid elements

     @params selector String with selector key ( I SR CR View Edit)
  */
  function validPaths(selector)
  {
    mUtil.assertType(selector,"string");

    var Xpath = mClFunc.Xpath;

    var paths = mUtil.flat(Xpath,"_");
    var keys = mUtil.objKeys(paths);

    return keys.filter(function(key)
       {
         return  key.includes(selector) &&  
                      mUtil.getElementByXpath(paths[key]) ||
                 false; 
       });
  }

  /**
      Detect current page type
  */
 var cachedTagValue =  null;

  function classify()
  {  
     if (cachedTagValue)  return cachedTagValue;

     var docId = validPaths("docId").length === 1;
     var list = mUtil.getElementByXpath('//*[@name="$sel_assigned_team"]'); 
     var title = document.querySelector(".SITitle");
    
    var tag = tags.unknownPage;
    
  
   if ( title ) 
    {
     switch ( title.innerText )
     {
      case "Incident" : { tag = "I"; break;}
      case "Change Request" : { tag = "CR"; break;}
      case "Service Request" : { tag = "SR"; break;}
     }

    if (list && docId ) 
      {
         tag = "edit" + tag;
      }
    else if (list)
      {
         tag = "new" + tag;
      }
    else if (docId)
      {
         tag = "view" + tag;
      }


     if (title.innerText === "End User" || title.innerText === "Employee")
      {
         tag = "viewRecord";
      }
    }
    
    

     if (document.title === "Mass Edit")
     {
        tag = tags.massEdit;  
     }

     if (document.title === "Look up User" )
     {
        tag = tags.lookUpUser;  
     }
	 
	  if (document.title === "Look up Employee" )
     {
        tag = tags.lookUpUser;  
     }
	 
     if (document.title === "Look up Configuration Item" )
     {
        tag = tags.lookUpItem;  
     }

     if (document.title === "Data Intensity ITIL Service Desk" )
     {
        tag = tags.homePage;  
     }

     

    console.log("This tab classifed as %s",tag)

    cachedTagValue = tag;
    return tag;
  }

console.log("Loaded");
console.groupEnd(); 
/**
      Return  object which will be public interface for functions 
      in that module
  */  
  return {
   "classify" : classify,
   "tags"    : tags
  };

};
}("opm@inf@classify");