/**
   Module for complex content functions
*/

window.Module.syncRoot = function(moduleName) {
  /**
     List of modules which must be loaded before this
  */
  window.Module.before[moduleName] = [
    "base@util",
    "opm@inf@string",
     "opm@inf@classify",
       "base@storage"
  ];

  window.Module.noncomplete[moduleName] = function() {
    console.group("module <" + moduleName + ">");

    var mUt  = Module.get("util");
    var mStr = Module.get("string");
    var mSt    = Module.get("storage");
    var mCl    = Module.get("classify");

   
    /**  
        Transform raw column content in correct div elements
   
        @param arg
     */
    function transformToDivs(strSrcHtml, styleHeader) {
     
      var delim ="";   
   
      //Remove unnessasary divs
      delim = '<div style="background-color:silver;font-size:1px;margin-top:1px;margin-bottom:1px">&nbsp;</div>';
      data = strSrcHtml.split(delim).join("");
      //Remove extra breaks
      delim = '<br><br>';
      data = strSrcHtml.split(delim).join("<br>");
      
      //Create divs for every record
      var regEx = /<div[^>]*>(\[[^\]]*\])<\/div>/gm
      var replaceFunc = function(m, p1) {
        return "</div></div><div>" +
                        "<div class='" + styleHeader + "''>" + p1 + "</div>" +
                        "<div class='record'>";
                      
      }
      
      //Refine html that was generated
      data = data.replace(regEx, replaceFunc);
      data = data.replace("</div>", "");
      data += "</div>";

      return data;
    }
 

     /**  
         Sort items divs by time or creation
    
         @param div Parent element for items
      */
   function sortByTime(div)
   {
  
    //Validate correct header with time stamp
    var regDate=/\D{3} \d{2} \d{4} \d{2}:\d{2}:\d{2}|\D{3} \d{2} \d{4} \d{2}:\d{2} \D{2}/

    //Rip date string from header
    var ripDate = function(elt)
     { 
      var text = regDate.exec(elt.childNodes[0].innerText)[0];
      mUt.assertBool(text.length === 20 );

      return new Date(text);
     }

     var items = [];
     var nodes = div.childNodes;
     for (var i=0; i<nodes.length; i++)
       items.push(nodes[i]); 
     
     items.sort(function(a,b){ return ripDate(b).valueOf() - ripDate(a).valueOf();})
     
     //Populate sorted divs to parent element
     div.innerHTML = "";
     items.every(function(elt){ div.appendChild(elt); return true;})

     return div;
   }


 /**  
     Global enhancement of tickets view

     @param tag Type of current page
  */
function optGlobalViewEnhance(opt,tag)
{
   var active = false;
    

    switch (tag)
    {
     case mCl.tags.viewI: 
     case mCl.tags.viewSR: 
     case mCl.tags.viewCR: 
     case mCl.tags.editI: 
     case mCl.tags.editSR: 
     case mCl.tags.editCR:
     case mCl.tags.newI:
     case mCl.tags.newSR:
     case mCl.tags.newCR:

           { active=true; break;} 
    }

  if ( opt.GlobalViewEnhance && active)
   {

   Module.loadScript("js/modules/opm/mode/slave_view_enhance.js", true,
                     function()
                      {
                       }); 
   }


}



     /**  
         Reorginize items by time
    
         @param tag Type of current page
      */
    function optReorganizeFields(opt,tag) {
       var ticket  = /[ISRCR]{1,2}$/.exec(tag)[0];
       var Xpath = mStr.Xpath[ ticket ];
       
  
      var css        = document.createElement("style");

      //CSS table for new created elements
      css.innerHTML = `

      .addInf {
        background-color: lightgreen;
        font-size: 18px;
		width:70%;

      }

      .stuffOnly {
        background-color: lightskyblue;
        font-size: 18px;

        width:70%;
        margin-left:10%;
      }
      
      .stuffOnly + .record{
        
        margin-left:10%;
		

      }

      .record {
        background-color: #E0EAFF;
        font-size: 16px;
		width:70%;
		
      }

       div
       {
         font-family:monospace; 

       }
      `;
         
      var workActivate = false;
      var chronoLine = document.createElement("div");
      var workTab = mUt.getElementByXpath(Xpath.docWorkTab);
   
      //Process double click by tab title
      workTab.addEventListener("dblclick", function(e) {
           
        var place = mUt.getElementByXpath(Xpath.docNewInfTable);
        var table = mUt.getElementByXpath(Xpath.docInfTable);
    
        //Toogle state
        if (workActivate = !workActivate) {

          var addNotes = mUt.getElementByXpath( Xpath.docAddInf);
          var stuffOnly = mUt.getElementByXpath(Xpath.docStuffOnly);
          
          addNotes = addNotes && transformToDivs(addNotes.innerHTML, "addInf") || "";
          stuffOnly = stuffOnly && transformToDivs(stuffOnly.innerHTML, "stuffOnly") || "";

          chronoLine.innerHTML = addNotes + stuffOnly;                                ;

          chronoLine = sortByTime(chronoLine);          

          //Insert sorted items and hide old unsorted view
          place.insertBefore(chronoLine, place.childNodes[0]);
          place.insertBefore(css       , place.childNodes[0]);
          table.style.display = 'none';
        } else {
          //Restore original state of view 
          place.removeChild(chronoLine);
          table.style.display = '';
        }

      });


      function showAll(rows)
       {
        var infHeader = mUt.getElementByXpath(Xpath.docInfHeader);
        infHeader.style.display =  infHeader.dataset['x_display'];
      
 

        rows.map(function(row)
        {
          row.style.display = row.dataset['x_display'];
        });

       }

      function hideSome(rows)
       {
        var interestRows = [
         
             'CI Name:'
             ,'Additional people to cc on emails:'
             ,'Impact:'
             ,'Service:'
             ,'Requested Start Time:'
             ,'CI Primary'
			 ,'CI Production'
			 ,'Monitor State'
         ];

        var infHeader = mUt.getElementByXpath(Xpath.docInfHeader);
        infHeader.dataset['x_display'] = infHeader.style.display;
        infHeader.style.display = 'none';

        rows.every(function(row)
        {
          row.dataset['x_display'] = row.style.display;
          row.style.display = 'none';

          interestRows.every(function(interestRow)
            {
              if (row.innerHTML.indexOf(interestRow) !== -1)
              { 
                 row.style.display =  row.dataset['x_display']
                 return false;
              }

              return true;
            });

          return true;
        });

       }


      var detailActivate = false;
      var detailTab = mUt.getElementByXpath(Xpath.docDetailTab);
    
      //Process double click by tab title
      detailTab.addEventListener("dblclick", function(e) {
     
       var detailPage = mUt.getElementByXpath(Xpath.docDetailPage);
       var  infRows = [].slice.call(detailPage.querySelectorAll('div > table > tbody > tr'));

        //Toogle state
        if (detailActivate = !detailActivate) {
     
          hideSome(infRows);
          optGlobalViewEnhance(opt,tag);
        } 
        else
        {
         showAll(infRows);
        }

      });

    }















 function changeSubmitter()
  {
     var subNeed = document.getElementById("extSubNeed");
	 var selSet = document.getElementById("extOften");
    
	 subNeed.value = subNeed.value || selSet.children[selSet.selectedIndex].innerText; 
	 
	 
	 var forFind =  subNeed.value.indexOf("-") ==-1 ? subNeed.value :  subNeed.value.split("-")[1];
	 
      mSt.set( mSt.keys.lookUpUser, forFind);

      var current = document.getElementById("lu$customer_name") ||
                             document.getElementById("lu$requester") ||
                                document.getElementById("lu$full_name");
      current.click();                     
  }

 /**  
     Realisation of quick selection of submitter and CI name

     @param tag Classification tag of current page
  */
    function optQuickCIName(tag)
    {
     
  
  
      var area = document.createElement("div");
        
      area.innerHTML = `
      <table>	       
	  <tr><td> <select id="extOften" tabindex=1 style="width:100%;"> </select> </td></tr>
      <tr><td> <input tabindex=2 id="extSubNeed" type=text style="width:99%"> </td></tr>	
	  <tr><td>
      <button tabindex=4 id="extSoft" type=button style="background:hsl(349, 89%, 51%);">Soft closed</button>
	  <button tabindex=3 id="extUpdate" type=button style="background:#0EDA0E;">After email</button>	
	   <button tabindex=5 id="extUpdateOSR" type=button style="background:yellow">OSR</button> 
	  </td></tr> 
      
	  </table>
      `;
        
      document.getElementById("extPanel").appendChild(area); 
	  	    
	   var  options = 
	 [
	    "Biogen-Brian Oehler",
		"Biogen-Dave Patterson",
		"Dunkin-Bill Reidy",
		"AFL-Cindy Ullery",
		"Aspen-Raju Metpelly",
		"Weight-Lesslie Samson",
		"Hussman-Brian Baker",
		"Tejon-Steve Quinn",
		"GSI-Stephen Ibbitson",
		"GSI (access tickets)-Ken Lanciani",
		"Alkermes-Twinkle Patel",
		"ITT-Jonh Bromley",
		"iRobot-Katrina Sorrentino",
		"Lidestry-Bill Littleboy",
		"Cell-Carlos del Castillo",
		"OneGas-Eddie Morris",
		"VHA-Robert Steinbach",
		"OneOk-David Crull",
		"Greatbatch-Milan Parihar",
        "Blackstone-Elena Brennan"		
	 ];
   
     var selectSet = document.getElementById('extOften');
     
     options.map(function(optText,i)
	 {
		var newOpt = document.createElement("option");
         
		newOpt.value = i;
        newOpt.innerText=optText;		
		 
		selectSet.appendChild(newOpt);
	 });
	  
	  
	   document.getElementById("extUpdate").addEventListener("click",
        function(e){
            setTimeSpent("0:07");
            setTicketStatus("Updated by Customer");     
      });
		  
		  document.getElementById("extSoft").addEventListener("click",
        function(e){
           
            setTimeSpent("0:05");
            setTicketStatus("Soft Closed");
          });

  
		  
      document.getElementById("extUpdateOSR").addEventListener("click",
        function(e){
           
            var ticket  = /[ISRCR]{1,2}$/.exec(tag)[0];
            var Xpath = mStr.Xpath[ ticket ];
            var strVendorSR = mUt.getElementByXpath(Xpath.docVendorSRNumber).value;
            if (strVendorSR.length > 13) strVendorSR = "";
			
			
			var selectedField =  mUt.getElementByXpath(Xpath.docEditAreaStuffOnly);
            
			var isTemplateHere = function (strValue) {
			
             var lines = strValue.split('\n');		
             var testLine = (lines[lines.length - 1 ]).trim();			 
			 return testLine === "@"	
			}
			
			var templateRemove = function (strValue) {
			
             var lines = strValue.split('\n');
             lines[lines.length - 1 ] = ""			 
			 return lines.join("\n");
			}
			
			
			if ( isTemplateHere(selectedField.value) )
			{
				selectedField.value = templateRemove(selectedField.value);
			   selectedField.value += `Checked Oracle SR ${strVendorSR}. ` + 
             'No update found.\n' + 'Current status: @';
			 
            setTimeSpent("0:10");					
			}
           
		   selectedField =  mUt.getElementByXpath(Xpath.docEditAreaAdditionalInformation);
            
			if ( isTemplateHere(selectedField.value) )
			{
				selectedField.value = templateRemove(selectedField.value);
			   selectedField.value += `Checked Oracle SR ${strVendorSR}.`+
            '\nFound following update:\n' +
            '~~~~~~~~~~~~~~~~~~~~~~~~\n' +
            '@\n' +
            '~~~~~~~~~~~~~~~~~~~~~~~~\n' +
            '\n' +
            'Reviewing.\n\n';

            setTimeSpent("0:10");
            setTicketStatus("In Progress");				
			}
		 
            
          });
/*
      document.getElementById("extUpdateOSR").addEventListener("click",
        function(e){
           
                var ticket  = /[ISRCR]{1,2}$/.exec(tag)[0];
            var Xpath = mStr.Xpath[ ticket ];
            var strVendorSR = mUt.getElementByXpath(Xpath.docVendorSRNumber).value;
            if (strVendorSR.length > 13) strVendorSR = "";
   
            mUt.getElementByXpath(Xpath.docEditAreaAdditionalInformation).value += `Checked Oracle SR ${strVendorSR}.`+
            '\nFound following update:\n' +
            '~~~~~~~~~~~~~~~~~~~~~~~~\n' +
            '@\n' +
            '~~~~~~~~~~~~~~~~~~~~~~~~\n' +
            '\n' +
            'Reviewving.\n\n'
            ;

            setTimeSpent("0:10");
            setTicketStatus("In Progress");

          });

*/
	  
	    document.getElementById("extOften").addEventListener("change",
        function(e){
          
		  var subNeed = document.getElementById("extSubNeed");
	      var selSet = document.getElementById("extOften");
    
	      subNeed.value = selSet.children[selSet.selectedIndex].innerText; 
		   
          });
	  	  
		   document.getElementById('extSubNeed').addEventListener("blur",
        function(e){
		      changeSubmitter();
          });
	  
		 
    }



    /**  
        Setting of ticket status
   
        @param strStatus String with new status to set
     */
    function setTicketStatus(strStatus)
     {
      mUt.assertType(strStatus,"string");

      var status = document.getElementById("e_1007");
      var opt  = [].slice.call(status.options);

      opt.map(function(elt,i){if (elt.innerText == strStatus) elt.selected= true;  })
     }

    /**  
        Setting of time spent
   
        @param strTime String with values of time formatted as 00:00
     */
    function setTimeSpent(strTime)
    {
      mUt.assertType(strTime,"string");
     var partsOfTime = strTime.split(":");

       var time = document.getElementById("e_1033_2") ||
                      document.getElementById("e_1029_2") ||
                   document.getElementById("e_1051_2");
                 
       var hour = document.getElementById("e_1033_1") ||
                      document.getElementById("e_1029_1") ||
                   document.getElementById("e_1051_1");
      hour.focus();    
      hour.value = partsOfTime[0];
    
      time.focus();
      time.value = partsOfTime[1];
    }





    /**
        Return  object which will be public interface for functions 
        in that module
    */
    console.log("Loaded");
    console.groupEnd();

    return {
      "optReorganizeFields": optReorganizeFields,
      "optQuickCIName"     : optQuickCIName
    };


 }; 

}("opm@mode@slave_part_1");


