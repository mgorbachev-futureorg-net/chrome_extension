
/*
Interface to script as from the old place and direct from the ticket
Include in general script commands for view of tables in database


Generate script for alert logs direct from ticket tab

Dedicated projects times

History of tickets assignement
*/


var styleAdd = 'style="background-color:lightgreen"';
var styleStuff = 'style="background-color:lightblue"';

var regEx       = /<div[^>]*>(\[[^\]]*\])<\/div>/gm
var replaceFunc = function(m,p1){return "</div><div>" + "<div " +styleAdd + ">" + p1 + "</div>";}


var data = z.innerHTML;

var delim = ""; 
delim = '<div style="background-color:silver;font-size:1px;margin-top:1px;margin-bottom:1px">&nbsp;</div>';   
data = data.split(delim).join("");


data = data.replace(regEx,replaceFunc);
data = data.replace("</div>","");
data += "</div>";


var items = document.createElement("div");
items.innerHTML = data;

/CSRF_NONCE=\S{32}/.exec(w.innerHTML)


  var code = 
   {
   "2956": 'Not assigned CR',
   '2957': 'Not assigned SR',
   '2955': 'Not assigned I' ,
   '2575': "Monitoring CR"  ,
   '2577': "Monitoring SR"  ,
   '2576': "Monitoring I"  
   }

  var title = "" ;
  console.log(title,strURL);

   var table = 
     {
      title : code[ /view=(\d{4})/.exec(strURL)[1] ], 
      data: null
     };

console.log(table);



[].slice.call( h.querySelectorAll("#headerWrapperTable td div table td")).every(function(elt){console.log(elt.innerText.trim()); return true})



var  infRows = [].slice.call(document.querySelectorAll('#page_0 > div > table > tbody > tr'));

function showAll(rows)
 {

  rows.map(function(row)
  {
    row.style.display = row.dataset['x_display'];
  });

 }

function hideSome(rows)
 {
  var interestRows = [ "CI Name" ];


  rows.every(function(row)
  {
    row.dataset['x_display'] = row.style.display;
    
    interestRows.every(function(interestRow)
      {
        if (row.innerHTML.indexOf(interestRow) === -1)
        { 

           row.style.display = 'none';
           return false;
        }

        return true;
      });

    return true;
  });

 }

 function a(){hideSome(infRows)};
 function b(){showAll(infRows)};


var s = [].slice.call(document.querySelectorAll("span, tr>td:first-child"));

 s.map(function (elt)
   {if (elt.innerText.endsWith(":")) elt.style.fontWeight = 'bold' })