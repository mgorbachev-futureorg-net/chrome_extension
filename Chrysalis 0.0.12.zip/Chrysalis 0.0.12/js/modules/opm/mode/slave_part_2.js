/**
   Module for complex content functions
   */

   window.Module.syncRoot = function(moduleName) {
  /**
     List of modules which must be loaded before this
     */
     window.Module.before[moduleName] = [
     "base@util",
     "opm@inf@string",
     "opm@inf@classify",
     "base@storage"
     ];

     window.Module.noncomplete[moduleName] = function() {
      console.group("module <" + moduleName + ">");

      var mUt  = Module.get("util");
      var mStr = Module.get("string");
      var mSt    = Module.get("storage");
      var mCl    = Module.get("classify");

  //  Often uses values
  var tag = mCl.classify();

  if (tag === mCl.tags.unknownPage)
  {
   console.log("loading slave <2> aborted, page classifyed as %s", tag);	
   return {
    "register": function(){}
  };
}

var getXpath = mUt.getElementByXpath;
var ticket  = /[ISRCR]{1,2}$/.exec(tag)[0];
var node = mStr.Xpath[ticket]; 
  //


 /**  
     Get panel for placing elements

     @param arg
     */
     function  getPanel()
     {
       var panel = document.getElementById("informPanel");

       if ( ! panel )
       {         
        panel = document.createElement("div");
        panel.id = "informPanel";
        panel.className = "extPanel"; 

      //Place to put panel element   
      var docCompanyNode = getXpath( node.docCompany);
      docCompanyNode.parentNode.appendChild(panel);
    }

    return panel;
  }

  function  getButtonPanel()
  {
   var panel = document.getElementById("informPanelButton");

   if ( ! panel )
   {         
    panel = document.createElement("span");
    panel.id = "informPanelButton";
    panel.className = "extPanel"; 
    
    getPanel().appendChild(panel);
  }

  return panel;
}

function  getShortTextPanel()
{
 var panel = document.getElementById("shortTextPanelButton");

 if ( ! panel )
 {         
  panel = document.createElement("div");
  panel.id = "shortTextPanelButton";
  panel.className = "extPanel"; 

  getPanel().appendChild(panel);
}

return panel;
}

function  getLongTextPanel()
{
 var panel = document.getElementById("longTextPanelButton");

 if ( ! panel )
 {         
  panel = document.createElement("div");
  panel.id = "longTextPanelButton";
  panel.className = "extPanel"; 

  getPanel().appendChild(panel);
}

return panel;
}

 /**  
     Tag this ticket according various data

     @param arg
     */
     function addGroupTypeElement(nodePanel)
     {
      var docCompanyNode = getXpath( node.docCompany); 
      var docCompany = docCompanyNode.innerText.trim();

      var groupTag = document.createElement("span");
      groupTag.className = "groupTag";
      groupTag.innerText = "";

      var customerGroup = mStr.CustomerGroup;

      for (var tag in customerGroup )
      {
       if (customerGroup.hasOwnProperty(tag))
       {
         if ( customerGroup[tag].indexOf(docCompany) !== -1)
          groupTag.innerText += tag + " " ;			   

      }

    }

    if ( groupTag.innerText === "") groupTag.innerText = "Unknown"; 

    nodePanel.appendChild(groupTag);
  }


 /**  
     Checking current time for intercect with time intervals

     @param arg
     */
     function isInTimeWindow(timeIntervals)
     {
       var now = new Date();
       var currentMinute =  now.getHours()*60 + now.getMinutes();

       var isActive = false;

       timeIntervals.every(function(interval)
       {
         isActive = (interval[0] === now.getDay())&&(currentMinute > interval[1])&&(currentMinute < interval[2]);

         if (isActive) return false;
         return true;
       });

       return isActive;

     }

/**  
     Adding element for dedicated projects
     */
     function addTicketInstructionsElement(nodePanel, funcCallback)
     {

      var docStuffOnly = getXpath( node.docStuffOnly); 
         
      var stuffOnlyTag = document.createElement("span");
      stuffOnlyTag.className = "stuffOnly";


      var stuffOnlyData = docStuffOnly.innerHTML;
      stuffOnlyTag.innerHTML = stuffOnlyData.substring(stuffOnlyData.lastIndexOf('<div'));

      nodePanel.appendChild(stuffOnlyTag);

      funcCallback();
    }


 /**  
     Adding element for dedicated projects
     */
     function addDedicCustomerElement(nodePanel)
     {

       var docCompanyNode = getXpath( node.docCompany); 
       var docCompany = docCompanyNode.innerText.trim();

       var groupTag = document.createElement("span");
       groupTag.className = "dedicTag";


       var dedicatedProjects = mStr.DedicatedProjects;

       dedicatedProjects.filter(function(dedicatedProject)
       {
         return dedicatedProject.companyes.indexOf(docCompany) !== -1;
       }).every(function(dedicatedProject)
       {
        groupTag.innerText += dedicatedProject.name + " ";

        if (isInTimeWindow(dedicatedProject.timeIntervals))
         groupTag.className='dedicTagActive';

       return true;
     });

       nodePanel.appendChild(groupTag);
     }


     LoadedTextScripts = {};


 /**  
     Load templates for script generations

     @param arg
     */
     function loadTemplate(strTemplate,funcCallback)
     {

       if ( ! LoadedTextScripts[strTemplate] )
       {

         switch (strTemplate)
         {
           case 'alert' :
           case 'database':
           case 'sisA':
           case 'sisB':
           case 'cmdToPutty': {
             Module.loadScript("js/modules/opm/inf/textTemplates.js", false, funcCallback);
             break;
           }

           case 'alertData':{
             Module.loadScript("js/modules/opm/inf/alertLogsData.js", false, function(){
               LoadedTextScripts.alertData = true;
               funcCallback();
             });
             break;
           }
         }
       }

       else
       {
         funcCallback();
       }
     }


/**
   Create and add element to node
   Assign to the new element values of ID and INNER_HTML 
   */
   function addElementTo(node, strTag, strId, strInnerHTML)
   {
    var elt = document.createElement(strTag);
    elt.id = strId || "";
    elt.innerHTML = strInnerHTML || "";

    node.appendChild(elt);
    return elt;
  }


 /**  
     Adding button for generating script for alert log fast check

     @param arg
     */
     function addAlertLogButton(nodePanel)
     {
      var b = addElementTo(nodePanel,'button','','Alert');
      b.className =  "buttonUnknown";

      b.addEventListener('click', function(){

       var docSummary = getXpath( node.docSummary).innerText.trim().replace(/^.*\| /,"");

       if ( docSummary.trim() === "" )
       {
        b.className =  "buttonError";
        return;
      }

      loadTemplate('alertData',function(){
        loadTemplate('alert',function(){



          var alertLogData = Data.filter(function(elt){ return elt.name.startsWith(docSummary) });

          if (alertLogData.length === 1)
          {
            console.log("Found record %o", alertLogData);

            var pathToFile = alertLogData[0].path.trim();
            var exceptions = alertLogData[0].reg.replace(/[^0-9|]/g,"");

            result = LoadedTextScripts['alert'].replace("{{pathToFile}}",pathToFile ).replace("{{exceptions}}",exceptions );

            mUt.setClipBoardBuffer(result);
            b.className =  "buttonGood";
          }
          else if (alertLogData.length > 1)
          {
           console.log("Found %d records",alertLogData.length);
           b.className =  "buttonWarning";
           prompt("Found more than one monitor with this name. Please use another search interface by following link:", "file:///X:/AlertLogs/ScriptGenPage/index.html");
         }			 
         else
         {
           console.log("Found %d records",alertLogData.length);
           b.className =  "buttonError";
         }

       });
});
}); 
}

function addPuttyLogButton(nodePanel)
{

 var generateSessionFile =  function(strColor){

var nodes = [ 

  node.docCompany,
  node.docSummary,
  node.docId
].map(mUt.getElementByXpath);

var z = parseInt(strColor.replace('#','0x'))
var strRGBColor = [(z >> 16) & 0xff, (z >> 8) & 0xff, z & 0xff ].map(String).join(',');
debugger;


var templateValues = {

  docCompany : nodes[0].innerText.trim().replace(/\W/g,"_"),
  docSummary : nodes[1].innerText.trim().replace(/\W/g,"_"),
  docId : nodes[2].innerText.trim().replace(/\W/g,"_"),
  docHostName: mUt.getClipBoardBuffer().trim(),
  backGroundColor : strRGBColor
}

/*
set customer=__customer__
set windowTitle=__windowTitle__
set hostname=__hostname__
set ticketNumber=__ticketNumber__
set backGroundColor=__backGroundColor__
*/

  loadTemplate('cmdToPutty',function(){
   
   var strResult = LoadedTextScripts['cmdToPutty'];

    strResult = strResult.replace(/__customer__/g, templateValues.docCompany);
    strResult = strResult.replace(/__windowTitle__/g, templateValues.docId + " " + templateValues.docSummary);
    strResult = strResult.replace(/__hostname__/g, templateValues.docHostName);
    strResult = strResult.replace(/__ticketNumber__/g, templateValues.docId);
    strResult = strResult.replace(/__backGroundColor__/g, templateValues.backGroundColor);
   
    mUt.setClipBoardBuffer(strResult);
  });
}

var bPutty = addElementTo(nodePanel,'button','','Putty');
    bPutty.className = 'buttonUnknown';
	
var bColor = addElementTo(nodePanel,'input','','');
    bColor.type = 'color';
	bColor.value='#f50000';
  
bPutty.addEventListener('click',function(e){
  generateSessionFile( bColor.value);
  bPutty.className =  "buttonGood";
});

}


function addTicketToHistory()
{

  var nodes = [
  node.docCompany,
  node.docId,
  node.docPriority,
  node.docEditSummary,
  '//*[@name="$sel_assigned_team"]/option[@selected]',
  '//*[@name="$sel_assigned_person"]/option[@selected]'
  ].map(getXpath);

  var ticketValue = {

    time: Date.now(),
    docCompany: nodes[0].innerText.trim(),
    docId: nodes[1].innerText.trim(),
    docPriority:nodes[2].selectedOptions[0].innerText,
    docSummary: nodes[3].value.trim(),
    docTeam: nodes[4].innerText.trim(),
    docPerson: nodes[5].innerText.trim()
  }

  mSt.get(mSt.keys.historyPerCustomer, function(val)
  {
    var data = val[mSt.keys.historyPerCustomer] || {};

    var tickets = data[ticketValue.docCompany] || [];
    tickets.unshift(ticketValue);

    data[ticketValue.docCompany] = tickets;

    mSt.set( mSt.keys.historyPerCustomer, data );

    console.log("Added %o", ticketValue );
  });
  
}


function addTicketToHistoryButton(nodePanel)
{

 var b = addElementTo(nodePanel,'button','',"History");
 b.className =  "buttonUnknown";
 b.addEventListener('click', addTicketToHistory);


 var trackPerson =  document.querySelector('[name="$sel_assigned_person"]') ;
 var trackTeam =   document.querySelector('[name="$sel_assigned_team"]');

 trackPerson && (trackPerson.addEventListener('input', addTicketToHistory));
 trackTeam && (trackTeam.addEventListener('input', addTicketToHistory));
}


function addMonitorStateGoodButton(nodePanel)
{

 var b = addElementTo(nodePanel,'button','',"Good");
 b.className =  "buttonUnknown";
 b.addEventListener('click', function(){

  var stateButton = document.querySelector('select[name="monitor_state"]');

  if (stateButton)
  {
   stateButton.selectedIndex = 2;
 }

});
}


 /**  
     Adding button for quick place text in clipboard

     @param arg
     */
     function addSimpleClipboardShortcut(nodePanel,strTemplate,strLabel)
     {
       var b = addElementTo(nodePanel,'button','',strLabel);
       b.className =  "buttonUnknown";

       b.addEventListener('click', function(){

        loadTemplate(strTemplate,function(){

         result = LoadedTextScripts[strTemplate];
         mUt.setClipBoardBuffer(result);
         b.className =  "buttonGood";
       });
      }); 


     }

 /**  
    Option for populate additional inform panel
    
    @param opt Current option set
    */
    function optInformPanel(opt,tag)
    {
      var active = false;


      switch (tag)
      {
       case mCl.tags.viewI: 
       case mCl.tags.viewSR: 
       case mCl.tags.viewCR: 
       case mCl.tags.editI: 
       case mCl.tags.editSR: 
       case mCl.tags.editCR:
       { active=true; break;} 
     }

     if ( opt.ShowUpperInformPanel && active)
     {
      addGroupTypeElement(getShortTextPanel());
      addDedicCustomerElement(getShortTextPanel());
      
      addAlertLogButton(getButtonPanel());
      addSimpleClipboardShortcut(getButtonPanel(), "database","Database");


      addElementTo(getButtonPanel(),'br')

      addSimpleClipboardShortcut(getButtonPanel(), "sisA","Sis A");   
      addSimpleClipboardShortcut(getButtonPanel(), "sisB","Sis B");

      addElementTo(getButtonPanel(),'br')

      
      addTicketToHistoryButton(getButtonPanel());
      addMonitorStateGoodButton(getButtonPanel());

      addElementTo(getButtonPanel(),'br')      


      addPuttyLogButton(getButtonPanel() );


      var onceRun = function(e){
       var self =this;
       addTicketInstructionsElement(getLongTextPanel(),function(){
        self.removeEventListener('mousemove',onceRun); 
      });
     }

     getPanel().addEventListener('mousemove', onceRun );
   }
 }


/**  
       Realisation all options in current
       */
       function register()
       { 
        mSt.get(mSt.keys.flagsOption, function(res)
        {
          var opt = res[mSt.keys.flagsOption];
          var tag = mCl.classify();


          optInformPanel(opt, tag)  ;


          console.log("Slave <2> registered to actions");
        }); 

      }
    /**
        Return  object which will be public interface for functions 
        in that module
        */
        console.log("Loaded");
        console.groupEnd();

        return {
          "register": register

        };
      };


    }("opm@mode@slave_part_2");


