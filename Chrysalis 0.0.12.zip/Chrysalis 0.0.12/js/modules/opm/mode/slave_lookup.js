// This is for  alt key processing
     var lines =  document.querySelectorAll("#contentWrapperTable input.pointable");
     //console.log("First line selected", lines);
     if (lines.length > 0 ) lines[0].checked =true;


function getElementByXpath(path) {
  return document.evaluate(path, document, null,
           XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}


var link = getElementByXpath('//*[@id="$panelTable"]/tbody/tr/td/table[1]/tbody/tr/td/table[1]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td[2]/a');
var reloadControlPanel = document.getElementById('reloadControls');

if ( reloadControlPanel )
 {
  reloadControlPanel.parentNode.removeChild(reloadControlPanel);
 }


if ( link )
 {
  
	reloadControlPanel = document.createElement('span');
	reloadControlPanel.id = 'reloadControls';
	reloadControlPanel.innerHTML = "<input type='text' id='timeInput' style='width:20px'></input>";
    
  var wasDelay = 0;

    chrome.runtime.onMessage.addListener(function(request)
       {
       	 console.log('on request');
         var timeElement = document.querySelector('#timeInput');

          switch (request.type)
          {
          	case "cont-alarm":
          	{
            var delay = parseInt(timeElement.value);
		        if (isNaN( delay ) )
		         {
		          timeElement.value='7'; 
		          delay=15;
		         }

		         if ( ++wasDelay >= delay)
		         {
		          wasDelay = 0;
		          console.log('perform reload');
		          link.click();
		         }
		         else
		         {
		          console.log('current delay %d, must wait %d',wasDelay,delay);
		         }
		       }
           
          }
      });
     console.log('on load');
  	link.appendChild(reloadControlPanel);
 }
