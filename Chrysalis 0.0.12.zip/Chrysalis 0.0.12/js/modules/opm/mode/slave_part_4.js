/**
   Module for complex content functions
*/

window.Module.syncRoot = function(moduleName) {
  /**
     List of modules which must be loaded before this
  */
  window.Module.before[moduleName] = [
    "base@util",
    "opm@inf@string",
     "opm@inf@classify",
       "base@storage"
  ];

  window.Module.noncomplete[moduleName] = function() {
    console.group("module <" + moduleName + ">");

    var mUt  = Module.get("util");
    var mStr = Module.get("string");
    var mSt    = Module.get("storage");
    var mCl    = Module.get("classify");


    /**  
      Option for tracking tickets history and notes for customer
  
       @param arg
    */
function optAddPanelsAndButtons(opt,tag)
  {
    var active = false;
    
    switch (tag)
    {
     case mCl.tags.viewI: 
     
      { active=true; break;} 
    }

    if ( opt.optInformPanel && active)
    {   
      var ticket  = /[ISRCR]{1,2}$/.exec(tag)[0];
      var Xpath = mStr.Xpath[ ticket ];
      
   

    }   
 }




/**  
       Realisation all options in current
    */
  function register()
  { 
    mSt.get(mSt.keys.flagsOption, function(res)
     {
      var opt = res[mSt.keys.flagsOption];
      var tag = mCl.classify();

      optAddPanelsAndButtons(opt,tag);
   

      console.log("Slave <4> registered to actions");
     }); 

  }
    /**
        Return  object which will be public interface for functions 
        in that module
    */
    console.log("Loaded");
    console.groupEnd();

    return {
      "register": register
      
    };


 }; 

}("opm@mode@slave_part_4");



/*
   history tune (active on team select, priority print)
   Add text from work tab
   
   putty button (prod/non-prod color distinkt dirs per customer)
   
*/
