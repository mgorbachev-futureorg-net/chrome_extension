/**
   Module for complex option page  functions
*/

window.Module.syncRoot = function(moduleName) {
  /**
     List of modules which must be loaded before this
  */
  window.Module.before[moduleName] = [
    "base@util",
    "opm@inf@string"
  ];

  window.Module.noncomplete[moduleName] = function() {
    console.group("module <" + moduleName + ">");

    var mUt  = Module.get("util");
    var mStr = Module.get("string");

   

   function register()
   {
    var table = document.getElementById("menuRows");

    table.addEventListener("dblclick",function()
      {
        var exitsFreeRow = false;

        var rows = [].slice.call(table.querySelectorAll("#menuRows tr"));
        rows.every(function(row)
          { 
             [].slice.call(row.querySelectorAll("textarea")).every(function(area)
              {
                exitsFreeRow = area.value === "";
                return true;
              });
            return true;
          }); 

         if (! exitsFreeRow)
           {
             var row = document.createElement("tr");
              row.innerHTML += `  <td>
                                      <textarea ></textarea>
                                    </td>
                                    <td>
                                      <textarea ></textarea>
                                    </td>`;

            table.appendChild(row);
           }
      });


   }

  function getData()
  {
    var table = document.getElementById("menuRows");
    var contextMenus = [];

    var rows = [].slice.call(table.querySelectorAll("#menuRows tr"));
        rows.every(function(row)
          { 
            var values = [].slice.call(row.querySelectorAll("textarea")).map(function(area)
              {
                return area.value;
              });


            if (values[0] && values[1])
            {
              contextMenus.push({title:values[0], insertText:values[1]});
            }

            return true;
          }); 

    var oftenTeamsAndPersons = document.getElementById("oftenTeamsAndPersonsTextArea").value;
    
    return { contextMenus:contextMenus,
             oftenTeamsAndPersons:oftenTeamsAndPersons};
  }

  function setData(data)
   {
    document.getElementById("oftenTeamsAndPersonsTextArea").value = data.oftenTeamsAndPersons;
    

      var contextMenus = data.contextMenus;
      var table = document.getElementById("menuRows");
      table.innerHTML = "";

      var row = ` <tr><td>
                    <textarea ></textarea>
                  </td>
                  <td>
                    <textarea ></textarea>
                    </td></tr>`;

     contextMenus.every(function(elt){ table.innerHTML += row; return true; });

     var rows = [].slice.call(table.querySelectorAll("#menuRows tr"));
          rows.map(function(row,i)
          { 
            [].slice.call(row.querySelectorAll("textarea")).map(function(area,j)
              {
                if (0===j) area.value = contextMenus[i].title;
                if (1===j) area.value = contextMenus[i].insertText;
              });
          }); 
   }

    /**
        Return  object which will be public interface for functions 
        in that module
    */
    console.log("Loaded");
    console.groupEnd();

    return {
      "register": register,
      "getData" : getData, 
      "setData" : setData
    };


  };

}("opm@mode@options_part_1");