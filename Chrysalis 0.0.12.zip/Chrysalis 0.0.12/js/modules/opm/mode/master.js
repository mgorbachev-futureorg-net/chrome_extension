/**
    This is module for perform actions for implement options
    Master side (load at background page)
*/

window.Module.syncRoot = function (moduleName)
{
/**
   List of modules which must be loaded before this
*/
window.Module.before[moduleName] = [
                            "base@util",
                            "base@storage",
                            "opm@inf@string"
                            ] ;

window.Module.noncomplete[moduleName] = function()
 {
 console.group("module <" + moduleName+ ">");

  var mUt   = Module.get("util")   ;
  var mSt   = Module.get("storage");
  var mStr  = Module.get("string" );

 /**  
     Skeleton of URL to ticket
  */
var strURLWithRegInfo = null;

/**
   Part of URL with current session id
*/
var strSessionID = "";


 /**  
     Queue of requests to tabs in future
  */
var queueOfFutureRequests = {};

 /**  
      Times of next actions such as  XHR send
  */

 var time = {};


 /**  
     Register sending strRequest for strToken in future

     @param strToken Token for distinct requests
     @param strRequest Request for send in answer
  */
function  sendInFuture(strToken,strRequest)
 {
  mUt.assertType(strToken,"string");
  mUt.assertType(strRequest,"string");
 

  var queueForToken = queueOfFutureRequests[strToken];
  
  if (strRequest === "clear-queue")
  {
   queueForToken = [];
  }
   else if (!queueForToken)
  {
    queueForToken = [ strRequest ];
  }
  else
  {
    queueForToken.push(strRequest);
  }

  queueOfFutureRequests[strToken] = queueForToken;
  console.log(queueOfFutureRequests);
 }


 /**  
     Send request associated with token to tab with tabId
 
     @param strToken  String with token
     @param tabId     Id of tab to which send token
  */
 function sendNow(strToken, tabId)
 {
  mUt.assertType(strToken,"string");


  var queueForToken = queueOfFutureRequests[strToken];

  if (!queueForToken || queueForToken.length === 0)
  {
    console.error("No queue for token", strToken);
  }
  else
  {
   var strRequest = queueForToken.shift();

   if (tabId)
     {
       chrome.tabs.sendMessage(tabId, {type: strRequest}); 
     }
     else
       {
        chrome.runtime.sendMessage( {type: strRequest});
       }
   
   console.log("Send message <%s> to <%s>",strRequest,tabId);
   console.log(queueOfFutureRequests);
  }

 } 

 /**  
     Generate link to ticket using last loaded ticket as shablon

     @param selDocId String with document ID
  */               //SR123456  //123456
function getLinkToTocket(selDocId)
{
	 
      var number = /\d{5,6}/.exec(selDocId)[0];
	  var prefix = getDocPrefix( parseInt(number) );

      var _unifier = {  CR: "1978",
                        SR: "1806",
                        I : "2091",
                     };

      //_unifier=2091&_formatType=1&_recordId=512503&_prevTarget=close

      var linkToTicket = strURLWithRegInfo.slice();

      linkToTicket = linkToTicket.replace(/_unifier=\d{4}/,"_unifier="+_unifier[prefix]);
      linkToTicket = linkToTicket.replace(/_recordId=\d{5,6}/,"_recordId="+number);
   
   return  linkToTicket;
}

 
  /**  
      Generate sample link to tiket, actual field will be replace after
 
      @param webRequestUrl   String with url containing information about current session
   */
function genSampleLinkToTicket(strLinkPart)
 {
   console.log(strLinkPart);

    strURLWithRegInfo = 
        'https://support.dataintensity.com/gui2/record/edit.do;en;' +
         strLinkPart + '?' + 
         '_mode=view&_unifier=1806&_formatType=1&_recordId=150828&_prevTarget=close';
 }

 /**  
     Open view panel tab
  */
function makeViewTab()
{
 
  chrome.tabs.query({currentWindow:true, active:true}, function(tabs)
   {   
       chrome.extension.getViews({type:"tab"}).every(function(elt){elt.close(); return true;});

       chrome.tabs.create(
       {
        windowId : tabs[0].windowId,
        index: tabs[0].index + 1,
        active:false,
        url: chrome.extension.getURL("html/view_panel.html")
      });
   });

}


 /**  
     Implement context menus 
  */
  function optionContextMenus(opt)
  {
    if ( opt.ContextInsert )
    {
     mSt.get(mSt.keys.textFields, function(val)
       {
         val[mSt.keys.textFields].contextMenus.every(function(elt)
         {
             chrome.contextMenus.create(
                {
                  id   : elt.insertText,
                  title: elt.title,
                  contexts : ["editable"]
                });
             return true;
         });

       });


       chrome.contextMenus.onClicked.addListener(function(info){

          var insertText = info.menuItemId;

          chrome.tabs.query({currentWindow: true,active:true}, function(tabs) 
            {   
             chrome.tabs.sendMessage(tabs[0].id,
                  {type:"cont-InsertText", data:insertText });
           }); 
       
       });
    }
  }

  /**  
      Manipulations with data slot
 
      @param opt Current options set
   */
   function optionClipSlots(opt)
   {
     if ( opt.DataSlots )
      {
        
     chrome.commands.onCommand.addListener(function(command)
      {
        switch (command)
        {
          case "dataSlotRead":
           {
              mSt.get(mSt.keys.dataSlot,function(item)
              {
                var slotValue= item[mSt.keys.dataSlot];
                mUt.setClipBoardBuffer(slotValue);
              });

            break;
           }

           case "dataSlotWrite":
           {
                var clipValue= mUt.getClipBoardBuffer();   
                mSt.set(mSt.keys.dataSlot,clipValue);
          
            break;
           }
           
        }
      });


        
      }
   }

  /**  
      Search for ticket by summary and open ticket if finded
  */
  function tryFindAndOpenTicket(strTicketInfo)
  {  
	console.log("try to open for <%s>",strTicketInfo); 
	  
	var tables = [
	{id:'1806', column:'summary'},
	{id:'2091', column:'summary'},
	{id:'1978', column:'change_summary'}
	]
	
	
	
	var validatorDocId = /\d{5,6}/;
	 
	var strValueToSearch = escape(strTicketInfo);
	
	//Search for SR, I and CR
	tables.map(function(table)
	 {	
		var searchLink = `https://support.dataintensity.com/gui2/data/search.do;en;${strSessionID}?tableId=${table.id}&q_id=${table.id}&table=${table.id}&$columnDbName=${table.column}&$value=${strValueToSearch}&$operation=2`;
		
		console.log('generate search link as %s',searchLink);
		
		var xmlhttp = new XMLHttpRequest();

		xmlhttp.onreadystatechange = function()
		{
		  if (xmlhttp.readyState==xmlhttp.DONE && xmlhttp.status==200)
			{
			  var tableData = parseTable(xmlhttp.responseText, "view=2956");
			  console.log("parsed response %o",tableData);
			  
			  //If exist rows for tickets with this summary
              if (tableData.data)
			  {		  
				  var findedTickets = tableData.data.filter(function(row){ return row.length > 2}).slice(0,2).map(function(row){
					return row.find(function(elt){return validatorDocId.test(elt)}) ;
				  });
				  
				  console.log("first of finded  %o",findedTickets);
				  
				  //If exist docId then generate link to this docId
				  if (findedTickets.length > 0)
				   {
                    console.log("try to open first of them");			
					openTabWithTicketById( findedTickets[0]); 
				   } 
				  
					  
			  }
			  					  
			}
		}

		xmlhttp.open("GET", searchLink,true);
		xmlhttp.send();
					
 	 });
	
	
  }
   
   /**
      Open new tab for ticket with this docId
   */
  function openTabWithTicketById(strTicketId)
  {
	 var linkToTicket = getLinkToTocket(strTicketId);

	 chrome.tabs.query({active:true}, function(tabs) 
	  {   
		 var tabCurIndex = tabs[0].index;
	
		 chrome.tabs.create(
		 {
		  index: tabCurIndex+1,
		  active:false,
		  url: linkToTicket
		},
				 function(tab)
				 {
				   chrome.tabs.update(tab.id,{active:true});	 
				 });			 
	   });
	   
  }  


function getDocPrefix(number)
{
var result = "";
var intNumber = number;
	 if (intNumber >500000 && intNumber < 700000)
	  {
		result = "I";
	  }
	  if (intNumber >90000 && intNumber < 150000)
	  {
		result = "CR" ;
	  }
	  if (intNumber >150000 && intNumber < 200000 )
	  {
		result = "SR";
	  }
return result;
}
  
 /**  
     Quick ticket open from clipboard

     @param opt Current options set
  */

   function optionQuickTicketOpen(opt)
   {
      if ( opt.QuickTicketOpen )
      {
       
     
      time.nextFetch = new Date();    
       

        /**  
            Resend XHR request and search response in order to find
            data about session      
 
            @param args Object with XHR information
         */
         var ripFunc = function(args)
         {
              time.now = new Date();  

               /**  
                   Check if last refresh was long enouth
                */
              if (time.now > time.nextFetch)
               {
                var xmlhttp = new XMLHttpRequest();

                xmlhttp.onreadystatechange = function()
                {
                  if (xmlhttp.readyState==4 && xmlhttp.status==200)
                    {
                      var regExtract = /jsessionid=\S{30,40};CSRF_NONCE=\S{32}/;
                      var linkPart = regExtract.exec(xmlhttp.responseText)[0];
                      
					  strSessionID = linkPart;
					  genSampleLinkToTicket(linkPart);
                    }
                }

                xmlhttp.open("GET", args.url,true);
                xmlhttp.send();

                /**  
                    Make schedule for next request
                 */
               time.nextFetch = new Date( Date.now() + 30000);    
               }
         }

         var filter = { urls: ["https://support.dataintensity.com/gui2/get_data.jsp*"]};
         chrome.webRequest.onCompleted.addListener(ripFunc,filter);



          /**  
              Process command for scan clipboard and open ticket by docId
           */
         chrome.commands.onCommand.addListener(function(command){
 
          console.log("Command " + command); 

         if (command === "scanExchangeBuffer")
         {
           var selDocIdMany = mUt.getClipBoardBuffer().trim();
           
		
           selDocIdMany.split(/\s/).map(function(selDocId, index){
			  
			selDocId = selDocId.toUpperCase().trim(); 
			if ( selDocId.length < 3) return;

		  var validatorDocId = /(CR\d{5}|SR\d{5,6}|I\d{6})/;


              /**  
                  Try guess about type of ticket
                                        
              */            
      		   if (! validatorDocId.test(selDocId))
      		   {
              var number = /^\d{5,6}/.exec(selDocId); 
      				
      				if (number)
      				{
      				  var intNumber = parseInt(number);
      				  selDocId = getDocPrefix(intNumber) + String(intNumber);
					  
      				}
      			   console.log("Doc Id after recover try ",selDocId);
      		   }
      		   
		   
		       /**  
                Try open ticket in new tab
            */
             if (validatorDocId.test(selDocId) )
             {
			   openTabWithTicketById(selDocId);
             }
			
			 if (!validatorDocId.test(selDocId) && index === 0)
			  {
				tryFindAndOpenTicket(selDocIdMany);	  
			  }
			 
			  });
			 
           }
         });
      }    
   }


 /**  
     Parse response in order to find information about tickets

     @param strHtml html data
     @param strURL  String with URL of data source
  */
function parseTable(strHtml, strURL)
 {
   var h  = document.createElement('html');

  strHtml = strHtml.replace(/src="\/gui2\/[^"]*"/,"");
  strHtml = strHtml.replace(/href="\/gui2\/[^"]*"/,"");

  h.innerHTML = strHtml;
   
  var header = h.querySelector("#headerWrapperTable");
  
   /**  
       Dictionary with type of tickets by this URL
    */
  var code = 
   {
   "2956": 'Not assigned CR',
   '2957': 'Not assigned SR',
   '2955': 'Not assigned I' ,
   '2575': "Monitoring CR"  ,
   '2577': "Monitoring SR"  ,
   '2576': "Monitoring I"  
   }

   var table = 
     {
      title : code[ (/view=(\d{4})/).exec(strURL)[1] ], 
      data: null,
      labels : null
     };
 
 /**  
     If data exists
  */
  if (header)
  {
    /**  
        Select headers labels
     */
   var labels = [].slice.call(h.querySelectorAll("#headerWrapperTable td div")).map(function(td)
    {
		var result = "<no data>";
		
		if (td.innerText)
		{
		 result = td.innerText.trim().replace(/\n|\t/g,"");
		}
		
		return result;
    }); 
	
labels.shift();

  
    /**  
        Select row data
     */
   var data = [].slice.call(h.querySelectorAll("#contentWrapperTable  tr")).map(function(elt)
    {
      return [].slice.call(elt.querySelectorAll("td")).map(function(td)
        {
         var result = "<no data>";
		
		if (td.innerText)
		{
		 result = td.innerText.trim().replace(/\n|\t/g,"");
		}
		
		return result;
        });
    }); 
  
  
   table.data   = data;
   table.labels = labels;
  }
  
  return table;    
 }

 /**  
     Collect list of URL and perform data request

     @param arg
  */
var collector = new function()
{

var count;

function start()
{
  count = 0;
  urls = [];
  time.nextFetch = new Date( Date.now() + 30000);
  stop();

  var filter = { urls: ["https://support.dataintensity.com/gui2/get_data.jsp*"]};
  chrome.webRequest.onCompleted.addListener(process,filter);
}

function stop()
{
   chrome.webRequest.onCompleted.removeListener(process);
}


var urls = null;

function process(args)
 {
   if (urls.length < 6)
    {
      urls.push(args.url);
      console.log("Now know " + urls.length + " urls");
    }
   

   if (urls.length === 6)
    {
     stop();

     urls.every(function(url)
      {
         var xmlhttp = new XMLHttpRequest();

          xmlhttp.onreadystatechange = function()
          {
            if (xmlhttp.readyState==4 && xmlhttp.status==200)
              {
                var table = parseTable(xmlhttp.responseText,url);
                console.log(table);
                chrome.runtime.sendMessage({type:"view-tableData", data:table});
              }
          }

      xmlhttp.open("GET", url,true);
      xmlhttp.send();
     
      return true;
      });

          
       console.log("Send requests");
    }
 }

return {start:start};

}();









function optReloadTitlePage(opt)
  {
     chrome.browserAction.onClicked.addListener(function(tab)
      { 
         if (tab.title === "Data Intensity ITIL Service Desk")
         {
            mSt.get(mSt.keys.flagsOption, function(res)
            { 
             var opt = res[mSt.keys.flagsOption];
             
            if ( opt.ReloadTitlePage)
            {     
  
            chrome.tabs.executeScript(tab.id, {allFrames: true, 
                 file: "js/modules/opm/mode/slave_lookup.js"} );

            console.log('Activate optReloadTitlePage');  
             }
            });

         }    
    });



  //Register alarm for periodically sent notifications

   if ( opt.ReloadTitlePage)
    {
       chrome.alarms.create('reloadhome', {periodInMinutes:1});


    chrome.alarms.onAlarm.addListener(function(alarm)
     {
       
       if ( alarm.name === "reloadhome")
       {
         chrome.tabs.query({title:"Data Intensity ITIL Service Desk"},function(tabs)
          {
            chrome.tabs.sendMessage(tabs[0].id,{type:"cont-alarm",
                                             data:null} );

          });
       }

     });


    }   

 }








    /**  
        Gather information about one ticket or all tickets related to monitoring team
   
        @param opt Current option set
     */
  function optionOpenView(opt)
   {
  
      chrome.browserAction.onClicked.addListener(function(tab)
      { 
          mSt.get(mSt.keys.flagsOption, function(res)
            { 
             var opt = res[mSt.keys.flagsOption];
             
            if ( opt.CollectAllTablesData)
            {   
       
             if (tab.title === "Data Intensity ITIL Service Desk")
               {
                 sendInFuture("view-page","view-gatherTableInfo");
               }
              else
              {
                sendInFuture("view-page","view-gatherTicketInf");
              }

              makeViewTab();

            }
         });
      });
    }
   

















    /**  
      Register message listeners
   
      @param opt Current option set
     */
   function optionMessagePass(opt)
    {
      
      chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
       {
          switch (request.type)
          {
            case "back-sendInFuture":
            {
              sendInFuture(request.data.token, request.data.request);
              console.log(request);
              sendResponse();
              break;
            }
           
            case "back-sendNow":
            {
              sendNow(request.data.token, request.data.tabId);
              console.log(request);
              sendResponse();
              break;
            }
           
            case "active-TicketInf":
            {
              chrome.tabs.query({currentWindow:true, active:true}, function(tabs) 
               {  
                chrome.tabs.sendMessage(tabs[0].id, {type:"cont-TicketInf", data:request.data});
               });
 
              break;
            }

            case "back-TicketInf":
            {
              chrome.runtime.sendMessage({type:"view-TicketInf",
                                             data:request.data});
              break;
            }

            case "back-FindEmail":
            {
              chrome.tabs.remove(request.data.tabId);  
              chrome.runtime.sendMessage({type:"view-FindEmail",data:request.data});
              break;
            }

            case "active-viewTable":
             {
               collector.start();
             }
          }

         });
    }

 /**  
     Create short informational message about ticket
    
     @param opt Current option set
  */
  function optionShortMessageCreate(opt)
   {
     if (opt.ShortMessageCreate)
     {
         chrome.commands.onCommand.addListener(function(command){
           if (command === "genShortInf")
           {
             sendInFuture("view-page","view-gatherShortTicketInf");
             makeViewTab();
          }
         });

      }

   }
  


 function basicBackgroundPageOperations(opt)
  {
  /**
  General (support for moduleSystem.js and bookmark.js )
  Process messages from other pages
  
  @param request      message details
  @param sendResponse callback, which must be executed after end of 
                      message processing
*/
  var tmpStorage = mUt.refine({});

 chrome.runtime.onMessage.addListener(
   function(request, sender, sendResponse)
  {
 
  switch  (request.type)
  {
 
  case "back-getTmpData":
   {
    var res = mUt.refine({});
    res[request.data.key] =tmpStorage[request.data.key] || ""; 
   
    sendResponse( res );
    break;
   }
   
   case "back-setTmpData":
   {
    tmpStorage[request.data.key] = request.data.value; 
    break;
   }

   /**
   In order to differ content scripts, we must know tabs id in which
   they executed.
   This tab id may be known if send request to all tabs with their id
   then each tab can save this id for future use
   */
  case "back-pingReq":
   {
    chrome.tabs.query({},function(tabs)
      {  
         tabs.every(function(tab)
          {
           chrome.tabs.sendMessage(tab.id,
             {type: "content-pingRes", thisTab : tab});
           return true;
          });

      });

     break;
   }

  /**
   request to perform api call for one of tabs
  
  @param request.api    array of keys for locate APi
  @param request.args   args for api call
  */
  case "back-apiCall":
   {
    var stubLog = function(arg)
     {
      sendResponse(arg);
     };

    var api = request.api;
    var args= request.args;

    var curApi = chrome;

    for (var i=0; i<api.length; i++)
      curApi = curApi[ api[i] ];
   
    for (var i=0; i<args.length; i++)
      if (args[i] === "<sendResponse>")
        args[i] = stubLog; 
   
   switch (args.length)
    {
     case 1: 
     {
     curApi(args[0]);
      break;}
     case 2: 
     {
      curApi(args[0],args[1]);
      break;}
      case 3: 
     {
      curApi(args[0],args[1],args[2]);
      break;}
     case 4: 
     {
      curApi(args[0],args[1],args[2], args[3]);
      break;}
     case 5: 
     {
      curApi(args[0],args[1],args[2], args[3], args[4]);
      break;}

    }
    
  
   /**
   Return true indicated that sendResponce callback will be
   call asynchronously

   */
   return true;
   break;
   }
 }

});

  }

   

   /**  
       Realisation all options in current options set
    */
  function register()
  { 
    mSt.get(mSt.keys.flagsOption, function(res)
     {
      var opt = res[mSt.keys.flagsOption];
      
     basicBackgroundPageOperations();

      optionContextMenus(opt)      ;
      optionClipSlots(opt)         ;
      optionQuickTicketOpen(opt)   ;
      optionOpenView(opt)          ;
      optionMessagePass(opt)       ;
      optionShortMessageCreate(opt);
      optReloadTitlePage(opt)      ;

      console.log("Master registered to actions");
     }); 

  }
  /**
      Return  object which will be public interface for functions 
      in that module
  */ 
console.log("Loaded");
console.groupEnd();
  	
  return {
   "register" : register
  };

};

}("opm@mode@master");