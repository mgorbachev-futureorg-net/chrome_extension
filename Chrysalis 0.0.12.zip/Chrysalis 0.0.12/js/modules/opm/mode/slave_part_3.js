/**
   Module for complex content functions
*/

window.Module.syncRoot = function(moduleName) {
  /**
     List of modules which must be loaded before this
  */
  window.Module.before[moduleName] = [
    "base@util",
    "opm@inf@string",
     "opm@inf@classify",
       "base@storage"
  ];

  window.Module.noncomplete[moduleName] = function() {
    console.group("module <" + moduleName + ">");

    var mUt  = Module.get("util");
    var mStr = Module.get("string");
    var mSt    = Module.get("storage");
    var mCl    = Module.get("classify");


 /**  
      Style for display history table
  
       @param arg
    */	
function loadStyle()
{
	 var css        = document.createElement("style");

      //CSS table for new created elements
      css.innerHTML = `

	   #historyPanel {
		   width:100%;
		   display : block;
       background-color: #EFF4FF;
	   }

 
     #historyNotes{
      display:inline-flex;
      width : 79%

     }
     #historyNotes textarea{

      width:100%;
      min-height:75px;
     }
  
     #historyControls{
      display:inline-table;
       width : 20%
     }

      #historyControls button{
       width : 100%;
       height:25px;
       margin : 3px;
     }

     #historyTickets{

      display:block;
      width : 100%;

     }

    #historyTickets table{

      width: 100%;
    }

     #historyTickets table * {
     
      border-width: 0px 3px 3px 0px;
      border-style: ridge; 
     }
   
     #historyTickets  td {

      text-align : left;
     }

      #historyTickets td:first-child {
      text-align : center;
     }

      `;
   
    document.body.appendChild(css);   
}


/*

time: Date.now(),
  docCompany: nodes[0].innerText.trim(),
  docId: nodes[1].innerText.trim(),
  docSummary: nodes[2].value.trim(),
  docTeam: nodes[3].innerText.trim(),
  docPerson: nodes[4].innerText.trim()
*/

 /**  
     Create table with history of tickets

     @param arg
  */
function dumpTicketHistoryToTheTable(strDocCompany)
 {
   var table = document.querySelector("#historyTickets table");

   var htmlHead = `<colgroup>
      <col width="3%">
      <col width="8%">
      <col width="5%">
      <col width="12%">
      <col width="15%">
      <col width="15%">
      <col width="*"  >  
    </colgroup> 
    <tr>
     <th>#</th>
     <th>Ticket Id</th>
     <th>Ticket priority</th>
     <th>Time</th>
     <th>Assigned Team</th> 
     <th>Assigned Person</th> 
     <th>Ticket summary</th> 
    </tr>
    `;


  var htmlBody = "";

   mSt.get(mSt.keys.historyPerCustomer, function(val)
      {
      var data = val[mSt.keys.historyPerCustomer] || {};
      var tickets = data[strDocCompany] || [];
       
      htmlBody = tickets.map(function(ticketInf,i)
        {
          var time = new Date(ticketInf.time);
          var timeStr = time.toLocaleTimeString() + " " + time.toLocaleDateString().replace(/\/\d{4}/,"");

          return `
          <tr>
          <td><input type="checkbox" id=historyTicket${i}></input> </td>
          <td>${ticketInf.docId}</td>
          <td>${ticketInf.docPriority || ""}</td>
          <td>${timeStr}</td>
          <td>${ticketInf.docTeam}</td>
          <td>${ticketInf.docPerson}</td>
          <td>${ticketInf.docSummary}</td>
          </tr>
          `;

        }).join("\n");
            
       table.innerHTML = htmlHead + htmlBody;
      console.log("History table created");
     });

 }


function setSelectedCheckBox(parentNodeId, boolValue)
 {
  var parentNode = document.getElementById(parentNodeId);

   [].slice.call(parentNode.querySelectorAll("input")).map(function(elt)
    {
      elt.checked = boolValue;
    });
 }


 /**  
     Create block with history and notes information

     @param arg
  */
function generateHistoryView(targetPlace, Xpath)
{
	var historyPanel = document.createElement('div');
	historyPanel.id = 'historyPanel';
	 
	historyPanel.innerHTML = `
  
	<div id="historyNotes">
  <textarea> </textarea>
   </div>
	
 <div id="historyControls">
   <button id="selectAll">Select all</button>
   <button id="delesectAll">Deselect all</button>
   <button id="deleteSelected">Delete selected</button>
</div>

 <div id="historyTickets">
   <table> 
    <tbody> 

    </tbody>   
  </table>

</div>
 
 

	`;

var customer = mUt.getElementByXpath(Xpath.docCompany).innerText.trim();


 /**  
      Process events for notes panel

     @param arg
  */
var notes = historyPanel.querySelector('textarea');

var wasChanged = false;

notes.addEventListener('input',function(e)
    {
    wasChanged = true; 
  });


notes.addEventListener('blur',function(e)
    {
      if (wasChanged)
      {
          mSt.get(mSt.keys.notesPerCustomer, function(val)
          {
          var data = val[mSt.keys.notesPerCustomer] || {};
          data[customer] = e.target.value;
          
          mSt.set( mSt.keys.notesPerCustomer, data );
         });

        wasChanged = false;  
      }
      else
      {
          mSt.get(mSt.keys.notesPerCustomer, function(val)
          {
          var data = val[mSt.keys.notesPerCustomer] || {};
          e.target.value = data[customer] || "No value was saved";
          
         });

      }
  
   dumpTicketHistoryToTheTable(customer);
  });

 mSt.get(mSt.keys.notesPerCustomer, function(val)
      {
      var data = val[mSt.keys.notesPerCustomer] || {};
      notes.value = data[customer] || "No value was saved";
      dumpTicketHistoryToTheTable(customer);
     });	
	

historyPanel.querySelector('#selectAll').addEventListener('click',function()
  {
    setSelectedCheckBox('historyPanel',true);
  });

historyPanel.querySelector('#delesectAll').addEventListener('click',function()
  {
    setSelectedCheckBox('historyPanel',false);
  });

historyPanel.querySelector('#deleteSelected').addEventListener('click',function()
  {
     mSt.get(mSt.keys.historyPerCustomer, function(val)
      {
      var data = val[mSt.keys.historyPerCustomer] || {};
      var tickets = data[customer] || [];
    
      [].slice.call(historyPanel.querySelectorAll("input:checked")).map(function(elt)
      {
       var index = parseInt( elt.id.replace("historyTicket","") );

       tickets[index] = null;
      });     
 
      tickets = tickets.filter(function(elt){return elt != null}); 

      console.log(tickets);
    

      data[customer] = tickets;
      mSt.set( mSt.keys.historyPerCustomer, data );     
      dumpTicketHistoryToTheTable(customer);
      console.log("Tickets deleted");
     }); 
   




     
  });


	




	targetPlace.insertBefore(historyPanel, targetPlace.childNodes[0]);
}

 /**  
     Hide and show history and notes panel

     @param arg
  */
function changeView(boolShow)
{
 var panel = document.getElementById('historyPanel'); 

  if (panel)
  {
   panel.parentNode.querySelector(".layoutContainer").style.display = boolShow? 'none' : 'initial';
   panel.style.display = boolShow? 'block' : 'none';
  }

}

	 /**  
      Option for tracking tickets history and notes for customer
  
       @param arg
    */
function optTrackHistoryAndNotes(opt,tag)
  {
    var active = false;
    
    switch (tag)
    {
     case mCl.tags.viewI: 
     case mCl.tags.viewSR: 
     case mCl.tags.viewCR: 
     case mCl.tags.editI: 
     case mCl.tags.editSR: 
     case mCl.tags.editCR: 
      { active=true; break;} 
    }

    if ( opt.ReorginizeFields && active)
    {   
      var ticket  = /[ISRCR]{1,2}$/.exec(tag)[0];
      var Xpath = mStr.Xpath[ ticket ];
      
	    var historyActivate = false;
      var historyTab = mUt.getElementByXpath(Xpath.docHistoryTab);
      var historyPage = mUt.getElementByXpath(Xpath.docHistoryPage);
	  
	  var wasGenerated = false;
	 
      //Process double click by tab title
      historyTab.addEventListener("dblclick", function(e) {
       
    	  if (! wasGenerated)
    	  {
    		generateHistoryView(historyPage, Xpath);
    	  loadStyle();
    		wasGenerated = true;
    	  }
    	 
    		 historyActivate = !historyActivate 
    		 changeView(  historyActivate ); 		 
      });


    }   
 }




/**  
       Realisation all options in current
    */
  function register()
  { 
    mSt.get(mSt.keys.flagsOption, function(res)
     {
      var opt = res[mSt.keys.flagsOption];
      var tag = mCl.classify();

      optTrackHistoryAndNotes(opt,tag);
   

      console.log("Slave <3> registered to actions");
     }); 

  }
    /**
        Return  object which will be public interface for functions 
        in that module
    */
    console.log("Loaded");
    console.groupEnd();

    return {
      "register": register
      
    };


 }; 

}("opm@mode@slave_part_3");



/*
   

   putty button (prod/non-prod color distinkt dirs per customer)
   
*/
