  /*
  var s = [].slice.call(document.querySelectorAll("span, tr>td:first-child"));

         s.map(function (elt)
           {if (elt.innerText.endsWith(":")) elt.style.fontWeight = 'bold' })

  */

 var elts = [];

  elts = document.querySelectorAll("span, tr>td:first-child, tr>td:only-child" );

  for (var i=0; i<elts.length; i++ )
  {
   var elt = elts[i];
   if (elt.innerHTML.endsWith(":")) elt.style.fontWeight = 'bold';
  }

/*
 elts = document.querySelectorAll("div" );

  for (var i=0; i<elts.length; i++ )
  {
  	var elt = elts[i];
    elt.style.border = '1px solid';
  }

*/