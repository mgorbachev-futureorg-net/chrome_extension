/**
    This is module for perform actions for implement options
    Slave side (load at tabs for content_opm.js)
    */

    window.Module.syncRoot = function (moduleName)
    {
/**
   List of modules which must be loaded before this
   */
   window.Module.before[moduleName] = [
   "base@util",
   "opm@inf@classify",
   "opm@inf@string",
   "base@storage"
   ] ;

   window.Module.noncomplete[moduleName] = function()
   {
     console.group("module <" + moduleName+ ">");
  /**  
      Ofterm used modules 
      */
      var mUt    = Module.get("util");
      var mCl    = Module.get("classify");
      var mStr   = Module.get("string");
      var mSt    = Module.get("storage");

   /**  
       Realisation of mass edit option
  
       @param opt  Current options set
       */
       function optionMassEdit(opt,tag)
       {
        var active = false;

        switch (tag)
        {
         case mCl.tags.massEdit: { active=true; break;} 
       }

       if ( opt.MassEditEnhancenment && active)
       {     
        var labelClass = "x_usedFields";

        var list = document.createElement('ul');
        list.textContent = "Quick field select";
        list.innerHTML += "<br><br>";
        list.style.cssText =  "color      : black;     " +
        "font-family: sans-serif;" +
        "padding    : 15px;      " +
        "font-size  : large;     " + 
        "font-weight: bold;      " + 
        "background : #eff3ff;    " +
        "border       : black;"  +
        "border-width : thick;"  +
        "border-style : double;" +
        "border-radius: 25px;";

        var fields = [ "Assigned Team",
        "Assigned Person",
        "Time Spent",
        "Status",
        "Investigation Notes",
        "Additional Notes",
        "Additional Information",
        "Staff Only Working Notes",
        "Resolution",
        "Staff Only Notes",
        "Monitor State"
        ];

        var labels = document.querySelectorAll('label.pointable'); 
        for (var i=0; i< labels.length; i++ )
        {
         var curLab = labels[i];
         var labText = curLab.textContent.trim();

         if ( fields.indexOf(labText) !== -1 )
         {
          var label = document.createElement('label');
          label.dataset['x_for'] = curLab.htmlFor;
          label.textContent = curLab.textContent;
          label.className = labelClass;
          label.style.cssText = "color      : green;     " +
          "font-family: sans-serif;" +
          "font-size  : large;     " + 
          "font-weight: bold;      ";


          list.appendChild(label);
          list.innerHTML += "<br>";
        } 
      }

      list.addEventListener('click', function(e)
      {    
        if (e.target.className === labelClass )
        {
          var label = e.target;
          var elt = document.getElementById(label.dataset['x_for']);

          elt.checked = ! elt.checked;
          label.style.color = elt.checked ? 'red': 'green';
        }

      });

      var table = mUt.getElementByXpath('//*[@id="wizardDiv"]/form/table/tbody/tr[2]/td/table/tbody/tr[3]/td/table/tbody/tr[3]/td/fieldset/table/tbody');
      table && table.insertBefore(list,table.childNodes[0]); 

    }

  }

 /**  
     Realisation of hotkey option

     @param opt Current options set
     */
     function optionTicketHotkey(opt,tag)
     {
      var active = false;


      switch (tag)
      {
       case mCl.tags.viewI: 
       case mCl.tags.viewSR: 
       case mCl.tags.viewCR: 
       case mCl.tags.editI: 
       case mCl.tags.editSR: 
       case mCl.tags.editCR:
       case mCl.tags.newI: 
       case mCl.tags.newSR: 
       case mCl.tags.newCR:  
       { active=true; break;} 
     }

     if ( opt.TicketsHotkey && active)
     {
       var tab_w = (tag.indexOf("CR") !== -1  ) ? "tab_2_inactive" : "tab_1_inactive";
       var tab_e= "tab_0_inactive";
       var tab_v= "tab_9_inactive";

       var tab_e_active = "tab_0_active";
       var tab_v_active = "tab_9_active";

       document.getElementById(tab_w).querySelector("div").accessKey="w";
       document.getElementById(tab_e).querySelector("div").accessKey="d"; 

       var hist = document.getElementById(tab_v);

       if (hist)
       {
        hist.querySelector("div").accessKey="v"; 
        hist.querySelector("div").addEventListener('click',function(){
         document.getElementById(tab_v_active).querySelector("div").dispatchEvent(new MouseEvent("dblclick"));
       });
      }

      document.getElementById(tab_e).querySelector("div").addEventListener('click',function(){
        document.getElementById(tab_e_active).querySelector("div").dispatchEvent(new MouseEvent("dblclick"));
      });

      var but;
      (but = document.querySelector('input[type="button"][value="Edit"]') ) && (but.accessKey="e");
      (but = document.querySelector('[id="$finishMenuBut1"]') )&& (but.accessKey="s");
      (but = document.querySelector('[id="$cancelMenuBut1"]') ) && (but.accessKey="c");
    }

  }



  /**  
      Realisation of change title option
 
      @param opt Current options set
      */
      function optionChangeTitle(opt,tag)
      {
        var active = false;


        switch (tag)
        {
         case mCl.tags.viewI: 
         case mCl.tags.viewSR: 
         case mCl.tags.viewCR: 
         case mCl.tags.editI: 
         case mCl.tags.editSR: 
         case mCl.tags.editCR: 
         { active=true; break;} 
       }


       if ( opt.ReplaceTabTitle && active)
       {
        var getXpath = mUt.getElementByXpath;
        var ticket  = /[ISRCR]{1,2}$/.exec(tag)[0];
        var node = mStr.Xpath[ticket];

        var docId = getXpath( node.docId ).innerText.trim();
        var docCompany = getXpath( node.docCompany).innerText.trim();

        var code = docId.replace(/(\d{3})/, function(x){return " " + x + " ";});

        document.title = code +"-" +  docCompany;
      }

    }

  /**  
      Process message for insert text in active element
 
      @param opt Current option set
      */
      function optionContextMenus(opt,tag)
      {
        var active = false;


        switch (tag)
        {
         case mCl.tags.editI: 
         case mCl.tags.editSR: 
         case mCl.tags.editCR:
         case mCl.tags.newI: 
         case mCl.tags.newSR: 
         case mCl.tags.newCR: 
         case mCl.tags.massEdit: 
         { active=true; break;} 
       }

       if ( opt.ContextInsert && active)
       {
         chrome.runtime.onMessage.addListener(
           function(request, sender, sendResponse)
           {

            switch  (request.type)
            {    
             case "cont-InsertText":
             {  
               var active =  document.activeElement;   

               if (active.value === "")
               {
                active.value = request.data;
              }
              else
              {
               active.value = active.value + "\n" +  request.data;
             }
           }
         }
       });

       }
     }


     function oftenElementsChoose(e)
     {
      var area = e.target;
      var selection = area.value.substring(area.selectionStart, area.selectionEnd);

      var teams = mUt.getElementByXpath('//*[@name="$sel_assigned_team"]'); 
      var persons = mUt.getElementByXpath('//*[@name="$sel_assigned_person"]'); 

      [persons,teams].every(function(list)
      {
       if (list)
       {
        var index=-1;
        var searchAhead = true;
        list.style.height = '30px'
        list.multiple = false;


        [].slice.call(list.children).every(function(elt)
        {
          index++;

          elt.hidden = false;
          var name = elt.innerText;

          if (selection && name.toLowerCase().includes(selection.toLowerCase().trim() ))
          { 
            searchAhead = false;
          }

          return searchAhead;
        });


        if (!searchAhead)
        {
          [].slice.call(list.children).map(function(elt,i)
          {
           if (i !== index) elt.hidden = true;
         });

          list.multiple  = true;
        }
      }
      
      return searchAhead;
    });

    }


  /**  
      Modify dropdown list with team names
 
      @param opt  Current options set
      */
      function optionOftenTeam(opt)
      {
        var list = mUt.getElementByXpath('//*[@name="$sel_assigned_team"]'); 

        if (list && opt.SelectTeamEnhancement )
        {
         preparePanel();

         mSt.get(mSt.keys.textFields, function(val)
         {
           var area = document.createElement("textarea");
           area.disabled = true;
           area.style.resize = 'none';
           area.addEventListener('click',oftenElementsChoose);
           area.addEventListener('select',oftenElementsChoose);
           area.addEventListener('blur',function(){mUt.autoResize(area)});

           area.value = val[mSt.keys.textFields].oftenTeamsAndPersons;


           document.getElementById("extPanel").appendChild(area);  
           mUt.autoResize(area); 		 

         });
       }

     }

     function preparePanel()
     {
       var panel = document.getElementById("extPanel");

       if (! panel)
       {
         panel = document.createElement("div");

         panel.id = "extPanel";
         panel.className = "extPanel"; 

         var place = document.querySelectorAll('div.SICommonArea')[0];  
         place.appendChild(panel);
       }

     }

   /**  
      Register message listeners
   
      @param opt Current option set
      */
      function optionMessagePass(opt,tag) 
      {
        var getElementByXpath = mUt.getElementByXpath;


        function toSimpleObject(obj)
        {

         var trimObj = {};

         for (var key in obj)
         {
          var field = obj[key];


          if (field)
          {
            var fieldText = "<no data>";

            if ( field.textContent && /^[\w-]{1,20}$/.test(field.textContent)  )
            { 
              fieldText = field.textContent.trim();
            }
            else if (field.innerText)
            {
              fieldText = field.innerText.trim();
            }
            else
            {
             fieldText = field.toString();
           }
           

           trimObj[key] = fieldText;
         }

       }

       return trimObj;
     }

     function hasNullField(obj)
     {
       var hasNull = false;

       for (var key in obj)
       {
        var field = obj[key];

        if (field === null || field === undefined)
        {
          hasNull = true;
          break;
        }
      }

      return hasNull;  
    }


    function gatherTicketInf(followEmail)
    {

      var answer = {complete: false};
      var title = document.querySelector('.SITitle');

      if (title && title.innerText === "Change Request")
      {
        var link = {};
        link.docRequestor  = getElementByXpath('//*[@id="link$requester"]');
        link.docOwner      = getElementByXpath('//*[@id="link$linked_ci_owner"]');
        link.docPrimary    = getElementByXpath('//*[@id="link$ci_primary_dba"]');

        if (followEmail)
        {

          chrome.runtime.sendMessage({type:"back-sendInFuture", 
            data: {token:"viewRecord",request:"cont-FindEmail"} },
            function(){link.docOwner.click();});

          chrome.runtime.sendMessage({type:"back-sendInFuture", 
            data: {token:"viewRecord",request:"cont-FindEmail"} },
            function(){link.docRequestor.click();});

          chrome.runtime.sendMessage({type:"back-sendInFuture", 
            data: {token:"viewRecord",request:"cont-FindEmail"} },
            function(){link.docPrimary.click();});

        }

        answer.docRequestor = link.docRequestor;
        answer.docOwner     = link.docOwner;
        answer.docPrimary   = link.docPrimary;

        
        answer.docPriority  = getElementByXpath('//*[@id="lf27794"]');
        answer.docCategory  = getElementByXpath('//*[@id="lf27883"]');

        answer.docCIName     = getElementByXpath('//*[@id="lf27777"]');
        answer.docId         = getElementByXpath('//*[@id="lf28024"]');
        answer.docCompany    = getElementByXpath('//*[@id="lf27893"]');
        answer.docSummary    = getElementByXpath('//*[@id="lf27796"]');
        answer.docTimeWindow = getElementByXpath('//*[@id="mainwrapper"]/tbody/tr/td/form[1]/table/tbody/tr[4]/td/div[1]/div/table/tbody/tr[15]/td/table');
      }


      if (title && title.innerText === "Incident")
      {
       answer.docId        = getElementByXpath('//*[@id="lf29660"]');
       answer.docPriority  = getElementByXpath('//*[@id="lf29504"]');
       answer.docCategory  = getElementByXpath('//*[@id="lf29563"]');
       answer.docSummary   = getElementByXpath('//*[@id="lf29494"]');
       answer.docCompany   = getElementByXpath('//*[@id="lf29559"]');
       answer.docCIName    = getElementByXpath('//*[@id="lf29527"]');
     }


     if (title && title.innerText === "Service Request")
     {
       answer.docId        = getElementByXpath('//*[@id="lf25489"]');
       answer.docPriority  = getElementByXpath('//*[@id="lf25331"]');
       answer.docCategory  = getElementByXpath('//*[@id="lf25410"]');
       answer.docSummary   = getElementByXpath('//*[@id="lf25337"]');
       answer.docCompany   = getElementByXpath('//*[@id="lf25419"]');
       answer.docCIName    = getElementByXpath('//*[@id="lf25379"]');
     }


     if ( !hasNullField(answer) )
     {
      answer = toSimpleObject(answer);
      answer.complete = true;
    }

    return answer; 
  }

  function gatherPersonEmail()
  {
    var answer = {complete:false};

    answer.email    = getElementByXpath('//*[@id="lf25008"]');  
    answer.fullName = getElementByXpath('//*[@id="lf25004"]');


    if ( !hasNullField(answer) )
    {
      answer = toSimpleObject(answer);
      answer.complete = true;
    }

    return answer;
  }


  if ( opt.GatherTicketInf)
  {


    switch (tag)
    {
     case mCl.tags.viewI: 
     case mCl.tags.viewSR: 
     case mCl.tags.viewCR: 
     {

       chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
       {
        var inf;

        if (request.type === "cont-TicketInf")
        {


          var followEmail = request.data.type !== "short";

          inf = gatherTicketInf( followEmail );

          if (inf.complete === true)
          {
            delete inf.complete;
            chrome.runtime.sendMessage({type: "back-TicketInf",
              data: {inf:inf,
               type:request.data.type}
             });
          }
        }
      });   

       break;
     }

     case mCl.tags.viewRecord:
     {
       chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
       {
        var inf;

        if (request.type === "cont-FindEmail")
        {
          inf = gatherPersonEmail();

          if (inf.complete === true)
          {
           delete inf.complete;
           chrome.runtime.sendMessage({type: "back-FindEmail",
             data: {
              inf:inf,
              tabId:Module.thisTab.tab.id
            }});
         }
       }

     });


       chrome.runtime.sendMessage( {type:"back-sendNow",
         data:{token:"viewRecord", tabId:Module.thisTab.tab.id}});

       break;
     }  
   }

 }

}
 /**  
     Option for reorginize fields in one column
    
    @param opt Current option set
    */
    function optReorganizeFields(opt,tag)
    {
      var active = false;


      switch (tag)
      {
       case mCl.tags.viewI: 
       case mCl.tags.viewSR: 
       case mCl.tags.viewCR: 
       case mCl.tags.editI: 
       case mCl.tags.editSR: 
       case mCl.tags.editCR:
       case mCl.tags.newI:
       case mCl.tags.newSR:
       case mCl.tags.newCR:

       { active=true; break;} 
     }

     if ( opt.ReorginizeFields && active)
     {
      Module.execInTop(["opm@mode@slave_part_1"],function()
      {
        var mSlP_1 = Module.get("slave_part_1");
        mSlP_1.optReorganizeFields(opt,tag);
      });
    }
  }

  /**  
     Option for quick fill CI name and submitter field
    
    @param opt Current option set
    */
    function optQuickCIName(opt,tag)
    {
      var active = false;

      switch (tag)
      {
       case mCl.tags.editI: 
       case mCl.tags.editSR: 
       case mCl.tags.editCR:
       case mCl.tags.newI: 
       case mCl.tags.newSR: 
       case mCl.tags.newCR:  
       { active=true; break;} 
     }

     if ( opt.QuickCIName && active)
     {
       preparePanel();

       Module.execInTop(["opm@mode@slave_part_1"],function()
       {
        var mSlP_1 = Module.get("slave_part_1");
        mSlP_1.optQuickCIName(tag);
      });
     }



     active = false;

     switch (tag)
     {
       case mCl.tags.lookUpUser:  
       { active=true; break;} 
     }

     if ( opt.QuickCIName && active)
     {
      mSt.get( mSt.keys.lookUpUser, function(val)
      {
        var res = val[mSt.keys.lookUpUser];


        var input = document.querySelector('input.wizardinput');

        if (res !== "")
        {
          input.value = res;
          mSt.set( mSt.keys.lookUpUser, "");
        }

        input.addEventListener("keydown",
          function(e){
           console.log(e);
           if (e.keyIdentifier === "Alt")
           {
            var imp = mUt.getElementByXpath('//*[@id="wrapper"]/table/tbody/tr[4]/td/input[1]');

            Module.loadScript("js/modules/opm/mode/slave_lookup.js", true,
             function()
             {
                        //imp.focus();
                        imp.click();
                      }); 

          }


        });
      });

    }


    active = false;
    
    switch (tag)
    {
     case mCl.tags.lookUpItem:  
     { active=true; break;} 
   }


   if ( opt.QuickCIName && active)
   {
    var input = document.querySelector('input.wizardinput');

    input.addEventListener("keydown",
      function(e){
       console.log(e);
       if (e.keyIdentifier === "Alt")
       {
        var imp = mUt.getElementByXpath('//*[@id="wrapper"]/table/tbody/tr[4]/td/input[1]');

        Module.loadScript("js/modules/opm/mode/slave_lookup.js", true,
         function()
         {
                        //imp.focus();
                        imp.click();
                      }); 

      }
    });    
  }

}

function loadExtStyle()
{
 style = document.createElement("style");

 style.innerHTML = `

 .extPanel   {
   display: inline-flex;

 }

 .extPanel * {
  font-family: monospace;
  font-size:17px;

}

.extPanel div  {

 margin: 5px;
 padding: 5px;

}

.extPanel input, .extPanel span, .extPanel select, .extPanel button 
{
  margin: 5px;

}

.extPanel  textarea{

  margin: 5px ;
  background-color: #EFF4FF;
}

.extPanel#longTextPanelButton{
  
  width:300px;
  height:100px;
  overflow:scroll;
}

.extPanel#informPanelButton{

  width:160px;
  display:inline;
}

.extPanel#informPanel button {

  border-radius: 10px;
  border-style: outset;
  border-color: black;
  
  font-weight: bold;
  font-family: sans-serif;
  font-size: 10px;
  height: 17px;
  width:65px;
}

.groupTag { 
  color: darkcyan;
  font-weight: bold;
  font-size: 15px;
}

.dedicTagActive { 
  color: red;
  font-size: 15px;
  font-weight: bold;
}

.dedicTag { 
  color: rgba(202, 202, 202, 0.64);
  font-size: 15px;
  font-weight: bold;
}

.extPanel button {
  margin : 1px 1px;

}

.extPanel td button {
  width: 30.9%;
  height: 40px;
  font-size: 14px;
   border-radius: 10px;

}

.extPanel .stuffOnly * {
  font-size : 12px;
}

.buttonUnknown {

 background-color:#EFF4FF;
}

.buttonGood {


 background-color:#4FD64F;
}

.buttonError {


 background-color:red;
}

.buttonWarning {


 background-color:yellow;
}
`;

document.body.appendChild(style); 
}




   /**  
       Realisation all options in current
       */
       function register()
       { 
        mSt.get(mSt.keys.flagsOption, function(res)
        {
          var opt = res[mSt.keys.flagsOption];

          var tag = mCl.classify();

          loadExtStyle();

          optionChangeTitle(opt, tag)  ;
          optionMassEdit(opt, tag)     ;
          optionContextMenus(opt, tag) ;
          optionOftenTeam(opt, tag)    ;
          optionMessagePass(opt, tag)  ;
          optionTicketHotkey(opt, tag) ;
          optReorganizeFields(opt, tag);
          optQuickCIName(opt, tag)     ;


          Module.execInTop(["opm@mode@slave_part_2"],function()
          {
            var mSlP_2 = Module.get("slave_part_2");
            mSlP_2.register();
          });



          Module.execInTop(["opm@mode@slave_part_3"],function()
          {
            var mSlP_3 = Module.get("slave_part_3");
            mSlP_3.register();
          });

          Module.execInTop(["opm@mode@slave_part_4"],function()
          {
            var mSlP_4 = Module.get("slave_part_4");
            mSlP_4.register();
          });

          console.log("Slave registered to actions");
        }); 

}

  /**
      Return  object which will be public interface for functions 
      in that module
      */ 
      console.log("Loaded");
      console.groupEnd();

      return {
       "register" : register
     };


   };

 }("opm@mode@slave");
