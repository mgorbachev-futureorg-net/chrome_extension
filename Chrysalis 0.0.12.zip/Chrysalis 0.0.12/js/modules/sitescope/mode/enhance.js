/**
    This is a scheleton of module which compatible  with 
    module system 
*/

window.Module.syncRoot = function (moduleName)
{
/**
   List of modules which must be loaded before this
*/
window.Module.before[moduleName] = ["base@util", "base@storage"] ;
window.Module.noncomplete[moduleName] = function()
 {
console.group("module <" + moduleName+ ">");
 
  var mUt = Module.get("util");
  var mSt = Module.get("storage");

  /**
     Simple autologin
  */
  function login()
  { 
    var u =   document.getElementById('j_username');
    var p =   document.getElementById('j_password');
    var c =   mUt.getElementByXpath('/html/body/form/table[1]/tbody/tr[2]/td[3]/table/tbody/tr[3]/td/a');
   
    if (u&&p&&c)
    { 
      mSt.get(mSt.keys.SISCredential, function(cred)
      { 
         mSt.get(mSt.keys.SISNextLoginTime, function(time)
        { 
         cred = cred[mSt.keys.SISCredential   ];
         time = time[mSt.keys.SISNextLoginTime];

         if (Date.now() > time)
         {
           mSt.set(mSt.keys.SISNextLoginTime, Date.now() + 5000);

           cred = cred.split("@");
             
           u.value = cred[0];
           p.value = cred[1];
           c.click();    
         } 
       
        });               
      });

    }
  }
 


  console.log("Loaded");
  console.groupEnd();
  /**
      Return  object which will be public interface for functions 
      in that module
  */  
  return {
   "login" : login
  };

 };

}("sitescope@mode@enhance");