console.group("moduleSystem");
/**
   This is base module conatains  module loading system
   All another modules can be loaded by function of this module

*/

/**
 Global object for work with modules
*/ 
var _Module         = Module;
var Module = function(){



/**
    Make simple object withour prototype
    Then populate him with own fields <obj>

    @param obj object from which created simple object 
*/
function refine(obj)
{
 var ref = Object.create(null);

 for (var key in obj)
  if (obj.hasOwnProperty(key))
    ref[key] = obj[key]; 
 

 return ref;
}

function throwMessage(strMsg)
 {
   throw "ERROR: " + strMsg;
 }

/**
 Already loaded modules
*/
var modules     = refine({});
var timeOfLoad  = refine({});
var before      = refine({});
var noncomplete = refine({});

/**
 OS independed logical module path delimiter

@example   Will be used as  "base@util"
*/
var strLogicalPathDelim=/@/g;



/**
   Object for this tab information
*/
var thisTab = {};


/**
   Perform api call for exactly this tab
  
  @param name     full name of api function
  @param params   object with params for api function call
  @param callback function for execute after api call end
*/
function executeScriptInTab(params,callBack)
{
  var reqApiCall = function()
  {
    var api = ["tabs", "executeScript"];
    var args = [thisTab.tab.id, params, "<sendResponse>"];

    chrome.runtime.sendMessage(
                {
                 type:"back-apiCall",
                 api:api,
                 args:args,
                },
         callBack);

  };

  /**
      Check if it is requested tab information
  */
  if ( thisTab.tab )
   { 
         reqApiCall();
   }
  else
  {
    /**
        Send request tab information
    */
    var processPingReq = function(request,sender,sendResponse)
          {

            /**
               After getting answer, unsubscribe for future
               messages of this type
            */
            if (request.type === "content-pingRes" )
            {
             thisTab.tab = request.thisTab;
             //console.log("Modules will be load into this tab ",thisTab);
             chrome.runtime.onMessage.removeListener(processPingReq);                          

             reqApiCall();
            }
          };
 /**
    Subscribe for messages with tab information
 */
 chrome.runtime.onMessage.addListener(processPingReq);
 chrome.runtime.sendMessage({type:"back-pingReq"});
 }
 
}


/*
 Execute script file in context of current tab 

 @param strScriptPath  string with path to script file
 @param inAllFrames    run script in all frames
 @param funcExec       function to execute after script loaded

 @return null
*/
function loadScriptIntoDocument(strScriptPath, inAllFrames,funcExec)
  {
    var strExt = chrome.extension.getURL("");

    if (document.URL.startsWith( strExt))
    {  
      var _script = document.createElement("script");
      _script.src = strExt + strScriptPath;
      _script.addEventListener('load', funcExec);
      document.body.appendChild(_script);
    }
  else
  {
    var params = {allFrames: inAllFrames, 
                 file: strScriptPath};

    executeScriptInTab(params, funcExec);
  }
  
  return null;
  

  }

/**
 Load module and  execute function in context of this module
 
 @param strModuleName  string with module name
 @param inAllFrames    run script in all frames
 @param funcExec       function to execute after module loaded

 @return null
*/
function withModule(strModuleName, inAllFrames, funcExec)
{
var strModulePath =  strModuleName.replace(strLogicalPathDelim,'/');
var strScriptPath =  "js/modules/" + strModulePath + ".js";

/**
   Check if module already loaded
*/
if (! modules[strModuleName])
{
 loadScriptIntoDocument(strScriptPath,inAllFrames,function()
 	{
      if (!before[strModuleName] ||
             !noncomplete[strModuleName])
      {
       throwMessage("Incorrecty loaded "  +
            " module with name " + "'" + strModuleName + "'");
      }
     
      


      multiLoad(before[strModuleName],inAllFrames, function()
        {
        
          if (! modules[strModuleName])
          {
          modules[strModuleName] =
              refine(new noncomplete[strModuleName]() );


          timeOfLoad[strModuleName] = new Date().toLocaleTimeString();
          }
         /**
          Execute function in  module context
         */
          funcExec();
      
       });

      	});
}
 else
 {
  /**
     Execute function in  module context
  */
  funcExec();
 }
 
 return null;
}


/**
 Execute function after loading chain of modules

 @param arrStrModuleName  array of string with module names
 @param inAllFrames    run module script in all document frames
 @param funcExec       function to execute after last module loaded
 
 @return null
*/
function multiLoad(arrStrModuleName,inAllFrames, funcExec)
{
/**
   If function not provided use stub
*/  
if (!funcExec)
  funcExec = function(){};

var length = arrStrModuleName.length;
if (length !== 0) 
 {
   var count = 0;

   var afterLoad= function() 
   {
   count ++;
   if (count === length) funcExec();
   };

   for (var i = 0; i<length; i++)
    withModule(arrStrModuleName[i],inAllFrames,afterLoad); 
 }
 else 
 {
  funcExec();
 }

 return null;
}


/*
 Get object of module which already loaded

@param strModuleName Name of module
@return object       Module object
*/
function getModule(strModuleName)
{
var strName = strModuleName;

var intWasFound = 0;
var module = null;

for (var name in modules)
{
 if (name.endsWith(strName))
  {
    intWasFound++;
    module = modules[name];
  }
}

 /**
    If was found more then one module stop execution
 */
 if (intWasFound !== 1 )
 {
  throwMessage("Was found " + intWasFound +
            " modules with name " + "'" + strModuleName + "'");

 }

return  module;
}


 /**  
     Dump order of module loading with time values

  */
function dumpOrderOfLoad()
{
 var css = "color:darkgreen;";

console.group("%cOrder of load (%s)",css,new Date().toLocaleTimeString());

   for( var module in modules)
   {
    console.group(module);
    
      var bef = before[module];
      for (var i=0; i< bef.length; i++ )
       console.log("%c%s at %s",css,bef[i],timeOfLoad[bef[i]] );

    console.groupEnd();
   }

 console.groupEnd();

}


/*
 Public interface for work with modules

execInTop Function for load module chain in top frame
execInAll Function for load module chain in all  frames
get       Function for get module object
loaded    All alredy loaded modules
*/
return refine ({
execInTop    : function(a,b){ multiLoad(a,false,b);},
execInAll    : function(a,b){ multiLoad(a,true,b);},
"get"        : getModule  ,
"loaded"     : modules    ,
"before"     : before     ,
"noncomplete": noncomplete,
"syncRoot"   : {},
"time"       : timeOfLoad,
"dump"       : dumpOrderOfLoad,
"thisTab"    : thisTab,
"loadScript" : loadScriptIntoDocument 
});

}();

//console.log("This module system ", Module);

console.log("Load");
console.groupEnd();