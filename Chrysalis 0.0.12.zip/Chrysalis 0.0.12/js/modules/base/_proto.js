/**
    This is a scheleton of module which compatible  with 
    module system 
*/

window.Module.syncRoot = function (moduleName)
{
/**
   List of modules which must be loaded before this
*/
window.Module.before[moduleName] = [
                            "opm@inf@classify",
                            "base@util",
                            "opm@inf@classifyFunc"] ;

window.Module.noncomplete[moduleName] = function()
 {
 console.group("module <" + moduleName+ ">");

  var mUt   = Module.get("util");
  var mClFunc = Module.get("classifyFunc");
  var mCl     = Module.get("classify"); 
  var mEnFunc = Module.get("enhanceFunc"); 

  function FUN()
  { 

  }
 
  /**
      Return  object which will be public interface for functions 
      in that module
  */ 
console.log("Loaded");
console.groupEnd();
  	
  return {
   "FUN" : FUN
  };


};

}("base@_proto");