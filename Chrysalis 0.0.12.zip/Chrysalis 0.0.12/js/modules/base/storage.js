window.Module.syncRoot = function (moduleName)
{
/**
   List of modules which must be loaded before this
*/
window.Module.before[moduleName] = ["base@util"] ;
window.Module.noncomplete[moduleName] = function()
 {
 console.group("module <" + moduleName+ ">");
 
 var mUt   = Module.get("util");
 
 var keys = mUt.arrayToObj([
                       "flagsOption"  ,
                       "SISCredential",
                       "dataSlot",
                       "SISNextLoginTime",
                       "textFields",
                       "lookUpUser",
                       "viewContentParams",
                       "historyPerCustomer",
                       "notesPerCustomer"
                          ]);

 var store = mUt.refine({});

 store [ keys.flagsOption       ]  = "local"   ;
 store [ keys.dataSlot          ]  = "bookmark";
 store [ keys.SISCredential     ]  = "temp"    ;
 store [ keys.SISNextLoginTime  ]  = "temp"    ;
 store [ keys.textFields        ]  = "local"   ;
 store [ keys.lookUpUser        ]  = "temp"    ;
 store [ keys.viewContentParams ]  = "local"   ;
 store [ keys.historyPerCustomer]  = "local"   ;
 store [ keys.notesPerCustomer  ]  = "local"   ;
                    

var strDefBookmark = "http://10.0.0.0/";
  /**
     Get value from storage
     Type of storage define in object <store> for this <item>

     @param item     String with key
     @param callback Function to execute with item value
  */
  function get(item, callback)
  { 
   mUt.assertType(callback,"function");
   
  switch (store[item])
  {
    case "local": 
     {
       chrome.storage.local.get(item,callback);
       break;
     }
   
     case "temp":
    {

        chrome.runtime.sendMessage({type:"back-getTmpData",
                                data:{key:item}}, callback);
       break;
     }

     case "bookmark":
     {
      Module.execInTop(["base@bookmark"],function()
        {
          var mBk = Module.get("bookmark");
 

           var query = { title : item};

            mBk.query(query, function(elts)
            {
              var res= {};

              if (elts.length === 1)
              {
                var value = decodeURIComponent(elts[0].url);
                
                value = value.replace(strDefBookmark,"");
                
                res[item] = value;
              }
              else
              {
               res[item] = "";
              }

             callback (res);

            });    

        });
  
      break;
     }

  }
 

  }

  /**  
     Set value in storage
     Type of storage define in object <store> for this <item>

     @param item     String with key
     @param value    String with value
   */
  function set(item,value)
  {
  switch (store[item])
   {
    case "local": 
     {
       var res = mUt.refine({});
      res[item] = value;

      chrome.storage.local.set( res);
       break;
     }
   
     case "temp":
     {
        chrome.runtime.sendMessage({type:"back-setTmpData",
                                data:{key:item,value:value}} );
       break;
     }

      case "bookmark":
     {
       Module.execInTop(["base@bookmark"],function()
        {
         var mBk = Module.get("bookmark");

        var query = { title : item};
        
        mBk.query(query, function(elts)
        {
           var title = item;
           var url   = strDefBookmark + encodeURIComponent(value);

          if (elts.length === 0)
          {
           mBk.create({title:title, url:url });
          }
          else if (elts.length === 1)
          {
           mBk.update(title, {title:title, url:url });
          }
          else
           {
             mUt.throwMessage("Was found ", elts , " bookmarks when try set value");
           }
         
        });


      });    
   

      break;
     }
   }

  }
 

console.log("Loaded");
console.groupEnd();
 /**
      Return  object which will be public interface for functions 
      in that module
  */  
  return {
   "get" : get,
   "set"  : set,
   "keys" : keys
  };

 };

}("base@storage");