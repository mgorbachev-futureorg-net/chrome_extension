window.Module.syncRoot = function (moduleName)
{
/**
   List of modules which must be loaded before this
*/
window.Module.before[moduleName] = [] ;
window.Module.noncomplete[moduleName] = function()
 {
 console.group("module <" + moduleName+ ">");
 
/**
   Throw exception with string message

   @param strMsg  String with error message
*/
function throwMessage(strMsg)
 {
   throw "THROW ERROR: " + strMsg;
 }

/**
   Check assertion is correct
   
   @param arg     Argument which type will be check
   @param type    Correct type for this argument
   @param strMsg  String with error message
*/
 function assertType(arg,type,strMsg)
 {
  var argType = typeof arg;

   if (argType !== type)
   {
     throwMessage(strMsg || "Expected type is " + type + "but get " + argType);
   }
 }

 /**  
     Check assertion is correct

     @param arg     Boolean condition
     @param strMsg  String with error message
  */
 function assertBool(arg,strMsg)
 {
  if (! arg)
   {
     throwMessage(strMsg || "Condition is false");
   }
 }

/**
   Get array of object keys

   @param object keys from which will be extracted
*/
function objKeys(obj)
 { 
   var keys = [];

    for (var key in obj)
     if (obj.hasOwnProperty && obj.hasOwnProperty(key) ||
                                      (! obj.hasOwnProperty)  ) 
    {
     keys.push(key);
    }
   
   return keys;
 }

/**
   Transpose tree object into flat

   @param obj   Object for transpose
   @param delim Delimiter for object keys 
*/
function flatterObject(obj,delim)
 {
   var ref = Object.create(null);
  
  for (var key in obj)
    if (obj.hasOwnProperty && obj.hasOwnProperty(key) ||
                                      (! obj.hasOwnProperty)  ) 
   {
     var value = obj[key];

     if (typeof value === "string" ||
           typeof value === "number" )
      {
        ref[key] = value;
      }
      else
       {
         var flat = flatterObject(value,delim);

         for (var flatKey in flat)
            ref[ key + delim + flatKey] = flat[flatKey];         
       }
   }
 
  return ref;
 }

/**
   Generate object with keys and values from string array
  
   @param arr Source array 
*/
function arrayToObj(keys,values)
 {
  var ref = Object.create(null);

  for (var i=0; i<keys.length; i++)
    {
      var key   = keys[i].slice();
      assertType(key, "string");

      var value = keys[i].slice();

     if (values && values[i])
       {
         value = values[i];
         value = values[i].slice && values[i].slice() || value ;
       }
          
      ref[ key ] = value;                   
    }
  
  
  return ref;
 }

/**
    Make simple object without prototype
    Then populate him with own fields of <obj>

    @param obj object from which created simple object 
*/
function refine(obj)
{
 var ref = Object.create(null);

 for (var key in obj)
  if (obj.hasOwnProperty(key))
    ref[key] = obj[key]; 
 
 return ref;
}

/**
    Return element of DOM selected by XPath

    @param   path   XPath to element
*/
function getElementByXpath(path) {
  return document.evaluate(path, document, null,
           XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}



 /**  
     Automatic resize of TextArea to fit text content

     @param arg
  */
function autoResize(area)
{
  var s = document.createElement("div");
  var p = document.createElement("pre");
  
  p.innerText = area.value;
  s.style = area.style;
  s.appendChild(p);
  
  area.parentElement.appendChild(s);
   area.style.height = s.childNodes[0].clientHeight + 25 + "px";
   area.style.width  = s.childNodes[0].clientWidth +"px";
  area.parentElement.removeChild(s);
}

/**
   Return content of clipboard buffer
*/
function  getClipBoardBuffer()
 {
   var clip = "";

    var tmpInput = document.createElement('textarea');
    var tmpBody  = document.querySelector('body');
    tmpBody.appendChild(tmpInput);
     
    tmpInput.focus();
    document.execCommand('paste');
    clip = tmpInput.value;

    tmpBody.removeChild(tmpInput);

  return  clip;
 }

/**
   Set content of clipboard buffer

   @param value   string which will be send in clipboard
*/
function  setClipBoardBuffer(value)
 {
    var tmpInput = document.createElement('textarea');
    var tmpBody  = document.querySelector('body');
    tmpBody.appendChild(tmpInput);
     
    tmpInput.focus();
    tmpInput.value = value;
    tmpInput.select();
    document.execCommand('copy');
  
    tmpBody.removeChild(tmpInput);
    document.body.scrollIntoView();
 }


console.log("Loaded");
console.groupEnd();

 /**
      Return  object which will be public interface for functions 
      in that module
  */ 	
    return {
   "assertType"        : assertType        , 
   "assertBool"        : assertBool        ,
   "refine"			       : refine            ,
   "flat"              : flatterObject     ,
   "arrayToObj"        : arrayToObj        ,
   "throwMessage"      : throwMessage      ,
   "objKeys"           : objKeys           ,
   "getElementByXpath" : getElementByXpath ,
   "getClipBoardBuffer": getClipBoardBuffer,
   "setClipBoardBuffer": setClipBoardBuffer,
   "autoResize"        : autoResize
  };
};

}("base@util");