/**
    Module for work with bookmarks in chrome
*/

window.Module.syncRoot = function (moduleName)
{
/**
   List of modules which must be loaded before this
*/
window.Module.before[moduleName] = [
                            "base@util",
                            ] ;

window.Module.noncomplete[moduleName] = function()
 {
 console.group("module <" + moduleName+ ">");

  var mUt   = Module.get("util");
  
  /**
     Root folder in which will be store all data
  */
  var strFolderTitle = "SyncFolder";  

 /**  
     Get id for folder in will be store all data

     @param callback Function for call with folder id
  */
 function getSyncFolderId(callBack)
  {
    mUt.assertType(callBack,"function"); 
   
    var api = ["bookmarks", "search"];
    var args = [{title:strFolderTitle}, "<sendResponse>"];

   chrome.runtime.sendMessage(
                {
                 type:"back-apiCall",
                 api:api,
                 args:args,
                 },
     function(nodes)
     {
      mUt.assertType(nodes,"object");
      mUt.assertBool(nodes.length === 1);
      callBack ( nodes[0].id); 
     });

  }

 /**  
     Filter bookmarks list by id

     @param bookmarks  Array of bookmarks
     @param id         Id for filter by
  */
  function filterBookmarksById(bookmarks, id)
   {
     var res = [];
  
        for (var i=0; i<bookmarks.length; i++)
        {
          if (bookmarks[i].parentId === id)
            res.push(bookmarks[i]);
        }

     return res;
   }

 /**
    Create bookmark in folder <strFolderTitle>

    @param bookmark Object for new bookmark
    
 */

  function create(bookmark)
  { 
    mUt.assertType(bookmark,"object"); 


  getSyncFolderId(function(id)
   {
          
    var api = ["bookmarks", "search"];
    var args = [{title:bookmark.title}, "<sendResponse>"];

   chrome.runtime.sendMessage(
                {
                 type:"back-apiCall",
                 api:api,
                 args:args,
                 },
     function(nodes)
     { 
      nodes = filterBookmarksById(nodes,id);
      mUt.assertBool(nodes.length===0);

     bookmark.parentId = id;

         var x_api = ["bookmarks", "create"];
         var x_args = [bookmark];
     
          chrome.runtime.sendMessage(
                {
                 type:"back-apiCall",
                 api:x_api,
                 args:x_args,
                 });
     });

   });

  }

   /**  
       Remove bookmark from folder <strFolderTitle>
  
       @param strTitle  Title of bookmark to remove
    */
  function remove(strTitle)
  {
    mUt.assertType(strTitle,"string");

   getSyncFolderId(function(id)
   {
          
    var api = ["bookmarks", "search"];
    var args = [{title:strTitle}, "<sendResponse>"];

   chrome.runtime.sendMessage(
                {
                 type:"back-apiCall",
                 api:api,
                 args:args,
                 },
     function(nodes)
     { 
      nodes = filterBookmarksById(nodes,id);
      mUt.assertBool(nodes.length===1);

      var x_api = ["bookmarks", "remove"];
      var x_args = [nodes[0].id];
     
      chrome.runtime.sendMessage(
                {
                 type:"back-apiCall",
                 api:x_api,
                 args:x_args,
                 });
     });

   });
  }

   /**  
       Refresh bookmark data with new data
        
       @param strTitle     Title of bookmark to find
       @param bookmark     Object for new bookmark
    
    */
  function update(strTitle, bookmark)
 {
   mUt.assertType(strTitle,"string");
   mUt.assertType(bookmark,"object");

   getSyncFolderId(function(id)
   {
          
    var api = ["bookmarks", "search"];
    var args = [{title:strTitle}, "<sendResponse>"];

   chrome.runtime.sendMessage(
                {
                 type:"back-apiCall",
                 api:api,
                 args:args,
                 },
     function(nodes)
     { 
      nodes = filterBookmarksById(nodes,id);
      mUt.assertBool(nodes.length===1);

      var x_api = ["bookmarks", "update"];
      var x_args = [nodes[0].id, bookmark];
     
      chrome.runtime.sendMessage(
                {
                 type:"back-apiCall",
                 api:x_api,
                 args:x_args,
                 });     
     });

   });
  }


 /**  
     Query list of bookmarks using 

     @param arg
  */
  function query(objQuery, callBack)
   {
   mUt.assertType(objQuery,"object");
   mUt.assertType(callBack,"function");

   getSyncFolderId(function(id)
   {
          
    var api = ["bookmarks", "search"];
    var args = [objQuery, "<sendResponse>"];

   chrome.runtime.sendMessage(
                {
                 type:"back-apiCall",
                 api:api,
                 args:args,
                 },
     function(nodes)
     { 
      nodes = filterBookmarksById(nodes,id);
      callBack(nodes); 
     });

   });
  } 

 /**  
     If module loaded in background page
     All api functions must be call directly

  */
if (chrome.bookmarks)
{
 /**  
     Get id for folder in will be store all data

     @param callback Function for call with folder id
  */
 function getSyncFolderId(callBack)
  {
    mUt.assertType(callBack,"function"); 
   
    chrome.bookmarks.search({title:strFolderTitle},function(nodes)
      {
       mUt.assertType(nodes,"object");
       mUt.assertBool(nodes.length === 1);
       callBack ( nodes[0].id); 
      });
  }
/**  
     Filter bookmarks list by id

     @param bookmarks  Array of bookmarks
     @param id         Id for filter by
  */
  function filterBookmarksById(bookmarks, id)
   {
     var res = [];
  
        for (var i=0; i<bookmarks.length; i++)
        {
          if (bookmarks[i].parentId === id)
            res.push(bookmarks[i]);
        }

     return res;
   }

 /**
    Create bookmark in folder <strFolderTitle>

    @param bookmark Object for new bookmark
    
 */

  function create(bookmark)
  { 
    mUt.assertType(bookmark,"object"); 

    getSyncFolderId(function(id)
     {
      chrome.bookmarks.search({title:bookmark.title},function(nodes)
        {
         nodes = filterBookmarksById(nodes,id);
         mUt.assertBool(nodes.length===0);

        bookmark.parentId = id;
        chrome.bookmarks.create(bookmark);
        });   
     });
  }

   /**  
       Remove bookmark from folder <strFolderTitle>
  
       @param strTitle  Title of bookmark to remove
    */
  function remove(strTitle)
  {
    mUt.assertType(strTitle,"string");

   getSyncFolderId(function(id)
   {
    chrome.bookmarks.search({title:strTitle},function(nodes)
      {

      nodes = filterBookmarksById(nodes,id);
      mUt.assertBool(nodes.length===1);
      
      chrome.bookmarks.remove(nodes[0].id);
      });
   });
  }

   /**  
       Refresh bookmark data with new data
        
       @param strTitle     Title of bookmark to find
       @param bookmark     Object for new bookmark
    
    */
  function update(strTitle, bookmark)
 {
   mUt.assertType(strTitle,"string");
   mUt.assertType(bookmark,"object");

   getSyncFolderId(function(id)
   {
    chrome.bookmarks.search({title:strTitle},function(nodes)
      {
      nodes = filterBookmarksById(nodes,id);
      mUt.assertBool(nodes.length===1);

      chrome.bookmarks.update(nodes[0].id, bookmark);
     });
   });
 }


 /**  
     Query list of bookmarks using 

     @param arg
  */
  function query(objQuery, callBack)
   {
     mUt.assertType(objQuery,"object");
     mUt.assertType(callBack,"function");

     getSyncFolderId(function(id)
     {
      chrome.bookmarks.search(objQuery,function(nodes){

        nodes = filterBookmarksById(nodes,id);
        callBack(nodes); 
       });
      });
   } 


}


  /**
      Return  object which will be public interface for functions 
      in that module
  */ 
console.log("Loaded");
console.groupEnd();
  	
  return {
   "create" : create,
   "remove" : remove,
   "update" : update,
   "query"  : query
  };


};

}("base@bookmark");