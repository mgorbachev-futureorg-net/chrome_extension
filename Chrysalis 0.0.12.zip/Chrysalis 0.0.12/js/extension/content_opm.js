/**
   Root for content scrips works with OPM
*/
Module.execInTop(['opm@mode@slave'],function(){
 console.group("content_opm");
 
 var mSl = Module.get('slave');

 /**  
    Perform registration to all action according current options set
 */
 mSl.register();


 console.log("Content loaded");
 console.groupEnd();
});










