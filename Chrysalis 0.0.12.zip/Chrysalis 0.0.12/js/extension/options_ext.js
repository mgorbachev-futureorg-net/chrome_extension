/**
   Root for scripts works with options page
*/
Module.execInTop(["base@util", "base@storage","opm@mode@options_part_1"],function(){
 console.group("options_ext");
 
 var mUt = Module.get('util');
 var mSt = Module.get('storage');  
 var mOpt= Module.get("options_part_1");

  /**  
      Save all values on this page to storage
 
   */
function save()
{
      var params = document.querySelectorAll('input[type="checkbox"]');
      var selectedParams = mUt.refine({});

      for (var i=0; i< params.length; i++)
      {
        var p = params[i];
        selectedParams[ p.id ] = p.checked;
      }
      
      mSt.set( mSt.keys.flagsOption,  selectedParams );
     
     var login = document.getElementById("SISLogin").value;
     var pass  = document.getElementById("SISPassword").value; 

      mSt.set( mSt.keys.SISCredential, login + "@" + pass );
      mSt.set(mSt.keys.SISNextLoginTime, Date.now());
     
      //Call additional module for getting data in additional text fields
      mSt.set(mSt.keys.textFields, mOpt.getData() );
}

 /**  
     Restore all values from storage

  */
function restore()
{
     mSt.get(mSt.keys.flagsOption, function(res)
      { 
         var selectedParams = res[mSt.keys.flagsOption];

         var params = document.querySelectorAll('input[type="checkbox"]');

         for (var i=0; i< params.length; i++)
           {
            var p = params[i];
            var value = selectedParams[ p.id ] || false;
            p.checked = value;
           }
      });  


    mSt.get(mSt.keys.SISCredential, function(res)
      { 
         var cred = res[mSt.keys.SISCredential].split("@");
         document.getElementById("SISLogin").value = cred[0] || "";
         document.getElementById("SISPassword").value = cred[1] || "";
      });

     mSt.get(mSt.keys.textFields, function(val)
     {
        var textFields = val[mSt.keys.textFields];
       
        //Call additional module for setting data in additional text fields
        mOpt.setData(textFields);
     });
}


 //Adding ability folding content by double click on title
 function addFoldingByDoubleClick()
  {
	var stopEvent = function(e){e.preventDefault(); e.stopPropagation(); return false;};
	  
   [].slice.call(document.querySelectorAll(".panel > span")).map(function(elt){
  
   elt.onselect      = stopEvent;
	 elt.onselectstart = stopEvent;
	 elt.onmousedown   = stopEvent;
   });	   
	  
   [].slice.call(document.querySelectorAll(".panel > span")).map(function(elt){
      
      elt.addEventListener("dblclick",function(e){
        e.preventDefault();
		    e.stopPropagation();
        var childPanel = e.currentTarget.parentNode.querySelector('.content');
        
        var newStyle = childPanel.style.display === 'none'? 'block': 'none'
        childPanel.style.display = newStyle;
       
        return false;
       });
      
     }); 
  }


/**
   Create and add element to node
   Assign to the new element values of ID and INNER_HTML 
*/
function addElementTo(node, strTag, strId, strInnerHTML)
 {
  var elt = document.createElement(strTag);
  elt.id = strId || "";
  elt.innerHTML = strInnerHTML || "";

  node.appendChild(elt);
  return elt;
 }


 var mapButtonToStorage = {
   btnFlags       : mSt.keys.flagsOption,
   btnContextMenus: mSt.keys.textFields ,
   btnTemplate    : mSt.keys.viewContentParams,
   btnHistoryData : mSt.keys.historyPerCustomer,
   btnNotesData   : mSt.keys.notesPerCustomer
 }


var buttonState = mUt.refine({});

/**
   Track pressing to the buttons, toogle values between pressed/released
*/
function toogleButtonState(e){
 e.preventDefault();  
 var targetButton = e.target;
 var targetId     = e.target.id; 
 
 buttonState[targetId] =  ! (buttonState[targetId] || false);
 targetButton.className = buttonState[targetId]? 'btnPressed':'btnReleased';
}


/**
   Perform export values according to pressed buttons
*/
function performExportValues(e){
  e.preventDefault();
  e.stopPropagation();

save();


var result = mUt.refine({});
var keyFlags = mUt.objKeys(buttonState);
var waitForCount = keyFlags.length;
var doneForCount = 0;

//Out result to the text field after collecting all values
var outResult = function() 
  {
    doneForCount++;

    if (doneForCount === waitForCount)
    {
       var data = JSON.stringify(result,null,3);
       var area =  document.getElementById("textAreaJSON");
       area.value = data; 
    }

  }

  keyFlags.map(function(elt){
      
      if ( buttonState[elt] === true )
      { 
          mSt.get( mapButtonToStorage[elt], function(val)
              {
                result [  mapButtonToStorage[elt] ] = val[ mapButtonToStorage[elt] ];
                outResult();
              });
      }
       else
        outResult();
  });


}


function performImportValues(e){
 e.preventDefault();
 e.stopPropagation();

 var keyFlags = mUt.objKeys(buttonState);

 var area =  document.getElementById("textAreaJSON");
 var parsedValues = JSON.parse(area.value);

 keyFlags.map(function(elt){
      
      if ( buttonState[elt] === true )
      { 
         if (parsedValues[ mapButtonToStorage[elt]  ] )
         {
           mSt.set(mapButtonToStorage[elt], parsedValues[ mapButtonToStorage[elt] ]);
         }
         else
         {
           console.log("No values loaded for %s",mapButtonToStorage[elt] );
         }
      }
       
  });

 restore();
 }


function addImportExportProcessing()
 {
  
  var panel = document.getElementById('saveAndLoadControls');


  var lineOne   = addElementTo(panel, 'div', 'lineOne');
  var lineTwo   = addElementTo(panel, 'div', 'lineTwo');
  var lineThree = addElementTo(panel, 'div', 'lineThree');

  
  addElementTo(lineOne, 'button','btnFlags','Option flags');
  addElementTo(lineOne, 'button','btnContextMenus','Context menus text');
  addElementTo(lineOne, 'button','btnTemplate','Text templates');
  addElementTo(lineOne, 'button','btnHistoryData','History');
  addElementTo(lineOne, 'button','btnNotesData','Notes');
  lineOne.addEventListener('click', toogleButtonState);


  addElementTo(lineTwo, 'textarea','textAreaJSON');


  addElementTo(lineThree, 'button','btnExport','Export values');
  addElementTo(lineThree, 'button','btnImport','Import values');
  document.getElementById('btnExport').addEventListener('click', performExportValues);
  document.getElementById('btnImport').addEventListener('click', performImportValues);
 
 }


/*
     "flagsOption": {
      "AutoSISLogin": false,
      "ContextInsert": false,
      "DataSlots": false,
      "GatherTicketInf": false,
      "GlobalViewEnhance": false,
      "MassEditEnhancenment": false,
      "QuickCIName": false,
      "QuickTicketOpen": false,
      "ReorginizeFields": false,
      "ReplaceTabTitle": false,
      "SelectTeamEnhancement": false,
      "ShortMessageCreate": false,
      "TicketsHotkey": false,
      "optInformPanel": true
*/

function generateCheckboxes(objKeyTitle)
 {
   var strResultHTML = "";

   for (var i in objKeyTitle)
    {
      strResultHTML += `   
        <input type="checkbox" id="${i}">
            <label for="${i}">${objKeyTitle[i]}</label>
            <br>`;
    }

   return strResultHTML;

 }

 function addCheckBoxGeneration()
 {
   var lightOptions = {

"MassEditEnhancenment" :"Bring up most used mass edit fields",
"ReplaceTabTitle":"Replace tab title to 'docID-docCompany",
"optInformPanel":"Additional information panel",
"TicketsHotkey":"Hotkeys for ticket tabs",
"QuickCIName":'Quick fill "Submitter" and "CI name" fields',
"SelectTeamEnhancement":"Bring up most used teams",
"ReorginizeFields": "Tabs view enhancement by double click on tab title",
"GlobalViewEnhance": "Enhance view of tickets",
"ReloadTitlePage":"Periodically reload main page",
"CollectAllTablesData":"Perform data collection from all tables",
"ShowUpperInformPanel":"Show inform panel with addition control button"
   };

   var weightOptions = {
 "ContextInsert":"Context menus for insert text",
 "GatherTicketInf":"Gather ticket information for standart goals",
 "QuickTicketOpen":"Quick open ticket from clipboard",
 "ShortMessageCreate":"Quick create message about ticket",
 "DataSlots":"Temporary data slots"

   };

   document.getElementById('lightOptions').innerHTML = generateCheckboxes(lightOptions);
   document.getElementById('weightOptions').innerHTML = generateCheckboxes(weightOptions);
 }

 /**  
     Event listeners for this page

  */
window.addEventListener("load", function()
  {
    /**  
      Register additional event processing
    */
     mOpt.register();


     document.getElementById("panelWindow").addEventListener("click",save); 
	   document.getElementById("SISLogin").addEventListener("input", save);
	   document.getElementById("SISPassword").addEventListener("input", save); 
        
    //Additional functions for special task  
    addCheckBoxGeneration()    ;   
    addFoldingByDoubleClick()  ;
    addImportExportProcessing();


    //Restore actual values of parameters in visual controls
     restore();
  });


 console.log("Content loaded");
 console.groupEnd();
});
















