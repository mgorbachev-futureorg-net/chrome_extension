/**
   Root for scripts of vew panel
*/
Module.execInTop(["base@util", "base@storage"],function(){
 console.group("view_panel");
 
 var mUt = Module.get('util');
 var mSt = Module.get("storage");
  
 /**  
     View information as raw data

  */
 function getInfAsFields()
   {
     var strResult = ""; 
        for (var prop in normalizeCurrentInf())
        {
           strResult += prop + "\n";
        }

     return strResult;
   }
   

 /**  
     Get list of fields in current information object
  */
   function getInfAsDump()
   {
        var strResult = ""; 
        for (var prop in currentInf)
        {
          if (currentInf.hasOwnProperty(prop))
           strResult += prop + "==="+ currentInf[prop] + "\n";
        }

        if (strResult === "") 
               strResult = "Empty";
    
     return strResult;
   }


 /**  
     Create information object with default values in missing fields
  */
   function normalizeCurrentInf()
   {
      var val = 
    {
     docOwner:""    , docOwnerEmail:"",
     docRequestor:"", docRequestorEmail:"",
     docPrimary:""  , docPrimaryEmail:"",
     docId:"",
     docCompany:"",
     docSummary:"",
     docTimeWindow:"",
     docCIName: "",
     docPriority:"",
     docCategory:"",
    };
     
     var prop;
     for (prop in currentInf)
     {
      if (currentInf.hasOwnProperty(prop))
                 val[prop] = currentInf[prop];
     }

     for (prop in val)
     {
       if(val.hasOwnProperty(prop) && val[prop] ==="")
        val[prop] = "<no data>";
     }

     return val;
   }
  
 
   function fillActiveShablon(funcReturnValue)
    {
  
     mSt.get( mSt.keys.viewContentParams, function(val)
    {
    var params = val[mSt.keys.viewContentParams];
    var whatBuild = document.querySelector("div[id=viewSelectors] input:checked").value;
    
    var shablon = params[whatBuild];
    var val = normalizeCurrentInf();    

    for (var i in val)
     {
       var placeHolder = new RegExp("{"+ i +"}","gi");
       var value = val[i].trim();
       if (value === "<no data>") value = "";
       shablon = shablon.replace(placeHolder, value);
     }
      
     funcReturnValue(shablon);
    });
   }
  
  function setContent(strValue)
  {
  document.getElementById("rightPanelContentTextArea").value = strValue;
  }

 /**  
     View service information about operation
  */
   function getSysInf()
   {
        var strResult = ""; 
      
       strResult += "Last update: " + (new Date()).toLocaleString() + "\n";

       var addEmail =  [];
      if (addEmail.length > 0)
        strResult += "Added next email to CC: " + addEmail.join("; ") + ";\n";

     return strResult;
   }

 /**  
     Refresh current view
  */
 function rebuildView()
   {
  
    document.getElementById("leftPanelContent").innerText = getInfAsFields();
    
   
    var whatBuild = document.querySelector("div[id=viewSelectors] input:checked").value;
    var strResult = "";
    
    mSt.get( mSt.keys.viewContentParams, function(res)
    { 
     var shablonValue = res.viewContentParams[whatBuild];
    document.getElementById("rightPanelOptionsTextArea").value = shablonValue;
    
     switch (whatBuild)
    {
     case "dump"      : setContent(getInfAsDump());      break;
     case "monitoring": setContent(getViewOfTables());   break;
     default          : fillActiveShablon(setContent);   break;
    }
  

    });
   
   document.getElementById("sysPanelContent").innerText = getSysInf();
   }


 /**  
     Fetch information about email
  */
  function fetchEmail(args)
  {
    var map = { docOwner:"", docRequestor:"", docPrimary:"" };

    for (var field in map)
    {
      var name = currentInf[field] || "";

      if (args.fullName === name)
        currentInf[field+"Email"] = args.email;
    }
  }


var tables = mUt.refine({});

 /**  
     Save data about one of the tables on monitoring

     @param args Table data object
  */
 function fetchTable(args)
  {
  if (args.data)
   {
    tables[args.title] = args;
   }
   else
   {
    delete tables[args.title];
   }
  }

 /**  
     View content of tables by selecting important fields
  */
 function getViewOfTables()
  { 
   strResult = "";

   /**  
        Columns to show
     */ 
   var interestFields = [
   "ID"
   ,"Doc Id"
   ,"Priority"
    ,"Change Priority"
   ,"Submitter Company"
   ,"Summary"
   ,"Status"
   ,"Requested Start Time"
   ,"Requested End Time"
   ]; 

   for (var key in tables)
   {
    var table = tables[key];
 
    strResult +=  key + "(" + table.data.length  +" items)\n";

 /**  
     Show only columns which in list above
  */
    var indexes =  interestFields.map(function(elt)
                        {
                         return table.labels.indexOf(elt);
                        }).filter(function(elt){return elt !== -1;});
   
    var body = table.data.map(function(row){
                return indexes.map(function(i){ return row[i];  }).join("\t");
                });

    strResult += body.join("\n") + "\n\n";
   }
   
   return strResult;
  }

   
 /**  
     Change initial view of fields
  */
 function changeView(strNewView)
  {
    document.querySelector("div[id=viewSelectors] input[value=" +strNewView + "]").checked = true;
   
  }
 
 /**  
     Object for store current gather information
  */
var currentInf = {};
  
   function refreshInf(args)
    {
      var request = args;

       if (request.type === "view-TicketInf")
       {
        currentInf = request.data.inf;
          if (request.data.type === "short")
          {
            fillActiveShablon( mUt.setClipBoardBuffer);
            fillActiveShablon(setContent);
          }
       }
      
      if (request.type === "view-FindEmail")
      {
       fetchEmail(request.data.inf);
      } 

      if (request.type === "view-tableData")
      {
       fetchTable(request.data);
      }

      if (request.type === "view-gatherShortTicketInf")
      {
        changeView("inf");
        chrome.runtime.sendMessage( {type:"active-TicketInf",  data:{type:"short"}});      
      }  

      if (request.type === "view-gatherTicketInf")
      {
        changeView("email");
        chrome.runtime.sendMessage( {type:"active-TicketInf",  data:{}});      
      }  
       
      if (request.type === "view-gatherTableInfo")
      {
        changeView("monitoring");
        chrome.runtime.sendMessage( {type:"active-viewTable",  data:{}});      
      }  
        
      rebuildView();
    }


function saveParams()
{
 mSt.get( mSt.keys.viewContentParams, function(val)
  {
    var params = val[mSt.keys.viewContentParams];
    
    var whatBuild = document.querySelector("div[id=viewSelectors] input:checked").value;
    params[whatBuild] = document.getElementById("rightPanelOptionsTextArea").value;
    mSt.set( mSt.keys.viewContentParams, params);
  });
}


window.addEventListener("load", function()
  {
     document.getElementById("viewSelectors").addEventListener("click",
        function()
        {
         rebuildView();  
        });

     chrome.runtime.onMessage.addListener(function(request,sender,sendResponse)
        {
           refreshInf(request); 
        }
      );
     
     chrome.runtime.sendMessage( {type:"back-sendNow",
     data:{token:"view-page", tabId:null}});
     
     
     document.getElementById("rightPanelOptionsTextArea").addEventListener("blur",
        function()
        {
          saveParams();
        });
  });
  

 console.log("Content loaded");
 console.groupEnd();
});










