/**
   Root for content scripts works with SiteScope
*/

Module.execInTop( ["base@storage"],function(){
 
 console.group("content_sitescope");
 
 var mSt = Module.get("storage");

  mSt.get(mSt.keys.flagsOption, function(res)
     { 
       var active = res[mSt.keys.flagsOption].AutoSISLogin;

       if (active)
       {
          Module.execInTop( ["sitescope@mode@enhance"],function(){ 
            
           var mEn = Module.get('enhance');
           mEn.login();
  
           });

          console.log("Try to autologin to SIS");
       }

     });

 
 console.log("Content loaded");
 console.groupEnd();
});










