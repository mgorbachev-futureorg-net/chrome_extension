/**
   Root for content scrips works with OPM
*/
Module.execInTop(['base@util', "opm@mode@master"],function(){
 console.group("background");
 
 var mUt = Module.get('util');
 var mMs = Module.get('master'); 
 
 
  /**  
    Perform registration to all action according current options set
  */
  mMs.register();
 
 console.log("Content loaded");
 console.groupEnd();
});




